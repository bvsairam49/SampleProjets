//
//  MBViewController.h
//  MBCircularProgressBar
//
//  Created by Mati Bot on 07/19/2015.
//  Copyright (c) 2015 Mati Bot. All rights reserved.
//

@import UIKit;

@interface MBViewController : UIViewController

@end
