//
//  DGActivityIndicatorRotatingTrigonsAnimation.h
//  DGActivityIndicatorExample
//
//  Created by tripleCC on 15/6/26.
//  Copyright (c) 2015年 Danil Gontovnik. All rights reserved.
//

#import "DGActivityIndicatorAnimation.h"

@interface DGActivityIndicatorRotatingSandglassAnimation: DGActivityIndicatorAnimation


@end
