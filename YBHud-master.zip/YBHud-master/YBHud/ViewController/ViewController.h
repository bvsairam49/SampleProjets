//
//  ViewController.h
//  YBHud
//
//  Created by Yahya on 03/02/17.
//  Copyright © 2017 yahya. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@end
