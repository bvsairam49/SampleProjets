# FTIndicator ChangeLog

| Version | Date | ChangeLog |
| :--------: | :--------: | :-------- |
|1.0.0|2016.07.31|upload to CocoaPods|
|1.0.9|2016.08.02|add status bar frame observe for notification|
|1.1.0|2016-08-12|add notification tap handler thanks to Yuli Chandra|
|1.1.1|2016-08-15|Add notification completion handler thanks to Yuli Chandra|
|1.1.2|2016-08-15|fix bugs when no text|
|1.1.3|2016-08-28|progress hud add user interaction disable|
|1.1.4|2016-09-08|fix a bug where load image from bundle not working|
|1.1.5|2016-09-20|fix: podspec doest not correctly link to "FTToastIndicator"|
|1.1.6|2016-11-22|fix a bug of not dismissing when user back to homescreen，remove subpods|



