//
//  Package.swift
//  LocalizationKit
//
//  Created by Will Powell on 02/01/2017.
//  Copyright © 2017 CocoaPods. All rights reserved.
//


import PackageDescription

let package = Package(
    name: "LocalizationKit"
)
