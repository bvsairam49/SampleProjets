//
//  ViewController.swift
//  LeadShare
//
//  Created by Srinivas Yeruva on 15/03/17.
//  Copyright © 2017 Srinivas Yeruva. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var otpOneTextField: UITextField!
    @IBOutlet weak var otpTwoTextField: UITextField!
    @IBOutlet weak var otpThreeTextField: UITextField!
    @IBOutlet weak var otpFourTextField: UITextField!
    @IBOutlet weak var otpFiveTextField: UITextField!
    @IBOutlet weak var otpSixTextField: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        initializeTextFields()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func initializeTextFields() {
        otpOneTextField.delegate = self
        otpOneTextField.keyboardType = UIKeyboardType.numberPad
        
        otpTwoTextField.delegate = self
        otpTwoTextField.keyboardType = UIKeyboardType.numberPad
        
        otpThreeTextField.delegate = self
        otpThreeTextField.keyboardType = UIKeyboardType.numberPad
        
        otpFourTextField.delegate = self
        otpFourTextField.keyboardType = UIKeyboardType.numberPad
        
        otpFiveTextField.delegate = self
        otpFiveTextField.keyboardType = UIKeyboardType.numberPad
        
        otpSixTextField.delegate = self
        otpSixTextField.keyboardType = UIKeyboardType.numberPad
        
        
        otpOneTextField.addTarget(self, action: #selector(textFieldDidChange), for: UIControlEvents.editingChanged)
        otpTwoTextField.addTarget(self, action: #selector(textFieldDidChange), for: UIControlEvents.editingChanged)
        otpThreeTextField.addTarget(self, action: #selector(textFieldDidChange), for: UIControlEvents.editingChanged)
        otpFourTextField.addTarget(self, action: #selector(textFieldDidChange), for: UIControlEvents.editingChanged)
        otpFiveTextField.addTarget(self, action: #selector(textFieldDidChange), for: UIControlEvents.editingChanged)
        otpSixTextField.addTarget(self, action: #selector(textFieldDidChange), for: UIControlEvents.editingChanged)
        
        
    }
    
    
    
    func textFieldDidChange(textField: UITextField){
        
        let text = textField.text
        
        if text?.utf16.count==1{
            switch textField{
            case otpOneTextField:
                otpTwoTextField.becomeFirstResponder()
            case otpTwoTextField:
                otpThreeTextField.becomeFirstResponder()
            case otpThreeTextField:
                otpFourTextField.becomeFirstResponder()
            case otpFourTextField:
                otpFiveTextField.becomeFirstResponder()
            case otpFiveTextField:
                otpSixTextField.becomeFirstResponder()
            case otpSixTextField:
                otpSixTextField.resignFirstResponder()
            default:
                break
            }
        }else{
            
        }
    }



}

