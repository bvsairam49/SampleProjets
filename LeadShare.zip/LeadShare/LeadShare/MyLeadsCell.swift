//
//  MyLeadsCell.swift
//  LeadShare
//
//  Created by Srinivas Yeruva on 22/03/17.
//  Copyright © 2017 Srinivas Yeruva. All rights reserved.
//

import UIKit

class MyLeadsCell: UITableViewCell {

    @IBOutlet weak var LeadName: UILabel!
    @IBOutlet weak var Time: UILabel!
    @IBOutlet weak var ViewButton: UIButton!
    @IBOutlet weak var EditButton: UIButton!
    @IBOutlet weak var Time_icon: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        ViewButton.layer.cornerRadius = 10
        ViewButton.clipsToBounds = true
        
        EditButton.layer.cornerRadius = 10
        EditButton.clipsToBounds = true
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
