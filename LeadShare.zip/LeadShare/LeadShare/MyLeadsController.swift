//
//  MyLeadsController.swift
//  LeadShare
//
//  Created by Srinivas Yeruva on 22/03/17.
//  Copyright © 2017 Srinivas Yeruva. All rights reserved.
//

import UIKit

private let reuseIdentifier = "MyLeadsCell"

class MyLeadsController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    @IBOutlet weak var MyLeadsTable: UITableView!

    
    var lead_names = ["Ashburn Ashkickers", "Chamber Champions", "Dulles East LeadShare", "Dulles South", "Loudoun Business Leaders", "Loudoun Connection", "Loudoun Business Partners", "Loudoun LeadShare", "Potomac Leadership Group", "Potomac Promoters"]
    
    override func viewDidLoad() {
        super.viewDidLoad()

        MyLeadsTable.dataSource = self
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return lead_names.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: reuseIdentifier, for: indexPath) as! MyLeadsCell
        cell.LeadName.text = lead_names[indexPath.row]
        cell.Time.text = "20 min ago"
        cell.Time_icon.image = UIImage(named: "clock_outlined")
        return cell
    }

    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
