//
//  GroupsViewController.swift
//  LeadShare
//
//  Created by Srinivas Yeruva on 20/03/17.
//  Copyright © 2017 Srinivas Yeruva. All rights reserved.
//

import UIKit

private let reuseIdentifier = "GroupCell"

class GroupsViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    @IBOutlet weak var groupsTable: UITableView!
    @IBOutlet weak var profilePicture: UIImageView!
    
    
    var groups = ["Ashburn Ashkickers", "Chamber Champions", "Dulles East LeadShare", "Dulles South", "Loudoun Business Leaders", "Loudoun Connection", "Loudoun Business Partners", "Loudoun LeadShare", "Potomac Leadership Group", "Potomac Promoters"]

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        profilePicture.image = UIImage(named: "avatar")
        groupsTable.dataSource = self
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return groups.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: reuseIdentifier, for: indexPath) as! GroupsViewCell
        cell.name.text = groups[indexPath.row]
        return cell
    }



     //MARK: - Navigation

     //In a storyboard-based application, you will often want to do a little preparation before navigation

}
