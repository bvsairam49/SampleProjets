//
//  CreateGroupViewController.swift
//  LeadShare
//
//  Created by Srinivas Yeruva on 20/03/17.
//  Copyright © 2017 Srinivas Yeruva. All rights reserved.
//

import UIKit

class CreateGroupViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var createGroupBG: UIImageView!
    @IBOutlet weak var profilePicture: UIImageView!
    @IBOutlet weak var groupName: UITextField!
    @IBOutlet weak var createGroup: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        NotificationCenter.default.addObserver(self, selector: #selector(CreateGroupViewController.keyboardWillShow), name: NSNotification.Name.UIKeyboardWillShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(CreateGroupViewController.keyboardWillHide), name: NSNotification.Name.UIKeyboardWillHide, object: nil)
        
        createGroup.layer.cornerRadius = 22
        createGroup.clipsToBounds = true
        
        groupName.layer.cornerRadius = 22
        groupName.clipsToBounds = true
        groupName.delegate = self
        
        createGroupBG.layer.cornerRadius = 20
        createGroupBG.layer.masksToBounds = false
        createGroupBG.clipsToBounds = true

        profilePicture.image = UIImage(named: "avatar")
        
        
        let spacerView = UIView(frame:CGRect(x:0, y:0, width:25, height:10))
        groupName.leftViewMode = UITextFieldViewMode.always
        groupName.leftView = spacerView

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func keyboardWillShow(notification: NSNotification) {
        
        if let keyboardSize = (notification.userInfo?[UIKeyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue {
            if self.view.frame.origin.y == 0{
                self.view.frame.origin.y -= keyboardSize.height
            }
        }
        
    }
    
    func keyboardWillHide(notification: NSNotification) {
        if let keyboardSize = (notification.userInfo?[UIKeyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue {
            if self.view.frame.origin.y != 0{
                self.view.frame.origin.y += keyboardSize.height
            }
        }
    }
    
    //MARK: UITextFieldDelegate
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        // Hide the keyboard.
        textField.resignFirstResponder()
        return true
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    


}
