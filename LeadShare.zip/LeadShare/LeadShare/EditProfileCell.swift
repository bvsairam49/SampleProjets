//
//  EditProfileCell.swift
//  LeadShare
//
//  Created by Srinivas Yeruva on 17/03/17.
//  Copyright © 2017 Srinivas Yeruva. All rights reserved.
//

import UIKit

class EditProfileCell: UITableViewCell, UITextFieldDelegate {
   
    @IBOutlet weak var icon: UIImageView!
    @IBOutlet weak var name: UITextField!
   
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        name.delegate = self
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    
    //MARK: UITextFieldDelegate
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        // Hide the keyboard.
        textField.resignFirstResponder()
        return true
    }
    

}
