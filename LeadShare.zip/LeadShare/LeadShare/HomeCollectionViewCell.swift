//
//  HomeCollectionViewCell.swift
//  LeadShare
//
//  Created by Srinivas Yeruva on 16/03/17.
//  Copyright © 2017 Srinivas Yeruva. All rights reserved.
//

import UIKit

class HomeCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var title: UILabel!
    @IBOutlet weak var background: UIImageView!
}
