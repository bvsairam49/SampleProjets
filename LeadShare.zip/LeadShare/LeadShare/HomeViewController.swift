//
//  HomeViewController.swift
//  LeadShare
//
//  Created by Srinivas Yeruva on 15/03/17.
//  Copyright © 2017 Srinivas Yeruva. All rights reserved.
//

import UIKit

private let reuseIdentifier = "Cell"
class HomeViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {

    @IBOutlet weak var HomeCollectionView: UICollectionView!
    
    
    var labels = ["MESSAGES", "MEETINGS", "GROUPS", "LEADS", "PROFILE", "SETTINGS"]
    var bg = UIImage(named: "grid")
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        HomeCollectionView.dataSource = self

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func numberOfSectionsInCollectionView(collectionView: UICollectionView) -> Int {
        //#warning Incomplete method implementation -- Return the number of sections
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        //#warning Incomplete method implementation -- Return the number of items in the section
        return labels.count
    }
    
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: reuseIdentifier, for: indexPath as IndexPath) as! HomeCollectionViewCell
        
        cell.title.text = labels[indexPath.row]
        cell.background.image = bg
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        let cell : UICollectionViewCell = collectionView.cellForItem(at: indexPath)!
        performSegue(withIdentifier: "ProfileViewController", sender: cell)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
