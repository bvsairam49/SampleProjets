//
//  NewLeadController.swift
//  LeadShare
//
//  Created by Srinivas Yeruva on 22/03/17.
//  Copyright © 2017 Srinivas Yeruva. All rights reserved.
//

import UIKit

class NewLeadController: UIViewController, UITextFieldDelegate, UITextViewDelegate {
    
    @IBOutlet weak var LeadName: UITextField!
    @IBOutlet weak var BusinessType: UITextField!
    @IBOutlet weak var Contact: UITextField!
    @IBOutlet weak var Email: UITextField!
    @IBOutlet weak var Description: UITextView!
    

    override func viewDidLoad() {
        super.viewDidLoad()

        Description.delegate = self
        LeadName.delegate = self
        BusinessType.delegate = self
        Contact.delegate = self
        Email.delegate = self
        
        let borderColor = UIColor(red: 204.0/255.0, green: 204.0/255.0, blue: 204.0/255.0, alpha: 1.0)
        
        Description.layer.borderColor = borderColor.cgColor;
        Description.layer.borderWidth = 0.5;
        Description.layer.cornerRadius = 5.0;
        
        
        if (Description.text == "") {
            textViewDidEndEditing(Description)
        }
        let tapDismiss = UITapGestureRecognizer(target: self, action: #selector(NewLeadController.dismissKeyboard))
        self.view.addGestureRecognizer(tapDismiss)
    }

    func dismissKeyboard(){
        LeadName.resignFirstResponder()
        BusinessType.resignFirstResponder()
        Contact.resignFirstResponder()
        Email.resignFirstResponder()
        Description.resignFirstResponder()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func textViewDidEndEditing(_ textView: UITextView) {
        if (textView.text == "") {
            textView.text = "Description"
            textView.textColor = UIColor(red: 197.0/255.0, green: 197.0/255.0, blue: 203.0/255.0, alpha: 1.0)
        }
        textView.resignFirstResponder()
    }
    
    func textViewDidBeginEditing(_ textView: UITextView){
        if (textView.text == "Description"){
            textView.text = ""
            textView.textColor = UIColor.black
        }
        textView.becomeFirstResponder()
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
