//
//  ProfileEditViewController.swift
//  LeadShare
//
//  Created by Srinivas Yeruva on 17/03/17.
//  Copyright © 2017 Srinivas Yeruva. All rights reserved.
//

import UIKit
import os.log

private let reuseIdentifier = "EditCell"

class ProfileEditViewController: UIViewController,  UIImagePickerControllerDelegate, UINavigationControllerDelegate, UITableViewDataSource, UITableViewDelegate {

    @IBOutlet weak var profile: UIImageView!
    @IBOutlet weak var editDetails: UITableView!

    
    
    var details = ["2-(326)994-4782", "lisahaydon@gmail.com", "Ryan Road, Ashburn, VA", "(070) 412 3456", "Param Solutions", "100", "www.param-solutions.com", "120 USD"]
    var icons = [UIImage(named: "phone_icon"), UIImage(named: "email_icon"), UIImage(named: "location_icon"), UIImage(named: "fax_icon"), UIImage(named: "office_icon"), UIImage(named: "users_icon"), UIImage(named: "website_icon"), UIImage(named: "price_icon")]

    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        editDetails.dataSource = self
        
        profile.layer.borderWidth = 0
        profile.layer.masksToBounds = false
        profile.layer.cornerRadius = profile.frame.height/2
        profile.clipsToBounds = true

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    //MARK: UIImagePickerControllerDelegate
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        // Dismiss the picker if the user canceled.
        dismiss(animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        // The info dictionary may contain multiple representations of the image. You want to use the original.
        guard let selectedImage = info[UIImagePickerControllerOriginalImage] as? UIImage else {
            fatalError("Expected a dictionary containing an image, but was provided the following: \(info)")
        }
        
        // Set photoImageView to display the selected image.
        profile.image = selectedImage
        
        // Dismiss the picker.
        dismiss(animated: true, completion: nil)
    }

    
    @IBAction func selectImageFromPhotoLibrary(_ sender: UITapGestureRecognizer) {
        
        // UIImagePickerController is a view controller that lets a user pick media from their photo library.
        let imagePickerController = UIImagePickerController()
        
        // Only allow photos to be picked, not taken.
        imagePickerController.sourceType = .photoLibrary
        
        // Make sure ViewController is notified when the user picks an image.
        imagePickerController.delegate = self
        present(imagePickerController, animated: true, completion: nil)
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return details.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: reuseIdentifier, for: indexPath) as! EditProfileCell
        cell.icon.image = icons[indexPath.row]
        cell.name.text = details[indexPath.row]
        return cell
    }

 

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
