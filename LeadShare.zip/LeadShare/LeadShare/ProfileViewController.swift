//
//  ProfileViewController.swift
//  LeadShare
//
//  Created by Srinivas Yeruva on 16/03/17.
//  Copyright © 2017 Srinivas Yeruva. All rights reserved.
//

import UIKit

private let reuseIdentifier = "ProfileViewCell"
class ProfileViewController: UIViewController , UITableViewDataSource, UITableViewDelegate{

 
    @IBOutlet weak var profileTableView: UITableView!
    
    
    var details = ["2-(326)994-4782", "lisahaydon@gmail.com", "Ryan Road, Ashburn, VA", "(070) 412 3456", "Param Solutions", "100", "www.param-solutions.com", "120 USD"]
    var icons = [UIImage(named: "phone_icon"), UIImage(named: "email_icon"), UIImage(named: "location_icon"), UIImage(named: "fax_icon"), UIImage(named: "office_icon"), UIImage(named: "users_icon"), UIImage(named: "website_icon"), UIImage(named: "price_icon")]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        profileTableView.dataSource = self
        
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return details.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: reuseIdentifier, for: indexPath) as! ProfileDetailCell
        cell.icon.image = icons[indexPath.row]
        cell.name.text = details[indexPath.row]
        return cell
    }
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */

}
