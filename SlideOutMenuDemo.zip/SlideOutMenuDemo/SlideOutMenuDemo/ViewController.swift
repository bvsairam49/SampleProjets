//
//  ViewController.swift
//  SlideOutMenuDemo
//
//  Created by pavani divyasree on 26/04/17.
//  Copyright © 2017 pavani divyasree. All rights reserved.
//

import UIKit
class ViewController: UIViewController {

    @IBOutlet weak var sideMenuBtn: UIBarButtonItem!
       override func viewDidLoad() {
        super.viewDidLoad()
       sideMenu()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    func sideMenu(){
        
        
        if revealViewController() != nil{
            
            self.sideMenuBtn.target = revealViewController()
            self.sideMenuBtn.action = #selector(SWRevealViewController.revealToggle(_:))
            revealViewController().rearViewRevealWidth = 275
            
            view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
        }

    


    }
}
