//
//  TKSwitcherCollection.h
//  TKSwitcherCollection
//
//  Created by Tbxark on 8/5/16.
//  Copyright © 2016 TBXark. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for TKSwitcherCollection.
FOUNDATION_EXPORT double TKSwitcherCollectionVersionNumber;

//! Project version string for TKSwitcherCollection.
FOUNDATION_EXPORT const unsigned char TKSwitcherCollectionVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TKSwitcherCollection/PublicHeader.h>


