//
//  CameraManager.h
//  CameraManager
//
//  Created by Lex Tang on 4/9/15.
//  Copyright (c) 2015 imaginaryCloud. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for CameraManager.
FOUNDATION_EXPORT double CameraManagerVersionNumber;

//! Project version string for CameraManager.
FOUNDATION_EXPORT const unsigned char CameraManagerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CameraManager/PublicHeader.h>


