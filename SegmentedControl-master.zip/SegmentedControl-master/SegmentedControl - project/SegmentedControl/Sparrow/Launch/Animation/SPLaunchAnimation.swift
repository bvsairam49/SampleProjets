//
//  SPLaunchAnimation.swift
//  TwitterLaunchingAnimation
//
//  Created by Ivan Vorobei on 10/10/16.
//  Copyright © 2016 Ivan Vorobei. All rights reserved.
//

import UIKit

struct SPLaunchAnimation {

}
