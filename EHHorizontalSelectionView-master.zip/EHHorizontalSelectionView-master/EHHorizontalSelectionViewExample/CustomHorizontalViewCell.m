//
//  CustomHorizontalViewCell.m
//  EHHorizontalSelectionView
//
//  Created by Danila Gusev on 10/10/2016.
//  Copyright © 2016 josshad. All rights reserved.
//

#import "CustomHorizontalViewCell.h"

@implementation CustomHorizontalViewCell


@end
