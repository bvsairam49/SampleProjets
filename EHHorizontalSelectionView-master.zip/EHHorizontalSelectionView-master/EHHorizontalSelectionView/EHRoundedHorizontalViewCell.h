//
//  PinkHorizontalViewCell.h
//  TvRemote
//
//  Created by Danila Gusev on 01/03/2016.
//  Copyright © 2016 com.abrt. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "EHHorizontalLineViewCell.h"

@interface EHRoundedHorizontalViewCell : EHHorizontalLineViewCell

@end
