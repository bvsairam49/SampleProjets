## Version 1.1.0
* cell customizing via 
	- (EHHorizontalViewCell * _Nullable)selectionView:(EHHorizontalSelectionView * _Nonnull)selectionView cellForItemAtIndexPath:(NSIndexPath * _Nonnull)indexPath;

### Version 1.0.4
* xib in podspec fix

### Version 1.0.3
* text color customization

### Version 1.0.2
* fix issues

## Version 1.0.0
* updated documentation

### Version 0.9.4
* Fix shadow color issue


### Version 0.9.3
* Fix example project structure

### Version 0.9.3
* Customization for chosen selection view
* Documentation

### Version 0.9.1
* Added pods

## Version 0.9

* Initial version
* 3 default cell styles for selection view
* colors, fonts customisation
* support custom cell via "-registerCellWithClass:" and "registerCellNib:withClass:" methods