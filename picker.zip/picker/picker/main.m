//
//  main.m
//  picker
//
//  Created by anusha sabari on 3/31/17.
//  Copyright © 2017 sabarianusabari. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
