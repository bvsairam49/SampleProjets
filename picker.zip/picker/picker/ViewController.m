//
//  ViewController.m
//  picker
//
//  Created by anusha sabari on 3/31/17.
//  Copyright © 2017 sabarianusabari. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    {
        [super viewDidLoad];
        // Do any additional setup after loading the view, typically from a nib.
        self.cities = [NSArray  arrayWithObjects: @"Blue",@"Green",@"Orange",@"Purple",@"Red",@"Yellow" , nil];
    }
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 1;
    
}

// returns the # of rows in each component..
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent: (NSInteger)component
{
    return 6;
    
}
-(NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row   forComponent:(NSInteger)component
{
    
    return [self.cities objectAtIndex:row];
    
}



@end
