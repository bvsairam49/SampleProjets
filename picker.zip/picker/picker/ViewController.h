//
//  ViewController.h
//  picker
//
//  Created by anusha sabari on 3/31/17.
//  Copyright © 2017 sabarianusabari. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UIPickerViewDelegate,UIPickerViewDataSource>

@property (weak, nonatomic) IBOutlet UIPickerView *picker;
@property(weak,nonatomic)NSArray*cities;
@end

