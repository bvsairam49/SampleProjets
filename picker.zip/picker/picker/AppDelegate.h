//
//  AppDelegate.h
//  picker
//
//  Created by anusha sabari on 3/31/17.
//  Copyright © 2017 sabarianusabari. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

