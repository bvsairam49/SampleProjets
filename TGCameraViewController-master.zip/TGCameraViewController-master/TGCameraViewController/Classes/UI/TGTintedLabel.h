//
//  TGTintedLabel.h
//  TGCameraViewController
//
//  Created by Mike Sprague on 3/30/15.
//  Copyright (c) 2015 Tudo Gostoso Internet. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TGTintedLabel : UILabel

@end
