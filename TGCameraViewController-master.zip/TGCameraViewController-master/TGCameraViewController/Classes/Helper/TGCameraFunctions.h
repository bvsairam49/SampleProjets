//
//  TGCameraFunctions.h
//  TGCameraViewController
//
//  Created by Bruno Furtado on 27/05/15.
//  Copyright (c) 2015 Tudo Gostoso Internet. All rights reserved.
//

NSString *TGLocalizedString(NSString* key);