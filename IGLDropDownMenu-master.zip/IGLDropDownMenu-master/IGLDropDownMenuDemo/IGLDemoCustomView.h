//
//  IGLDemoCustomView.h
//  IGLDropDownMenuDemo
//
//  Created by Galvin Li on 2016-02-08.
//  Copyright © 2016 Galvin Li. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface IGLDemoCustomView : UIView

@property (nonatomic, strong) UIImage *image;
@property (nonatomic, strong) NSString *title;

@end
