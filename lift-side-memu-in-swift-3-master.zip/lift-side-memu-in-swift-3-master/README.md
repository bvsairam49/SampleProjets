# lift-side-memu-in-swift-3
Lift Slide Out Menu (Swift 3 in Xcode 8 : SWRevealViewController)
