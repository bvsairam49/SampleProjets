//
//  Post+CoreDataClass.swift
//  
//
//  Created by Amit Shekhar on 19/02/17.
//
//

import Foundation
import CoreData


public class Post: NSManagedObject {
    
}
