//
//  WhiteSectionHeaderView.swift
//  JTAppleCalendar
//
//  Created by JayT on 2016-05-16.
//  Copyright © 2016 CocoaPods. All rights reserved.
//
import JTAppleCalendar

class WhiteSectionHeaderView: JTAppleCollectionReusableView {
    @IBOutlet weak var title: UILabel!
}
