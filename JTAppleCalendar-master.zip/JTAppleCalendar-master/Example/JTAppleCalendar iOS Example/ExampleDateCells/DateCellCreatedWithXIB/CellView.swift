//
//  CellView.swift
//  testApplicationCalendar
//
//  Created by JayT on 2016-03-04.
//  Copyright © 2016 OS-Tech. All rights reserved.
//


import JTAppleCalendar

class CellView: JTAppleCell {
    @IBOutlet var selectedView: AnimationView!
    @IBOutlet var dayLabel: UILabel!
}
