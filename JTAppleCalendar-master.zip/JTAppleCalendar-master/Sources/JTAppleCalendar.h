//
//  JTAppleCalendar iOS.h
//  JTAppleCalendar iOS
//
//  Created by JayT on 2016-08-10.
//
//

#import <UIKit/UIKit.h>

//! Project version number for JTAppleCalendar iOS.
FOUNDATION_EXPORT double JTAppleCalendarVersionNumber;

//! Project version string for JTAppleCalendar iOS.
FOUNDATION_EXPORT const unsigned char JTAppleCalendarVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <JTAppleCalendar_iOS/PublicHeader.h>


