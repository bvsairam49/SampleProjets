//
//  CustomizedStyleCell.h
//  JTMaterialSwitch
//
//  Created by Junichi Tsurukawa on 2015/10/03.
//  Copyright 2015 Junichi Tsurukawa. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomizedStyleCell : UITableViewCell

@end
