//
//  AppDelegate.m
//  AESENCRYPT
//
//  Created by Anandh on 12/7/16.
//  Copyright © 2016 Jagadeesh. All rights reserved.
//

#import "AppDelegate.h"
#import "NSData+CommonCrypto.h"

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    
    //dataEncryptedUsingAlgorithm: (CCAlgorithm) algorithm
    //key: (id) key
    //initializationVector: (id) iv
    //options: (CCOptions) options
    //error: (CCCryptorStatus *) error
    
    NSString *key=@"thisissecretkey!";
    NSString *iVStr=@"thisissecretkey!";
    //    NSError *error;
    NSData *toencrypt = [@"Hello How Are you" dataUsingEncoding:NSUTF8StringEncoding];
    NSData *encrypted = [toencrypt dataEncryptedUsingAlgorithm:kCCAlgorithmAES128 key:key initializationVector:iVStr options:kCCOptionPKCS7Padding error:nil];
    NSString *encrptedString = [encrypted  base64EncodedStringWithOptions:0];
    
    NSData *decryptedData=[encrypted decryptedDataUsingAlgorithm:kCCAlgorithmAES128 key:key initializationVector:iVStr options:kCCOptionPKCS7Padding error:nil];
    NSString *strValues=[[NSString alloc]initWithData:decryptedData encoding:NSUTF8StringEncoding];
    NSLog(@"Encrypted String : %@,%@",encrptedString,strValues);
    
    return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
