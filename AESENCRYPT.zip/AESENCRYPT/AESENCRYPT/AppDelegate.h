//
//  AppDelegate.h
//  AESENCRYPT
//
//  Created by Anandh on 12/7/16.
//  Copyright © 2016 Jagadeesh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

