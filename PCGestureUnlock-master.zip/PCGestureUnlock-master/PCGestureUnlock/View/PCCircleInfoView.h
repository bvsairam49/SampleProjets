
#import <UIKit/UIKit.h>

@interface PCCircleInfoView : UIView

@end
