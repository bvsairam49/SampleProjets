
#import <UIKit/UIKit.h>

@interface GestureVerifyViewController : UIViewController

@property (nonatomic, assign) BOOL isToSetNewGesture;

@end
