# SideMenuSwiftDemo
SideMenu in Swift with autolayout


![alt tag](https://cloud.githubusercontent.com/assets/6309880/16975978/023394fa-4e69-11e6-9219-88c98bcd0883.png)

We have implement this feature in many of our developed apps, look at the apps details on our company website http://www.spaceotechnologies.com
