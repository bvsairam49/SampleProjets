//
//  ViewController1.swift
//  DateTimePickerViewDemo
//
//  Created by pavani divyasree on 10/05/17.
//  Copyright © 2017 pavani divyasree. All rights reserved.
//

import UIKit

class ViewController1: UIViewController {

    var time = Timer()
    
    @IBOutlet weak var dateTF: UITextField!
    @IBOutlet weak var timeTF: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

//        time = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(ViewController1.datePickerValueChanged(sender:)), userInfo: nil, repeats: true)
//        
        
       let datePicker = UIDatePicker()
        datePicker.datePickerMode = UIDatePickerMode.date
        datePicker.addTarget(self, action: #selector(ViewController1.datePickerValueChanged(sender:)), for: UIControlEvents.valueChanged)
        
        dateTF.inputView = datePicker
        timeTF.inputView = datePicker
        
        let toolbar = UIToolbar(frame: CGRect( x: 0, y: 0, width:self.view.frame.size.width, height:40))
       
        toolbar.barStyle = UIBarStyle.blackTranslucent
        toolbar.tintColor = UIColor.white
        
        let todayButton = UIBarButtonItem(title: "Today", style: UIBarButtonItemStyle.plain, target: self, action: #selector(ViewController1.todayPressed(sender:)))
        
        let doneButton = UIBarButtonItem (barButtonSystemItem: UIBarButtonSystemItem.done,target: self, action: #selector(ViewController1.donePressed(sender: )))
        
        let flexButton = UIBarButtonItem (barButtonSystemItem: UIBarButtonSystemItem.flexibleSpace ,target: self, action: nil)
        
        let label = UILabel(frame: CGRect( x: 0, y: 0, width:self.view.frame.size.width/3, height:40))
        label.font = UIFont.systemFont(ofSize: 14)
        label.textColor = UIColor.white
        label.textAlignment = NSTextAlignment.center
        label.text = "Select a Date"

    
        let labelButton = UIBarButtonItem(customView: label)
        toolbar.setItems([todayButton,flexButton,doneButton], animated: true)
        dateTF.inputAccessoryView = toolbar
        timeTF.inputAccessoryView = toolbar

        
    }

    func donePressed(sender: UIBarButtonItem){
        dateTF.resignFirstResponder()
        timeTF.resignFirstResponder()
        
    }
    func todayPressed(sender: UIBarButtonItem){
        let date = DateFormatter()
        let time = DateFormatter()
        date.dateStyle = DateFormatter.Style.medium
        time.timeStyle = DateFormatter.Style.medium
        
        dateTF.text = date.string(from: NSDate()as Date)
        dateTF.resignFirstResponder()
        timeTF.text = time.string(from: NSDate()as Date)
        timeTF.resignFirstResponder()

    }
    
    func datePickerValueChanged(sender: UIDatePicker){
        
        let formatter = DateFormatter()
        formatter.dateStyle = DateFormatter.Style.medium
        formatter.timeStyle = DateFormatter.Style.medium
        dateTF.text = formatter.string(from: sender.date)
        formatter.dateFormat = "HH:mm"
}
    
    
    
//    func didFireTimer(timer: Timer) {
//        timeTF.text = formatter.stringFromDate(NSDate(), toDate: datePicker.date)
//    }
//    
    
 
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        view.endEditing(true)
    }
    

    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}
