//
//  ViewController.swift
//  DateTimePickerViewDemo
//
//  Created by pavani divyasree on 10/05/17.
//  Copyright © 2017 pavani divyasree. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var dateLbl: UILabel!
    
    @IBOutlet weak var timeLbl: UILabel!
    
    @IBOutlet weak var datePickerView: UIDatePicker!
    
    @IBOutlet weak var timePickerView: UIDatePicker!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    
    
    @IBAction func dateBtnTapped(_ sender: Any) {
        
        
        
              
                let dateFormatter = DateFormatter()
                dateFormatter.dateFormat = "dd-MM-yyyy"
                let strDate = dateFormatter.string(from: datePickerView.date)
                self.dateLbl.text = strDate
        

    }
    
    @IBAction func timeBtnTapped(_ sender: Any) {
        
                let dateFormatter = DateFormatter()
                dateFormatter.dateFormat = "HH:mm"
                let strDate = dateFormatter.string(from: timePickerView.date)
                self.timeLbl.text = strDate
        

        
    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

