//
//  feedbackHistoryTableViewCell.swift
//  MobileBinaryOptions
//
//  Created by Gourav jaiswal on 13/02/17.
//  Copyright © 2017 Broctagon. All rights reserved.
//

import UIKit

class feedbackHistoryTableViewCell: UITableViewCell {
    
    let tblHeadinLabel = UILabel()
    let SubHeadingLabel = UILabel()
       var respond = UILabel()
   
    
   
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        self.createUI()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    func createUI() {
        
    
        

        self.contentView.layer.borderWidth = 2.0
        self.contentView.layer.borderColor = UIColor.white.cgColor
        self.contentView.layer.opacity = 1.0
        
        self.contentView.layer.cornerRadius = 4.0
        self.contentView.backgroundColor = UIColor.clear
       self.backgroundColor = .clear
        
        self.tblHeadinLabel.frame = CGRect(x:(SCREEN_WIDTH() * 6/100), y:-5, width: SCREEN_WIDTH(), height: 44)
        //self.tblHeadinLabel.textColor = UIColor.white
        //self.tblHeadinLabel.textAlignment = .center
        self.tblHeadinLabel.font = UIFont.systemFont(ofSize: 13)
        self.tblHeadinLabel.lineBreakMode = NSLineBreakMode.byWordWrapping
        self.tblHeadinLabel.numberOfLines = 0
        self.contentView.addSubview(self.tblHeadinLabel)
        
        
        self.SubHeadingLabel.frame = CGRect(x:(SCREEN_WIDTH() * 6/100), y:35, width: SCREEN_WIDTH(), height: 44)
        self.SubHeadingLabel.textColor = UIColor.white
        //self.SubHeadingLabel.textAlignment = .center
        self.SubHeadingLabel.font = UIFont.systemFont(ofSize: 0)
        self.SubHeadingLabel.lineBreakMode = NSLineBreakMode.byWordWrapping
        self.SubHeadingLabel.numberOfLines = 0
        self.contentView.addSubview(self.SubHeadingLabel)
        
        self.respond = UILabel(frame: CGRect(x:(SCREEN_WIDTH() * 22/100), y:35, width: SCREEN_WIDTH(), height: 44))
        self.respond .textColor = UIColor(red:160/255, green:23/255, blue:51/255, alpha:1.0)
        self.respond.textAlignment = .center
        self.respond.font = UIFont.systemFont(ofSize: 13)
        self.respond.lineBreakMode = NSLineBreakMode.byWordWrapping
        self.contentView.addSubview(respond)
        
        
        
               

        
//        
//        self.tblOrderNumberLabel.frame = CGRect(x:(SCREEN_WIDTH() * -43/100), y:-5, width: SCREEN_WIDTH(), height: 44)
//        self.tblOrderNumberLabel.textColor = UIColor.white
//        self.tblOrderNumberLabel.textAlignment = .center
//        self.tblOrderNumberLabel.font = UIFont.systemFont(ofSize: 10)
//        self.tblOrderNumberLabel.lineBreakMode = NSLineBreakMode.byWordWrapping
//        self.tblOrderNumberLabel.numberOfLines = 0
        //self.contentView.addSubview(self.tblHeadinLabel)
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
