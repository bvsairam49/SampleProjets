//
//  OhlcSeriesDataView.h
//  SciChart
//
//  Created by Admin on 15.02.16.
//  Copyright © 2016 SciChart Ltd. All rights reserved.
//

/** \addtogroup SeriesInfo
 *  @{
 */

#import <Foundation/Foundation.h>
#import "SCIXySeriesDataView.h"

@interface SCIOhlcSeriesDataView : SCIXySeriesDataView

@end

/** @}*/
