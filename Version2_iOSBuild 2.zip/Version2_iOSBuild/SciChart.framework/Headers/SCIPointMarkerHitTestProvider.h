//
//  PointMarkerHitTest.h
//  SciChart
//
//  Created by Admin on 03.12.15.
//  Copyright © 2015 SciChart Ltd. All rights reserved.
//

/** \addtogroup HitTest
 *  @{
 */

#import <Foundation/Foundation.h>
#import "SCIHitTestProviderBase.h"

@interface SCIPointMarkerHitTestProvider : SCIHitTestProviderBase

@end

/** @}*/
