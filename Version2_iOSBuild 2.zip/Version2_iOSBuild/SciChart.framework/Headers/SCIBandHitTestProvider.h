//
//  BandHitTestProvider.h
//  SciChart
//
//  Created by Admin on 18.02.16.
//  Copyright © 2016 SciChart Ltd. All rights reserved.
//

/** \addtogroup HitTest
 *  @{
 */

#import <Foundation/Foundation.h>
#import "SCIHitTestProviderBase.h"

@interface SCIBandHitTestProvider : SCIHitTestProviderBase

@end

/** @}*/
