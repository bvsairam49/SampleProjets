//
//  UserDefinedDistributionCalculator.h
//  SciChart
//
//  Created by Admin on 07.09.15.
//  Copyright (c) 2015 SciChart Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SCIDataDistributionCalculatorBase.h"

@interface SCIUserDefinedDistributionCalculator : SCIDataDistributionCalculatorBase

@end
