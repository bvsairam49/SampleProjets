//
//  LineSeriesInfo.h
//  SciChart
//
//  Created by Admin on 08.12.15.
//  Copyright © 2015 SciChart Ltd. All rights reserved.
//

/** \addtogroup SeriesInfo
 *  @{
 */

#import <Foundation/Foundation.h>
#import "SCISeriesInfo.h"

@interface SCIXySeriesInfo : SCISeriesInfo

@end

/** @}*/
