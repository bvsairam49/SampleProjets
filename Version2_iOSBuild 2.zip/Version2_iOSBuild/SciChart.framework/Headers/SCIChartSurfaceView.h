//
//  SciChartSurfaceView.h
//  SciChart
//
//  Created by Admin on 16.02.16.
//  Copyright © 2016 SciChart Ltd. All rights reserved.
//

/** \addtogroup Visuals
 *  @{
 */

#import <Foundation/Foundation.h>
#import "SCIChartSurfaceViewBase.h"

@interface SCIChartSurfaceView : SCIChartSurfaceViewBase

@end

/** @}*/
