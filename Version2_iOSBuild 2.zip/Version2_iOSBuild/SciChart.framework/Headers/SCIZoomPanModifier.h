//
//  SCIZoomPanModifier.h
//  SciChart
//
//  Created by Admin on 11.08.15.
//  Copyright (c) 2015 SciChart Ltd. All rights reserved.
//

/** \addtogroup ChartModifiers
 *  @{
 */

#import <Foundation/Foundation.h>
#import "SCIZoomPanModifierBase.h"

@interface SCIZoomPanModifier : SCIZoomPanModifierBase

@end

/** @}*/
