//
//  SCICategoryNumericAxis.h
//  SciChart
//
//  Created by Hrybenuik Mykola on 7/10/16.
//  Copyright © 2016 SciChart. All rights reserved.
//

/** \addtogroup Axis
 *  @{
 */

#import <SciChart/SciChart.h>

@interface SCICategoryNumericAxis : SCINumericAxis

@end

/** @}*/
