//
//  SCICategoryDateTimeAxis.h
//  SciChart
//
//  Created by Mykola Hrybeniuk on 7/13/16.
//  Copyright © 2016 SciChart. All rights reserved.
//

/** \addtogroup Axis
 *  @{
 */

#import <SciChart/SciChart.h>

@interface SCICategoryDateTimeAxis : SCIDateTimeAxis

@end

/** @}*/
