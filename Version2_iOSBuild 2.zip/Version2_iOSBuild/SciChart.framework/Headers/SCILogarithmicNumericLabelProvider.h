//
//  LogarithmicNumericLabelProvider.h
//  SciChart
//
//  Created by Admin on 19.01.16.
//  Copyright © 2016 SciChart Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SCINumericLabelProvider.h"

@interface SCILogarithmicNumericLabelProvider : SCINumericLabelProvider

@end
