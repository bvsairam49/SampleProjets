//
//  CandlestickHitTestProvider.h
//  SciChart
//
//  Created by Admin on 22.12.15.
//  Copyright © 2015 SciChart Ltd. All rights reserved.
//

/** \addtogroup HitTest
 *  @{
 */

#import <Foundation/Foundation.h>
#import "SCIHitTestProviderBase.h"

@interface SCICandlestickHitTestProvider : SCIHitTestProviderBase

@end

/** @}*/
