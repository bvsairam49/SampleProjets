//
//  SCINumericDeltaCalculator.h
//  SciChart
//
//  Created by Admin on 21.07.15.
//  Copyright (c) 2015 SciChart Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SCINumericDeltaCalculatorBase.h"

@interface SCINumericDeltaCalculator : SCINumericDeltaCalculatorBase

+(SCINumericDeltaCalculatorBase*) instance;

@end
