//
//  BaseVC.swift
//  MobileBinaryOptions
//
//  Created by GE on 17/1/16.
//  Copyright © 2017年 pc003. All rights reserved.
//

import UIKit

class BaseVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.view.backgroundColor = .white
        
        NotificationCenter.default.addObserver(self, selector: #selector(didLanguageChanged), name: NSNotification.Name(rawValue: kLanguageDidChangeNotification), object: nil)
    }
    
    /// add customALertView to self.view
    func showAlertVC(alertView: CustomAlertView) {
        self.view.addSubview(alertView)
        alertView.snp.makeConstraints { (make) in
            make.edges.equalTo(self.view)
        }
    }
    
    /// invoke when language changed
    func didLanguageChanged() {
        
    }
    
    /// hidden StatusBar
    override var prefersStatusBarHidden: Bool {
        return true
    }
    
    // MARK: - deinit
    
    deinit {
        NotificationCenter.default.removeObserver(self)
        print(NSStringFromClass(self.classForCoder) + " had deinit")
        
        self.destroyEvents()
    }
    
    /// destroy events when class deinit
    func destroyEvents() {
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
