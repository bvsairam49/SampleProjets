//
//  BaseTableView.swift
//  MobileBinaryOptions
//
//  Created by GE on 17/2/8.
//  Copyright © 2017年 Broctagon. All rights reserved.
//

import UIKit

class BaseTableView: UITableView {

    // a backgroung image view bigger than self
    var bigBackgroundImgView: UIImageView?

}
