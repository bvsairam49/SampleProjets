//
//  BaseBtn.swift
//  MobileBinaryOptions
//
//  Created by GE on 17/1/17.
//  Copyright © 2017年 pc003. All rights reserved.
//

import UIKit

class BaseBtn: UIButton {
    
    var tagName = ""

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
