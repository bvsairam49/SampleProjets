//
//  PopUpVC.swift
//  MobileBinaryOptions
//
//  The vc has naviBar like alertVC, and the background image is "bg2.png"
//
//  Created by GE on 17/2/14.
//  Copyright © 2017年 Broctagon. All rights reserved.
//

import UIKit

class PopUpVC: BaseVC {
    
    let headerView = UIView()
    let titleLb = UILabel()
    let cancelBtn = BaseBtn()
    
    let contentView = UIView()
    
    required init(title: String) {
        super.init(nibName: nil, bundle: nil)
        self.title = title
        self.createUI()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func createUI() {
        self.view.backgroundColor = .black
        self.createHeaderView()
        self.createContentView()
    }
    
    func createHeaderView() {
        self.headerView.backgroundColor = UIColor(patternImage: UIImage(named:"title_bg.png")!)
        self.view.addSubview(self.headerView)
        
        self.titleLb.textAlignment = .center
        self.titleLb.textColor = kColorTimeframeSelected()
        self.titleLb.font = FONT_CUSTOM(20.0)
        self.titleLb.text = self.title
        self.headerView.addSubview(self.titleLb)
        
        self.cancelBtn.setImage(UIImage(named: "close_icon.png"), for: .normal)
        self.cancelBtn.addTarget(self, action: #selector(dismissVC), for: .touchUpInside)
        self.headerView.addSubview(self.cancelBtn)
        
        self.headerView.snp.makeConstraints { (make) in
            make.left.right.top.equalTo(self.view)
            make.height.equalTo(44.0)
        }
        
        self.titleLb.snp.makeConstraints { (make) in
            make.centerX.centerY.equalTo(self.headerView)
        }
        
        self.cancelBtn.snp.makeConstraints { (make) in
            make.top.right.equalTo(self.headerView)
            make.width.height.equalTo(self.headerView.snp.height)
        }
    }
    
    func createContentView() {
        self.contentView.backgroundColor = UIColor(patternImage: UIImage(named:"bg1.png")!)
        self.view.addSubview(self.contentView)
        
        self.contentView.snp.makeConstraints { (make) in
            make.top.equalTo(self.headerView.snp.bottom).offset(1)
            make.left.right.bottom.equalTo(self.view)
        }
        
        self.createContentSubviews()
    }
    
    /// must be override
    func createContentSubviews() {
        
    }
    
    // MARK: - dismissVC
    
    func dismissVC() {
        if (self.navigationController?.viewControllers.count)! > 1 {
            let _ = self.navigationController?.popViewController(animated: true)
        }else {
            self.dismiss(animated: true, completion: nil)
        }
    }
    
    // MARK: - Device Orientation
    
    override var shouldAutorotate: Bool {
        return true
    }
    
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return .landscape
    }
}
