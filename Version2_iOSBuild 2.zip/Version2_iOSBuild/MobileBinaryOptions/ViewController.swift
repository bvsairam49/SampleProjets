//
//  ViewController.swift
//  MobileBinaryOptions
//
//  Created by ALOK KUMAR on 19/01/17.
//  Copyright © 2017 Broctagon. All rights reserved.
//

import UIKit
import SnapKit


class ViewController: UIViewController {
    var  myLabel : UILabel?


    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        // Code for Backgound imageview for Dashboard.... Starfish-Logo@3x
        let imageName = "bg@3x.png"
        let image = UIImage(named: imageName)
        let imageView = UIImageView(image: image!)
        self.view.addSubview(imageView)
        
        
        let WL_logo = "Starfish-Logo"
        let Wl_image = UIImage(named: WL_logo)
        let Wl_imageView = UIImageView(image: Wl_image!)
//        Wl_imageView.center = CGPoint(x: ((SCREEN_WIDTH()*45/100)+14), y :120)
        self.view.addSubview(Wl_imageView)
        Wl_imageView.snp.makeConstraints { (mack) in
            mack.top.equalTo(COMPUTE_LENGTH(230))
            mack.centerX.equalTo(self.view)
            mack.width.equalTo(COMPUTE_LENGTH(665))
            mack.height.equalTo(COMPUTE_LENGTH(211))
        }
    
        
        
        let lbl_version = UILabel.init()
//        let lbl_version = UILabel(frame: CGRect(x:((SCREEN_WIDTH()*10/100)+120), y: 20, width: 200, height: 21))
        //lbl_version.center = CGPoint(x: 300, y: 40)
        lbl_version.textAlignment = .center
        lbl_version.text = "Version:0.0.0"
        lbl_version.textColor = kColorTimeframeNormal()
        lbl_version.font = UIFont.systemFont(ofSize: 12)
        self.view.addSubview(lbl_version)
        lbl_version.snp.makeConstraints { (mack) in
            mack.top.equalTo(COMPUTE_LENGTH(50))
            mack.left.equalTo(self.view.snp.right).offset(-COMPUTE_LENGTH(300))
        }
        
        // * Lable for punchline
        let lbl_punchLine = UILabel()
        lbl_punchLine.text = "       Industry's first MT4 Binary\nOptions Mobile Trading Platform"
        lbl_punchLine.textColor = kColorTimeframeNormal()
        lbl_punchLine.font = UIFont.systemFont(ofSize: 15)
        lbl_punchLine.numberOfLines = 0
        self.view.addSubview(lbl_punchLine)
        lbl_punchLine.snp.makeConstraints { (mack) in
            mack.top.equalTo(Wl_imageView.snp.bottom).offset(COMPUTE_LENGTH(60))
            mack.centerX.equalTo(self.view)
            
        }
        
        
        let lbl_Online_User = UILabel.init()
//        if(SCREEN_WIDTH() <= 320)
//        {
//            lbl_Online_User = UILabel(frame: CGRect(x:((SCREEN_WIDTH()*10/100)+60), y: 230, width: 500, height: 40))
//        }
//        else{
//            lbl_Online_User = UILabel(frame: CGRect(x:((SCREEN_WIDTH()*10/100)+80), y: 230, width: 500, height: 40))
//        }
        //let lbl_Online_User = UILabel(frame: CGRect(x:(SCREEN_WIDTH()-260), y: 230, width: 500, height: 40))
        lbl_Online_User.text = "Online Mobile Phone Users"
        lbl_Online_User.textColor = UIColor.white
        lbl_Online_User.alpha = 0.5
        lbl_Online_User.font = UIFont(name:lbl_punchLine.font.fontName,size :12)
        lbl_Online_User.lineBreakMode = NSLineBreakMode.byWordWrapping
        lbl_Online_User.numberOfLines = 0
        //lbl_Online_User.adjustsFontSizeToFitWidth=true
        self.view.addSubview(lbl_Online_User)
        lbl_Online_User.snp.makeConstraints { (mack) in
            mack.top.equalTo(lbl_punchLine.snp.bottom).offset(COMPUTE_LENGTH(140))
            mack.centerX.equalTo(self.view)
        }
        
        
        
        let img_Btnlang = UIImage(named: "English") as UIImage?
        let btn_Lang = UIButton(frame: CGRect(x: 10 ,y:20, width: COMPUTE_LENGTH(180), height:COMPUTE_LENGTH(68)))
        btn_Lang.backgroundColor = UIColor.clear
        btn_Lang.titleLabel?.font = UIFont.systemFont(ofSize: 13)
        btn_Lang.setTitle(" EN", for: UIControlState.normal)
        // btn_Lang.setBackgroundImage(img_Btnlang, for: .normal)
        btn_Lang.setImage(img_Btnlang, for: .normal)
        
        self.view.addSubview(btn_Lang)
        // Need to put image on this
        
        btn_Lang.layer.cornerRadius = 2;
        btn_Lang.layer.borderWidth = 1;
        btn_Lang.layer.borderColor = kColorTimeframeNormal().cgColor
        
        // LoginButton Design
        
//        let img_Btnlogin = UIImage(named: "btn") as UIImage?
        let btnlogin = UIButton.init(type: .custom)
//        btnlogin.frame = CGRect (x:((SCREEN_WIDTH()*10/100)) ,y:270, width: (SCREEN_WIDTH()-60), height:50)
//        btnlogin.setBackgroundImage(img_Btnlogin, for: .normal)
        btnlogin.setTitle("Login", for: .normal)
        btnlogin.setTitleColor(kColorDouble(), for: .highlighted)
        btnlogin.setTitleColor(UIColor.white, for: .normal)
        btnlogin.setBackgroundImage(UIImage.init(named: "btn"), for: .normal)
        btnlogin.setBackgroundImage(UIImage.init(named: "btn_press"), for: .highlighted)
        btnlogin.addTarget(self, action: #selector(loginActivity(btn:)), for: .touchUpInside)
        self.view.addSubview(btnlogin)
        btnlogin.snp.makeConstraints { (mack) in
            mack.top.equalTo(lbl_Online_User.snp.bottom).offset(COMPUTE_LENGTH(85))
            mack.centerX.equalTo(self.view)
            
        }
        
        
        
        // Registration Design
//        let img_BtnRegistration = UIImage(named: "btn") as UIImage?
        let btnRegistration = UIButton.init(type: .custom)
            //        btnRegistration.frame = CGRect (x:((SCREEN_WIDTH()*10/100)) ,y:330, width: (SCREEN_WIDTH()-60), height:50)
//        btnRegistration.setBackgroundImage(img_BtnRegistration, for: .normal)
//        btnRegistration.addTarget(self, action: Selector("btnTouched1:"), for:.touchUpInside)
        btnRegistration.addTarget(self, action: #selector(registrationButtonAction(_:)), for: .touchUpInside)
        btnRegistration.setTitle("Registration", for:  UIControlState.normal)
        btnRegistration.setTitleColor(kColorDouble(), for: .highlighted)
        btnRegistration.setTitleColor(UIColor.white, for: .normal)
        btnRegistration.setBackgroundImage(UIImage.init(named: "btn"), for: .normal)
        btnRegistration.setBackgroundImage(UIImage.init(named: "btn_press"), for: .highlighted)

        self.view.addSubview(btnRegistration)
        btnRegistration.snp.makeConstraints { (mack) in
            mack.top.equalTo(btnlogin.snp.bottom).offset(COMPUTE_LENGTH(72))
            mack.centerX.equalTo(self.view)
        }

        
        
        let imgAdd = UIImageView.init()
        imgAdd.image = UIImage.init(named: "Ad settings_bg")
        self.view.addSubview(imgAdd)
        imgAdd.snp.makeConstraints { (mack) in
            mack.top.equalTo(btnRegistration.snp.bottom)
            mack.centerX.equalTo(self.view)
//            mack.width.equalTo(COMPUTE_LENGTH(677))
//            mack.height.equalTo(COMPUTE_LENGTH(123))
        }
        
        // Image of Registration information Add.......
        let lbl_add = UILabel.init()
        lbl_add.text = "Start trading with Just 20 USD"
        lbl_add.font = UIFont.systemFont(ofSize: 12)
        lbl_add.textColor = kColorTimeframeNormal()
        lbl_add.textAlignment = .center
        imgAdd.addSubview(lbl_add)
        lbl_add.snp.makeConstraints { (mack) in
            mack.top.equalTo(COMPUTE_LENGTH(65))
            mack.centerX.equalTo(imgAdd)
            
        }
        
//        let lbl_add = UILabel(frame: CGRect(x:((SCREEN_WIDTH()*45/100)-100), y: 380, width: 225, height: 50))
      //  lbl_add.center = CGPoint(x:((SCREEN_WIDTH()*45/100)+14), y: 435)
        
        //lbl_add.adjustsFontSizeToFitWidth=true
        
//        lbl_add.backgroundColor = UIColor(patternImage: UIImage(named:"Ad settings_bg@3x.png")!)
        
        
        
        // Player buttons
//        let img_BtnPlay = UIImage(named: "pay_icon@3x") as UIImage?
       
//        btnPlay.frame = CGRect (x: ((SCREEN_WIDTH()*45/100)-30), y: 410, width: 90, height: 90)
//        btnPlay.setImage(img_BtnPlay, for: .normal)
        //        btnlogin.addTarget(self, action: Selector("btnTouched:"), for:.touchUpInside)
        let btnPlay = UIButton(type: UIButtonType.custom) as UIButton
        btnPlay.setBackgroundImage(UIImage.init(named: "pay_icon"), for: .normal)
        self.view.addSubview(btnPlay)
        btnPlay.snp.makeConstraints { (mack) in
            mack.top.equalTo(imgAdd.snp.bottom).offset(COMPUTE_LENGTH(95))
            mack.centerX.equalTo(self.view)
            mack.width.equalTo(COMPUTE_LENGTH(102))
            mack.height.equalTo(COMPUTE_LENGTH(102))
        }
        
        
        // Trading info Lables.....
//        let lbl_TradeInfo = UILabel(frame: CGRect(x: ((SCREEN_WIDTH()*45/100)-40), y:470, width: 200, height: 40))
        let lbl_TradeInfo = UILabel.init()
        lbl_TradeInfo.text = "What are binary options\n and how do you trade it"
//        lbl_TradeInfo.adjustsFontSizeToFitWidth=true
        lbl_TradeInfo.textColor = kColorTimeframeNormal()
        lbl_TradeInfo.numberOfLines = 0
//        lbl_TradeInfo.lineBreakMode = NSLineBreakMode.byWordWrapping
        lbl_TradeInfo.font = UIFont(name:lbl_punchLine.font.fontName,size :13)
        self.view.addSubview(lbl_TradeInfo)
        lbl_TradeInfo.snp.makeConstraints { (mack) in
            mack.top.equalTo(btnPlay.snp.bottom).offset(COMPUTE_LENGTH(32))
            mack.centerX.equalTo(self.view)
        }
        
        
        
        // Hyper link click label....
        let  lbl_Aboutus = UIButton.init(type: .custom)
        
//        let lbl_Aboutus = UILabel(frame: CGRect(x: ((SCREEN_WIDTH()*45/100)-50), y: 500, width: 200, height: 21))
        lbl_Aboutus.setTitle("About StarfishFX", for: .normal)
        lbl_Aboutus.setTitleColor(kColorDouble(), for: .normal)
        lbl_Aboutus.titleLabel?.font = UIFont.systemFont(ofSize: 15)
       
        self.view.addSubview(lbl_Aboutus)
        lbl_Aboutus.snp.makeConstraints { (mack) in
            mack.top.equalTo(lbl_TradeInfo.snp.bottom).offset(COMPUTE_LENGTH(30))
            mack.centerX.equalTo(self.view)
        }
//        lbl_Aboutus.font = UIFont(name:lbl_punchLine.font.fontName,size :15)
        
        let imgAboutus = UIImageView.init(image: UIImage.init(named: "arrow"))
        self.view.addSubview(imgAboutus)
        imgAboutus.snp.makeConstraints { (mack) in
            mack.top.equalTo(lbl_Aboutus.snp.top).offset(COMPUTE_LENGTH(30))
            mack.left.equalTo(lbl_Aboutus.snp.right).offset(COMPUTE_LENGTH(10))
        }
        
        
        
        
        
        // Bottom images
        let imageName1 = "FV-logo"
        let image1 = UIImage(named: imageName1)
        let imageView1 = UIImageView(image: image1!)
//        if(SCREEN_WIDTH() <= 320)
//        {
//            //imageView1.center = CGPoint(x: 50, y :530)
//            imageView1.frame = CGRect(x:10, y: 530, width: 50, height: 30)
//        }
//        else
//        {
//            imageView1.center = CGPoint(x: 50, y :630)
//        }
        self.view.addSubview(imageView1)
        imageView1.snp.makeConstraints { (mack) in
            mack.left.equalTo(COMPUTE_LENGTH(77))
            mack.width.equalTo(COMPUTE_LENGTH(214))
            mack.height.equalTo(COMPUTE_LENGTH(127))
            mack.bottom.equalTo(self.view.snp.bottom).offset(-COMPUTE_LENGTH(99))
        }
        
        
        
        
        let imageName2 = "Finance-Review-Logo"
        let image2 = UIImage(named: imageName2)
        let imageView2 = UIImageView(image: image2!)
//        if(SCREEN_WIDTH() <= 320)
//        {
//            imageView2.frame = CGRect(x:100, y: 530, width: 50, height: 30)
//        }
//        else
//        {
//            imageView2.center = CGPoint(x: 150, y :630)
//        }
        self.view.addSubview(imageView2)
        imageView2.snp.makeConstraints { (mack) in
            mack.left.equalTo(imageView1.snp.right).offset(COMPUTE_LENGTH(48))
            mack.width.equalTo(COMPUTE_LENGTH(243))
            mack.height.equalTo(COMPUTE_LENGTH(64))
            mack.bottom.equalTo(imageView1.snp.bottom).offset(-COMPUTE_LENGTH(25))
            
        }
        
        
        let imageName3 = "Best--Trading"
        let image3 = UIImage(named: imageName3)
        let imageView3 = UIImageView(image: image3!)
//        if(SCREEN_WIDTH() <= 320)
//        {
//            imageView3.frame = CGRect(x:190, y: 530, width: 50, height: 30)
//
//        }
//        else
//        {
//            imageView3.center = CGPoint(x: 230, y :630)
//        }
        self.view.addSubview(imageView3)
        imageView3.snp.makeConstraints { (mack) in
            mack.left.equalTo(imageView2.snp.right).offset(COMPUTE_LENGTH(68))
            mack.width.equalTo(COMPUTE_LENGTH(130))
            mack.height.equalTo(COMPUTE_LENGTH(127))
            mack.bottom.equalTo(imageView1)
        }
        
        
        let imageName4 = "Best-Binary-Logo"
        let image4 = UIImage(named: imageName4)
        let imageView4 = UIImageView(image: image4!)
//        if(SCREEN_WIDTH() <= 320)
//        {
//            imageView4.frame = CGRect(x:260, y: 530, width: 50, height: 30)
//        }
//        else
//        {
//            imageView4.center = CGPoint(x: 310, y :630)
//        }
        self.view.addSubview(imageView4)
        imageView4.snp.makeConstraints { (mack) in
            mack.left.equalTo(imageView3.snp.right).offset(COMPUTE_LENGTH(58))
            mack.width.equalTo(COMPUTE_LENGTH(304))
            mack.height.equalTo(COMPUTE_LENGTH(111))
            mack.bottom.equalTo(imageView1.snp.bottom).offset(COMPUTE_LENGTH(10))
        }

        
        
}
    
    override func viewDidAppear(_ animated: Bool) {
           }

    
    // MARK:- Player Button action.
    
    func registrationButtonAction(_ sender: Any) {
        print("registration")
        let vc = RegistrationVC()
        self.navigationController?.pushViewController(vc, animated: false)
    }
    
    // MARK:- login Activity
    
    func loginActivity(btn:UIButton!)  {
        print("Hello test login")
       let vc = LoginVC()
       self.navigationController?.pushViewController(vc, animated: false)
        
       
    }
    
    // MARK:- Device Orientation

    override var shouldAutorotate: Bool {
        return true
    }
    
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return .portrait
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

