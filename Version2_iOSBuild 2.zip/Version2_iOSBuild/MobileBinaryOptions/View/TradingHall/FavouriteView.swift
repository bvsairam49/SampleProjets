//
//  FavouriteView.swift
//  MobileBinaryOptions
//
//  Created by GE on 17/2/4.
//  Copyright © 2017年 Broctagon. All rights reserved.
//

import UIKit

class FavouriteView: UIView {

    let backImgView = UIImageView()
    let heartImgView = UIImageView()
    let addBtn = BaseBtn()
    let favouriteSV = UIScrollView()
    let contentView = UIView()
    
    var values = Array<String>()
    var itemViews = Array<UIView>()
    
    init(values: Array<String>, selectedValue: String) {
        super.init(frame: .zero)
        
        self.values = values
        
        self.createUI()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func createUI() {
        let backImg = UIImage(named: "btnBorder_normal.png")
        self.backImgView.image = backImg?.resizableImage(withCapInsets: UIEdgeInsetsMake(0, (backImg?.size.width)!/462.0*40, 0, (backImg?.size.width)!/462.0*40), resizingMode: .stretch)
        self.addSubview(self.backImgView)
        self.backImgView.snp.makeConstraints { (make) in
            make.edges.equalTo(self)
        }
        
        self.heartImgView.image = UIImage(named: "favorite_heart.png")
        self.addSubview(self.heartImgView)
        self.heartImgView.snp.makeConstraints { (make) in
            make.left.equalTo(COMPUTE_LENGTH(35.0))
            make.width.equalTo(COMPUTE_LENGTH(50.0))
            make.height.equalTo(COMPUTE_LENGTH(41.0))
            make.centerY.equalTo(self)
        }
        
        self.addBtn.setImage(UIImage(named: "add.png"), for: .normal)
        self.addBtn.setImage(UIImage(named: "add.png"), for: .highlighted)
        self.addBtn.addTarget(self, action: #selector(clickAddBtn), for: .touchUpInside)
        self.addSubview(self.addBtn)
        self.addBtn.snp.makeConstraints { (make) in
            make.right.equalTo(self)
            make.width.equalTo(COMPUTE_LENGTH(30.0 + 38.0 + 10.0))
            make.height.equalTo(self)
            make.centerY.equalTo(self)
        }
        
        self.addSubview(self.favouriteSV)
        self.favouriteSV.snp.makeConstraints { (make) in
            make.left.equalTo(self.heartImgView.snp.right).offset(COMPUTE_LENGTH(20.0))
            make.right.equalTo(self.addBtn.snp.left)
            make.centerX.top.height.equalTo(self)
        }
        
        self.favouriteSV.addSubview(self.contentView)
        self.contentView.snp.makeConstraints { (make) in
            make.edges.equalTo(self.favouriteSV)
        }
        
        self.createItemViews()
    }
    
    func createItemViews() {
        for _ in 0..<self.values.count {
            let view = FavouriteItemView(symbol: "EURUSDbo", timeframe: "M1")
            self.contentView.addSubview(view)
            
            if let lastView = self.itemViews.last {
                view.snp.makeConstraints({ (make) in
                    make.left.equalTo(lastView.snp.right).offset(5)
                    make.width.height.top.equalTo(lastView)
                })
            }else {
                view.snp.makeConstraints({ (make) in
                    make.left.equalTo(0)
                    make.width.equalTo(COMPUTE_LENGTH(215.0))
                    make.height.equalTo(self).offset(-1)
                    make.centerY.equalTo(self.contentView)
                })
            }
            
            self.itemViews.append(view)
        }
        
        self.contentView.snp.makeConstraints { (make) in
            make.left.top.height.equalTo(self.favouriteSV)
            if let tempView = self.itemViews.last {
                make.right.equalTo(tempView).offset(5)
            }
        }
    }
    
    func clickAddBtn() {
        self.addItemView(value: "123")
    }
    
    func addItemView(value: String) {
        let newView = FavouriteItemView(symbol: "USDJPYbo", timeframe: "M30")
        self.contentView.addSubview(newView)
        
        newView.snp.makeConstraints { (make) in
            make.left.equalTo(0)
            make.width.equalTo(COMPUTE_LENGTH(215.0))
            make.height.equalTo(self).offset(-1)
            make.centerY.equalTo(self.contentView)
        }
        
        if let firstView = self.itemViews.first {
            firstView.snp.remakeConstraints({ (make) in
                make.left.equalTo(newView.snp.right).offset(5)
                make.width.height.top.equalTo(newView)
            })
        }
        
        self.contentView.snp.updateConstraints { (make) in
            if let tempView = self.itemViews.last {
                make.right.equalTo(tempView).offset(5)
            }
        }
        
        self.values.insert(value, at: 0)
        self.itemViews.insert(newView, at: 0)
    }
    
    func removeItemView(itemView: UIView) {
        itemView.removeFromSuperview()
        let index = self.itemViews.index(of: itemView)
        self.values.remove(at: index!)
        self.itemViews.remove(at: index!)
        
        var lastView: UIView?
        for itemView in self.itemViews {
            if let tempView = lastView {
                itemView.snp.remakeConstraints({ (make) in
                    make.left.equalTo(tempView.snp.right).offset(5)
                    make.width.height.top.equalTo(tempView)
                })
            }else {
                itemView.snp.remakeConstraints({ (make) in
                    make.left.equalTo(0)
                    make.width.equalTo(COMPUTE_LENGTH(215.0))
                    make.height.equalTo(self).offset(-1)
                    make.centerY.equalTo(self.contentView)
                })
            }
            
            lastView = itemView
        }
        
        self.contentView.snp.updateConstraints { (make) in
            if let tempView = self.itemViews.last {
                make.right.equalTo(tempView).offset(5)
            }
        }
    }
    
    func removeAllItemViews() {
        for subview in self.itemViews {
            subview.removeFromSuperview()
        }
        self.itemViews.removeAll()
        self.values.removeAll()
    }
    
    func resetValues(values: Array<String>, selectedValue: String) {
        self.values = values
        
        for subview in self.itemViews {
            subview.removeFromSuperview()
        }
        self.itemViews.removeAll()
        
        self.createItemViews()
    }
}

//class FavouriteView: UIView {
//    
//    let backImgView = UIImageView()
//    let heartImgView = UIImageView()
//    let addBtn = BaseBtn()
//    let favouriteSV = UIScrollView()
//    let contentView = UIView()
//    
//    var values = Array<String>()
//    var itemViews = Array<UIView>()
//    
//    let rightView = UIView()    // has some doubt for scrollView, then add it
//    
//    init(values: Array<String>, selectedValue: String) {
//        super.init(frame: .zero)
//        
//        self.values = values
//        
//        self.createUI()
//    }
//    
//    required init?(coder aDecoder: NSCoder) {
//        fatalError("init(coder:) has not been implemented")
//    }
//    
//    func createUI() {
//        let backImg = UIImage(named: "btnBorder_normal.png")
//        self.backImgView.image = backImg?.resizableImage(withCapInsets: UIEdgeInsetsMake(0, (backImg?.size.width)!/462.0*40, 0, (backImg?.size.width)!/462.0*40), resizingMode: .stretch)
//        self.addSubview(self.backImgView)
//        self.backImgView.snp.makeConstraints { (make) in
//            make.edges.equalTo(self)
//        }
//        
//        self.heartImgView.image = UIImage(named: "favorite_heart.png")
//        self.addSubview(self.heartImgView)
//        self.heartImgView.snp.makeConstraints { (make) in
//            make.left.equalTo(COMPUTE_LENGTH(35.0))
//            make.width.equalTo(COMPUTE_LENGTH(50.0))
//            make.height.equalTo(COMPUTE_LENGTH(41.0))
//            make.centerY.equalTo(self)
//        }
//        
//        self.addBtn.setImage(UIImage(named: "add.png"), for: .normal)
//        self.addBtn.setImage(UIImage(named: "add.png"), for: .highlighted)
//        self.addBtn.addTarget(self, action: #selector(clickAddBtn), for: .touchUpInside)
//        self.addSubview(self.addBtn)
//        self.addBtn.snp.makeConstraints { (make) in
//            make.right.equalTo(self)
//            make.width.equalTo(COMPUTE_LENGTH(30.0 + 38.0 + 10.0))
//            make.height.equalTo(self)
//            make.centerY.equalTo(self)
//        }
//        
//        self.addSubview(self.favouriteSV)
//        self.favouriteSV.snp.makeConstraints { (make) in
//            make.left.equalTo(self.heartImgView.snp.right).offset(COMPUTE_LENGTH(20.0))
//            make.right.equalTo(self.addBtn.snp.left)
//            make.centerX.top.height.equalTo(self)
//        }
//        
//        self.favouriteSV.addSubview(self.contentView)
//        self.contentView.snp.makeConstraints { (make) in
//            make.edges.equalTo(self.favouriteSV)
//        }
//        
//        self.createItemViews()
//    }
//    
//    func createItemViews() {
//        //        self.values = ["12345"]
//        //        for _ in 0..<self.values.count {
//        ////            let view = FavouriteItemView(symbol: "EURUSDbo", timeframe: "M1")
//        ////            self.contentView.addSubview(view)
//        //
//        //            let view = UIView()
//        //            self.contentView.addSubview(view)
//        //
//        //            if let lastView = self.itemViews.last {
//        //                view.snp.makeConstraints({ (make) in
//        //                    make.left.equalTo(lastView.snp.right).offset(5)
//        //                    make.width.height.top.equalTo(lastView)
//        //                })
//        //            }else {
//        //                view.snp.makeConstraints({ (make) in
//        //                    make.left.equalTo(0)
//        //                    make.width.equalTo(COMPUTE_LENGTH(215.0))
//        //                    make.height.equalTo(self).offset(-1)
//        //                    make.centerY.equalTo(self.contentView)
//        //                })
//        //            }
//        //
//        //            self.itemViews.append(view)
//        //        }
//        //
//        //        self.contentView.snp.makeConstraints { (make) in
//        //            make.left.top.height.equalTo(self.favouriteSV)
//        //            if let tempView = self.itemViews.last {
//        //                make.right.equalTo(tempView).offset(5)
//        //            }
//        //        }
//        
//        self.contentView.addSubview(self.rightView)
//        
//        self.rightView.snp.makeConstraints { (make) in
//            make.top.bottom.equalTo(self.contentView)
//            make.left.equalTo(0)
//            make.right.equalTo(1)
//        }
//        
//        self.contentView.snp.makeConstraints { (make) in
//            make.left.top.height.equalTo(self.favouriteSV)
//            make.right.equalTo(self.rightView).offset(5)
//        }
//    }
//    
//    func clickAddBtn() {
//        self.addItemView(value: "123")
//    }
//    
//    func addItemView(value: String) {
//        let newView = FavouriteItemView(symbol: "USDJPYbo", timeframe: "M30")
//        self.contentView.addSubview(newView)
//        
//        newView.snp.makeConstraints { (make) in
//            make.left.equalTo(0)
//            make.width.equalTo(COMPUTE_LENGTH(215.0))
//            make.height.equalTo(self).offset(-1)
//            make.centerY.equalTo(self.contentView)
//        }
//        
//        if let firstView = self.itemViews.first {
//            firstView.snp.remakeConstraints({ (make) in
//                make.left.equalTo(newView.snp.right).offset(5)
//                make.width.height.top.equalTo(newView)
//            })
//        }
//        
//        //        self.contentView.snp.updateConstraints { (make) in
//        //            if let tempView = self.itemViews.last {
//        //                make.right.equalTo(tempView).offset(5)
//        //            }
//        //        }
//        
//        self.contentView.snp.updateConstraints { (make) in
//            if let tempView = self.itemViews.last {
//                make.right.equalTo(tempView).offset(5)
//            }
//        }
//        
//        self.values.insert(value, at: 0)
//        self.itemViews.insert(newView, at: 0)
//    }
//    
//    func removeItemView(itemView: UIView) {
//        itemView.removeFromSuperview()
//        let index = self.itemViews.index(of: itemView)
//        self.values.remove(at: index!)
//        self.itemViews.remove(at: index!)
//        
//        var lastView: UIView?
//        for itemView in self.itemViews {
//            if let tempView = lastView {
//                itemView.snp.remakeConstraints({ (make) in
//                    make.left.equalTo(tempView.snp.right).offset(5)
//                    make.width.height.top.equalTo(tempView)
//                })
//            }else {
//                itemView.snp.remakeConstraints({ (make) in
//                    make.left.equalTo(0)
//                    make.width.equalTo(COMPUTE_LENGTH(215.0))
//                    make.height.equalTo(self).offset(-1)
//                    make.centerY.equalTo(self.contentView)
//                })
//            }
//            
//            lastView = itemView
//        }
//        
//        self.contentView.snp.updateConstraints { (make) in
//            if let tempView = self.itemViews.last {
//                make.right.equalTo(tempView).offset(5)
//            }
//        }
//    }
//    
//    func removeAllItemViews() {
//        for subview in self.itemViews {
//            subview.removeFromSuperview()
//        }
//        self.itemViews.removeAll()
//        self.values.removeAll()
//    }
//    
//    func resetValues(values: Array<String>, selectedValue: String) {
//        self.values = values
//        
//        for subview in self.itemViews {
//            subview.removeFromSuperview()
//        }
//        self.itemViews.removeAll()
//        
//        self.createItemViews()
//    }
//}
