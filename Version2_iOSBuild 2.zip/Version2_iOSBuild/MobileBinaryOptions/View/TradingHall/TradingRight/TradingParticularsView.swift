//
//  TradingParticularsView.swift
//  podTest2
//
//  Created by Jerry song on 17/2/3.
//  Copyright © 2017年 Test. All rights reserved.
//

import UIKit


protocol TradingParticularsViewDelegate : NSObjectProtocol {
    
    func closeTradingParticularsView()
}



class TradingParticularsView: UIView {

    weak var delegate :TradingParticularsViewDelegate?
    
    
    
    var symbolLb :UILabel!
    var inderLb :UILabel!
    var breedLb :UILabel!
    var earningsLb :UILabel!
    
//    var symbolLb :UILabel!
    
    
    
    func createUI() {
        
        //  headView
        let headImg :UIImageView = UIImageView.init()
        headImg.image = UIImage(named: "RightView_head_bg")
        headImg.isUserInteractionEnabled = true
        self.addSubview(headImg)
        headImg.snp.makeConstraints { (mack) in
            mack.top.equalTo(0)
            mack.left.right.equalTo(self)
            mack.height.equalTo(COMPUTE_LENGTH(90))
        }
        
        self.symbolLb = UILabel.init()
        symbolLb.text = "Close Positions"
        symbolLb.textAlignment = .center
        symbolLb.font = UIFont.systemFont(ofSize: 13)
        symbolLb.textColor = kColorPrice()
        headImg.addSubview(symbolLb)
        symbolLb.snp.makeConstraints { (mack) in
           mack.centerY.equalTo(headImg)
            mack.left.equalTo(COMPUTE_LENGTH(200))
            mack.height.equalTo(COMPUTE_LENGTH(70))
        }
        
        self.inderLb = UILabel.init()
        inderLb.text = "#95878733"
        inderLb.textColor = kColorPrice()
        inderLb.font = UIFont.systemFont(ofSize: 13)
        headImg.addSubview(inderLb)
        inderLb.snp.makeConstraints { (mack) in
            mack.top.height.width.equalTo(symbolLb)
            mack.left.equalTo(symbolLb.snp.right).offset(COMPUTE_LENGTH(5))
        }
        
        //  close TradingparticularsView
        let closeBtn : UIButton = UIButton(type:.custom)
        closeBtn.setBackgroundImage(UIImage.init(named: "close_icon"), for: .normal)
        closeBtn.addTarget(self, action: #selector(closeTouchTradingparticularsView), for: .touchUpInside)
        headImg.addSubview(closeBtn)
        closeBtn.snp.makeConstraints { (mack) in
            mack.centerY.equalTo(headImg)
            mack.left.equalTo(headImg.snp.right).offset(-COMPUTE_LENGTH(80))
            mack.width.equalTo(COMPUTE_LENGTH(50))
            mack.height.equalTo(COMPUTE_LENGTH(50))
        }
        
        
        //  centre
        let centreImg :UIImageView = UIImageView.init()
        centreImg.image = UIImage(named: "TradingParti_Center_BG")
        centreImg.isUserInteractionEnabled = true
        self.addSubview(centreImg)
        centreImg.snp.makeConstraints { (mack) in
            mack.top.equalTo(headImg.snp.bottom)
            mack.left.right.equalTo(self)
            mack.height.equalTo(COMPUTE_LENGTH(610))
        }
        
        //  Open
        let openLb = UILabel.init()
        openLb.text = "Open"
        openLb.textColor = kColorTimeframeNormal()
        openLb.textAlignment = .center
        openLb.font = UIFont.systemFont(ofSize: 13)
        centreImg.addSubview(openLb)
        openLb.snp.makeConstraints { (mack) in
            mack.top.equalTo(COMPUTE_LENGTH(8))
            mack.left.equalTo(COMPUTE_LENGTH(220))
            mack.height.equalTo(COMPUTE_LENGTH(70))
        }

        //  Close
        let CloseLb = UILabel.init()
        CloseLb.text = "Close"
        CloseLb.textColor = kColorTimeframeNormal()
        CloseLb.textAlignment = .center
        CloseLb.font = UIFont.systemFont(ofSize: 13)
        centreImg.addSubview(CloseLb)
        CloseLb.snp.makeConstraints { (mack) in
            mack.top.equalTo(COMPUTE_LENGTH(8))
            mack.left.equalTo(self.inderLb.snp.left).offset(COMPUTE_LENGTH(60))
            mack.height.equalTo(COMPUTE_LENGTH(70))
        }

        
        //  Open  Price
        let openPriceLb = UILabel.init()
        openPriceLb.text = "1.12381"
        openPriceLb.textColor = UIColor.white
        openPriceLb.textAlignment = .center
        openPriceLb.font = UIFont.systemFont(ofSize: 16)
        centreImg.addSubview(openPriceLb)
        openPriceLb.snp.makeConstraints { (mack) in
            mack.top.equalTo(openLb.snp.bottom).offset(COMPUTE_LENGTH(18))
            mack.left.height.equalTo(openLb)
            
        }

        //  Open  time
        let openTimeLb = UILabel.init()
        openTimeLb.text = "11.40:12"
        openTimeLb.textColor = UIColor.white
        openTimeLb.textAlignment = .center
        openTimeLb.font = UIFont.systemFont(ofSize: 12)
        centreImg.addSubview(openTimeLb)
        openTimeLb.snp.makeConstraints { (mack) in
            mack.top.equalTo(openPriceLb.snp.bottom).offset(COMPUTE_LENGTH(15))
            mack.left.height.equalTo(openPriceLb)
        }

        //  Close  Price
        let closePriceLb = UILabel.init()
        closePriceLb.text = "1.12377"
        closePriceLb.textColor = kColorWinEnd()
        closePriceLb.textAlignment = .center
        closePriceLb.font = UIFont.systemFont(ofSize: 16)
        centreImg.addSubview(closePriceLb)
        closePriceLb.snp.makeConstraints { (mack) in
           mack.top.equalTo(CloseLb.snp.bottom).offset(COMPUTE_LENGTH(18))
            mack.left.height.equalTo(CloseLb)
        }
        
        //  Close  time
        let closeTimeLb = UILabel.init()
        closeTimeLb.text = "11.41:12"
        closeTimeLb.textColor = UIColor.white
        closeTimeLb.textAlignment = .center
        closeTimeLb.font = UIFont.systemFont(ofSize: 13)
        centreImg.addSubview(closeTimeLb)
        closeTimeLb.snp.makeConstraints { (mack) in
            mack.top.equalTo(closePriceLb.snp.bottom).offset(COMPUTE_LENGTH(15))
            mack.left.height.equalTo(CloseLb)
        }


        //  Asset
        let assetLb = UILabel.init()
        assetLb.text = "Asset"
        assetLb.textAlignment = .center
        assetLb.textColor = kColorTimeframeNormal()
        assetLb.font = UIFont.systemFont(ofSize: 13)
        centreImg.addSubview(assetLb)
        assetLb.snp.makeConstraints { (mack) in
            mack.top.equalTo(openTimeLb.snp.bottom).offset(COMPUTE_LENGTH(12))
            mack.left.height.equalTo(openLb)
        }
        
        //  Amount
        let amountLb = UILabel.init()
        amountLb.text = "Amount"
        amountLb.textColor = kColorTimeframeNormal()
        amountLb.textAlignment = .center
        amountLb.font = UIFont.systemFont(ofSize: 13)
        centreImg.addSubview(amountLb)
        amountLb.snp.makeConstraints { (mack) in
            mack.top.equalTo(closeTimeLb.snp.bottom).offset(COMPUTE_LENGTH(12))
            mack.left.height.equalTo(CloseLb)
        }

        //  breed
        breedLb = UILabel.init()
//        breedLb.text = "EURUSDbo"
        breedLb.textAlignment = .center
        breedLb.textColor = UIColor.white
        breedLb.font = UIFont.systemFont(ofSize: 13)
        centreImg.addSubview(breedLb)
        breedLb.snp.makeConstraints { (mack) in
           mack.top.equalTo(assetLb.snp.bottom).offset(COMPUTE_LENGTH(18))
            mack.left.height.equalTo(openLb)
        }
        
        let iconImg = UIImageView.init()
        iconImg.image = UIImage(named: "Trading_down-icon")
        centreImg.addSubview(iconImg)
        iconImg.snp.makeConstraints { (mack) in
            mack.centerY.equalTo(breedLb)
            mack.left.equalTo(breedLb.snp.right).offset(COMPUTE_LENGTH(8))
            mack.width.equalTo(COMPUTE_LENGTH(40))
            mack.height.equalTo(COMPUTE_LENGTH(33))
        }
        
        //  investment  Amount  Lb
        let investmentAmountLb = UILabel.init()
        investmentAmountLb.text = "$ 100"
        investmentAmountLb.textAlignment = .center
        investmentAmountLb.textColor = UIColor.white
        investmentAmountLb.font = UIFont.systemFont(ofSize: 13)
        centreImg.addSubview(investmentAmountLb)
        investmentAmountLb.snp.makeConstraints { (mack) in
            mack.top.equalTo(amountLb.snp.bottom).offset(COMPUTE_LENGTH(18))
            mack.left.height.equalTo(CloseLb)
        }
        
        
        //  period
        let periodLb = UILabel.init()
        periodLb.text = "Period"
        periodLb.textAlignment = .center
        periodLb.textColor = kColorTimeframeNormal()
        periodLb.font = UIFont.systemFont(ofSize: 13)
        centreImg.addSubview(periodLb)
        periodLb.snp.makeConstraints { (mack) in
            mack.top.equalTo(investmentAmountLb.snp.bottom).offset(COMPUTE_LENGTH(18))
            mack.left.height.equalTo(openLb)
        }
        
        //  Result
        let ResultLb = UILabel.init()
        ResultLb.text = "Result"
        ResultLb.textAlignment = .center
        ResultLb.textColor = kColorTimeframeNormal()
        ResultLb.font = UIFont.systemFont(ofSize: 13)
        centreImg.addSubview(ResultLb)
        ResultLb.snp.makeConstraints { (mack) in
            mack.top.equalTo(investmentAmountLb.snp.bottom).offset(COMPUTE_LENGTH(18))
             mack.left.height.equalTo(CloseLb)
        }

        //  currency of settlement
        let proPorTionLb = UILabel.init()
        proPorTionLb.text = "30M-80%"
        proPorTionLb.textAlignment = .center
        proPorTionLb.textColor = UIColor.white
        proPorTionLb.font = UIFont.systemFont(ofSize: 13)
        centreImg.addSubview(proPorTionLb)
        proPorTionLb.snp.makeConstraints { (mack) in
            mack.top.equalTo(periodLb.snp.bottom).offset(COMPUTE_LENGTH(18))
            mack.left.height.equalTo(openLb)
        }
        
        
        //  earnings
        earningsLb = UILabel.init()
//        earningsLb.text = "$80"
        earningsLb.textColor = kColorWinEnd()
        earningsLb.textAlignment = .center
        earningsLb.font = UIFont.systemFont(ofSize: 13)
        centreImg.addSubview(earningsLb)
        earningsLb.snp.makeConstraints { (mack) in
            mack.top.equalTo(ResultLb.snp.bottom).offset(COMPUTE_LENGTH(18))
            
            mack.left.height.equalTo(CloseLb)
        }
  
        
    }
    
    
    //  close Tradingparticulars
    func closeTouchTradingparticularsView() {
        
        self.delegate?.closeTradingParticularsView()
    }
    

}
