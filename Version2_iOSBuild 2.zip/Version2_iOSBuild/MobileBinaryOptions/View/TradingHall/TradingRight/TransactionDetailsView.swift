//
//  TransactionDetailsView.swift
//  podTest2
//
//  Created by Jerry song on 17/1/17.
//  Copyright © 2017年 Test. All rights reserved.
//

import UIKit


//  Swift 代理
protocol TransactionDetailsViewDelegate :NSObjectProtocol{

    func createOpenPositionsView() // open
    
    func createClosePositionsView() // close
}




class TransactionDetailsView: UIView {

   
    weak var delegate:TransactionDetailsViewDelegate?
    
    var orderLb :UILabel!
    
    
    func createTransactionDetailsContent() {
    
        
        let openBtn = UIButton(type:.custom)
//        openBtn.setTitle("OPEN POSITIONS", for: .normal)
        openBtn.tag = 100
        openBtn.setBackgroundImage(UIImage(named:"Open-positions"), for: .normal)
         openBtn.setBackgroundImage(UIImage(named:"Open-positions_press"), for: .highlighted)
        openBtn.addTarget(self, action: #selector(tappedTradeBtn), for: .touchUpInside)
        self.addSubview(openBtn)
        openBtn.snp.makeConstraints { (mack) in
            mack.top.equalTo(COMPUTE_LENGTH(74))
            mack.left.equalTo(self.snp.left).offset(COMPUTE_LENGTH(30))
            mack.right.equalTo(self.snp.right).offset(COMPUTE_LENGTH(-30))
            mack.height.equalTo(COMPUTE_LENGTH(84))
        }
        
        let openTitle = UILabel.init()
        openTitle.text = "OPEN POSITIONS"
        openTitle.font = FONT_CUSTOM(10)
        openTitle.textColor = kColorTimeframeNormal()
        openBtn.addSubview(openTitle)
        openTitle.snp.makeConstraints { (mack) in
            mack.centerY.equalTo(openBtn)
            mack.left.equalTo(COMPUTE_LENGTH(30))
            
        }
        
        
        orderLb = UILabel.init()
        orderLb.text = "0"
        orderLb.textColor = UIColor.yellow
        orderLb.font = UIFont.systemFont(ofSize: 13)
        self.addSubview(orderLb)
        orderLb.snp.makeConstraints { (mack) in
            mack.centerY.equalTo(openBtn)
            mack.left.equalTo(openTitle.snp.right).offset(COMPUTE_LENGTH(30))
        }
        
        
        let closedBtn = UIButton(type:.custom)
        closedBtn.tag = 100
        closedBtn.setBackgroundImage(UIImage(named:"RightView_Closed-positions"), for: .normal)
        closedBtn.setBackgroundImage(UIImage(named:"RightView_Closed-positions_press"), for: .highlighted)
        closedBtn.addTarget(self, action: #selector(openClosePosiTableViewCellBtn), for: .touchUpInside)
        self.addSubview(closedBtn)
        closedBtn.snp.makeConstraints { (mack) in
            mack.top.equalTo(openBtn.snp.bottom).offset(COMPUTE_LENGTH(26))
            mack.left.equalTo(openBtn.snp.left)
            mack.width.equalTo(openBtn.snp.width)
            mack.height.equalTo(COMPUTE_LENGTH(84))
        }

        
        let closedTitle = UILabel.init()
        closedTitle.text = "CLOSED POSITIONS"
        closedTitle.font = UIFont.boldSystemFont(ofSize: 10)
        closedTitle.textColor = kColorTimeframeNormal()
        closedBtn.addSubview(closedTitle)
        closedTitle.snp.makeConstraints { (mack) in
            mack.centerY.equalTo(closedBtn)
            mack.left.equalTo(COMPUTE_LENGTH(30))
            
        }
        
        
        
        let closedOrderLb = UILabel.init()
        closedOrderLb.text = "3"
        closedOrderLb.textColor = UIColor.yellow
        closedOrderLb.font = UIFont.systemFont(ofSize: 13)
        closedBtn.addSubview(closedOrderLb)
        closedOrderLb.snp.makeConstraints { (mack) in
            mack.centerY.equalTo(closedBtn)
            mack.left.equalTo(orderLb.snp.left)
        }
    }
    
    
    func tappedTradeBtn(btn: UIButton) {
       
        if (orderLb.text?.isEqual("0"))! { //  如果正在进行中的交易为0 无点击反应
            
            return
        }
       
        //  执行代理
        self.delegate?.createOpenPositionsView()
        
        print("打开正在进行中的订单")
        
    }
    
    func openClosePosiTableViewCellBtn() {
        
        self.delegate?.createClosePositionsView()
         print("打开已经关闭的订单")
        
    }
    
    //  增加交易的 订单数量
    func setOpenPositionsNumber(number :Int ) {
        
//        var count = Int((orderLb.text)!)!  + number
        let number = 1
        let count = Int((orderLb.text)!)! + number
        
        orderLb.text = "\(count)"
        
        
        
    }
    
    
    
}
