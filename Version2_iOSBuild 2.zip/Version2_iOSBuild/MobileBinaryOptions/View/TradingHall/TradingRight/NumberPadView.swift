//
//  NumberPadView.swift
//  podTest2
//
//  Created by Jerry song on 17/1/18.
//  Copyright © 2017年 Test. All rights reserved.
//

import UIKit


/**
 *  键盘输入方式
 */
enum CompassPoint {
    case ComputeIncrease
    case ComputeDoubleUp
    case ComputeAppendValue
    case ComputeDelete
}

/**
 *  设置一个代理  在点击键盘上的数字后，把投资金额的值传递出去
 */
protocol NumberPadViewDelegate:NSObjectProtocol{
    
    func changeValue(compassPoint: CompassPoint, number: Int )
    
    func closeNumberPadView()
}




class NumberPadView: UIView {

    weak var delegate:NumberPadViewDelegate?
    
    
    
    func createContentView() {
        
        let numberPadBG :UIImageView = UIImageView.init()
        numberPadBG.image = UIImage(named: "KeyboardPage_bg")
        numberPadBG.isUserInteractionEnabled = true
//        numberPadBG.backgroundColor = UIColor.clear
        self.addSubview(numberPadBG)
        numberPadBG.snp.makeConstraints { (mack) in
            mack.top.left.width.height.equalTo(self)
        }
        
        
        // create Close Btn
        let closeBtn : UIButton = UIButton(type:.custom)
        closeBtn.frame = CGRect(x:self.width - COMPUTE_LENGTH(96), y:COMPUTE_LENGTH(18), width:COMPUTE_LENGTH(50), height:COMPUTE_LENGTH(50))
        closeBtn.setBackgroundImage(UIImage.init(named: "close_icon"), for: .normal)
        closeBtn.addTarget(self, action: #selector(closeTouchNumPad), for: .touchUpInside)
        numberPadBG.addSubview(closeBtn)
        
        let mainView = UIView.init(frame: CGRect.init(x: 0, y:COMPUTE_LENGTH(99), width: self.width, height:COMPUTE_LENGTH(260)))
        self.addSubview(mainView)
        
        //数据
        let arr = ["-$50","+$50","-$100","+$100"]
        //循环
        for i in 0...arr.count-1 {
            
            print("\(i)")
            
            let btn = UIButton.init(type: .custom)
            mainView.addSubview(btn)
            
            //每行三个
            let rowNum:CGFloat = 2
            //每一个多宽
            let width = mainView.width / rowNum
            //行
            let row = i % Int(rowNum)
            //列
            let col = i / Int(rowNum)
            //高度
            //            let hight:CGFloat = mainView.bounds.size.height / 4
            var CGX : CGFloat = (CGFloat(row) * width) + COMPUTE_LENGTH(9)
            
            if i == 1 || i == 3{
                
                CGX = CGFloat(row) * width - COMPUTE_LENGTH(9)
            }
            
            //坐标
            btn.frame = CGRect.init(x: CGX, y: CGFloat(col) * COMPUTE_LENGTH(140), width: width - COMPUTE_LENGTH(30), height: COMPUTE_LENGTH(120))
            btn.setBackgroundImage(UIImage(named:"number_headbg"), for: .normal)
            //设置标题
            btn.setTitle("\(arr[i])", for: .normal)
            btn.tag = i
            btn.addTarget(self, action: #selector(btnTouchNumPad), for: .touchUpInside)
            //字体颜色
            btn.tintColor = UIColor.white
        }

        //  craete x2(double up)
        let doubelBtn :UIButton = UIButton.init(type: .custom)
         doubelBtn.frame = CGRect.init(x:COMPUTE_LENGTH(26), y:mainView.bottom + COMPUTE_LENGTH(30) , width: self.width - COMPUTE_LENGTH(79), height: COMPUTE_LENGTH(100))
        doubelBtn.setTitle("x2(Double Up)", for: .normal)
        doubelBtn.setTitleColor(kColorDouble(), for: .normal)
        doubelBtn.setBackgroundImage(UIImage(named:"number_Doublebg3"), for: .normal)
        doubelBtn.titleLabel?.font = UIFont.systemFont(ofSize: 15)
        doubelBtn.addTarget(self, action: #selector(douBleBtnTouchNumPad), for: .touchUpInside)
        self.addSubview(doubelBtn)
        
        
        let rootView = UIView.init(frame: CGRect.init(x: 0, y: doubelBtn.bottom + COMPUTE_LENGTH(30), width: self.width, height: COMPUTE_LENGTH(700)))
        self.addSubview(rootView)
        //数据
        let numArray = ["1","2","3","4","5","6","7","8","9","0","00"," "]
        //循环
        for i in 0...numArray.count-1 {
            
            print("\(i)")
            
            let btn = UIButton.init(type: .custom)
            rootView.addSubview(btn)
            
            //每行三个
            let rowNum:CGFloat = 3
            //每一个多宽
            let width = mainView.width / rowNum
            //行
            let row = i % Int(rowNum)
            //列
            let col = i / Int(rowNum)
            var CGX : CGFloat = CGFloat(row) * width + COMPUTE_LENGTH(9)
            
            if i == 1 || i == 4 || i == 7 || i == 10 {
                
                CGX = CGFloat(row) * width - COMPUTE_LENGTH(4.5)
                
            }
            if i == 2 || i == 5 || i == 8 || i == 11 {
                
                CGX = CGFloat(row) * width - COMPUTE_LENGTH(9)
                
            }
            //坐标
            btn.frame = CGRect.init(x: CGX, y: CGFloat(col) * width + 4, width: width - COMPUTE_LENGTH(40), height: width - COMPUTE_LENGTH(40))
            //设置标题
            btn.setTitle("\(numArray[i])", for: .normal)
            btn.setBackgroundImage(UIImage(named:"number_bg"), for: .normal)
            btn.tag = i
            btn.addTarget(self, action: #selector(write), for: .touchUpInside)
            //字体颜色
            btn.tintColor = UIColor.white
            if i == 11 {
               btn.setImage(UIImage(named:"delete_icon"), for: .normal)
//                btn.imageEdgeInsets = UIImage(named: "delete_icon")
            }
            
        }
    }

    //  批量加减
    func btnTouchNumPad(sender:UIButton) {
        var number = 0
        switch sender.tag {
        case 0:
            number = -50
        case 1:
            number = +50
        case 2:
            number = -100
        case 3:
            number = +100
        default:
            number = 0
        }
        
        print(number)
        self.delegate?.changeValue(compassPoint: .ComputeIncrease, number: number)
    }
    
    func douBleBtnTouchNumPad(sender:UIButton)  {
        self.delegate?.changeValue(compassPoint: .ComputeDoubleUp, number: 0)
    }
    func write(btn:UIButton) {
        var mode :CompassPoint = .ComputeAppendValue
        var number = 0
        if btn.tag < 10 {
            number = Int((btn.titleLabel?.text)!)!
            
        }else if btn.tag == 10{
            number = 100
        }else{
        
            mode = .ComputeDelete
        }
        
         self.delegate?.changeValue(compassPoint: mode, number: number)
    }
    //  关闭按钮的事件
    func closeTouchNumPad(){
        self.delegate?.closeNumberPadView()
    }
}
