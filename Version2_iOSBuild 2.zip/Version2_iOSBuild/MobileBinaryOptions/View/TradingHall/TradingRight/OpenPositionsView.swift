//
//  OpenPositionsView.swift
//  podTest2
//
//  Created by Jerry song on 17/1/18.
//  Copyright © 2017年 Test. All rights reserved.
//

import UIKit


var kSize=UIScreen.main.bounds

//  create a delegate function
protocol OpenPositionViewDelegate : NSObjectProtocol {

    func closeTableView();
//    func createTradingParticularsView();

}


class OpenPositionsView: UIView,UITableViewDelegate,UITableViewDataSource {
    weak var delegate : OpenPositionViewDelegate?
    
    
    //  tableView
    var tableView :UITableView!
    //   重用标识
    var identifier :String!
    var itemStringArr :[String]!
    

    func createUI() {
        self.identifier = "cell"
        self.itemStringArr = ["EURUSDbo","EURUSDbo","EURUSDbo","EURUSDbo","EURUSDbo"]
        self.tableView = UITableView.init()
        tableView.delegate = self
        tableView.dataSource = self
        tableView.backgroundColor = UIColor.clear
        tableView.separatorColor = UIColor.clear
        self.addSubview(tableView)
         //注册 纯代码 cell
        tableView.register(OpenPosiTableViewCell.self, forCellReuseIdentifier: self.identifier)
        
        tableView.snp.makeConstraints { (mack) in
            mack.top.equalTo(COMPUTE_LENGTH(82))
            mack.left.right.equalTo(self)
            mack.bottom.equalTo(self).offset(COMPUTE_LENGTH(-22))
            
        }
        
        //  创建tableView 的头部视图
        let headerImg :UIImageView = UIImageView.init()
        headerImg.image = UIImage(named: "RightView_head_bg")
        headerImg.isUserInteractionEnabled = true
        self.addSubview(headerImg)
        headerImg.snp.makeConstraints { (mack) in
            mack.top.equalTo(0)
            mack.left.equalTo(0)
            mack.width.equalTo(self)
            mack.height.equalTo(COMPUTE_LENGTH(82))
        }
        //  Create TableView headView closeBtn
        let closeBtn = UIButton(type: .custom)
        closeBtn.frame = CGRect.init(x: 4, y:4, width: COMPUTE_LENGTH(55), height: COMPUTE_LENGTH(55))
        closeBtn.setBackgroundImage(UIImage(named:"RightView_back_icon"), for: .normal)
        closeBtn.addTarget(self, action: #selector(closeTableView), for: .touchUpInside)
        headerImg.addSubview(closeBtn)
        
        //  Closed podsitions
        let closedLb = UILabel.init()
        closedLb.text = "Open positions"
        closedLb.font = UIFont.systemFont(ofSize: 13)
        closedLb.textColor = kColorTimeframeNormal()
        closedLb.textAlignment = .center
        closedLb.frame = CGRect.init(x: 0, y: 4, width: 150, height: COMPUTE_LENGTH(50))
        headerImg.addSubview(closedLb)
        
//        tableView.tableHeaderView = headerImg
        
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return itemStringArr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: self.identifier)as! OpenPosiTableViewCell
        cell.backgroundColor = UIColor.clear
        cell.layer.backgroundColor = UIColor.clear.cgColor
        
        //赋值
        cell.symbolLb.text = "\(self.itemStringArr[indexPath.row])"
        
        return cell
    }
    
    func closeTableView() {
        
        self.delegate?.closeTableView()
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
//       self.delegate?.createTradingParticularsView()
        print(indexPath.row)
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        return COMPUTE_LENGTH(342)
    }
 
}
