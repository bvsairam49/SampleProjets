//
//  TradingOperationsView.swift
//  podTest2
//
//  Created by Jerry song on 17/1/17.
//  Copyright © 2017年 Test. All rights reserved.
//

import UIKit


/**
 *  交易 买涨 买跌状态
 */
enum TradingPoint {
    case tradingUp
    case tradingDown
}

/**
 *  设置一个代理  在点击UP or Down后，把值传递出去
 */
protocol TradingOperationsViewDelegate:NSObjectProtocol{
    
    func tradingValue(compassPoint: TradingPoint, number: Int )
    
}


class TradingOperationsView: UIView {

    weak var delegate :TradingOperationsViewDelegate?
    var upBtn :UIButton = UIButton()
    var downBtn :UIButton = UIButton()
    
    
    
    
    func createContentView()  {
        
        //  create up
        upBtn = UIButton(type:.custom)
        upBtn.setImage(UIImage(named:"RightView_UP_icon"), for: .normal)
        upBtn.setImage(UIImage(named:"RightView_UP_heigh"), for: .highlighted)
        upBtn.tag = 100
        upBtn.adjustsImageWhenHighlighted = false;
        upBtn.addTarget(self, action: #selector(addTradingPositionsNumber), for: .touchUpInside)
        self.addSubview(upBtn)
        upBtn.snp.makeConstraints { (mack) in
            mack.top.equalTo(COMPUTE_LENGTH(0))
            mack.centerX.equalTo(self)
            mack.width.equalTo(COMPUTE_LENGTH(462))
            mack.height.equalTo(COMPUTE_LENGTH(110))
        }

        
        let priceLb = UILabel.init()
        priceLb.text = "1.12345"
        priceLb.textColor = kColorPrice()
        priceLb.textAlignment = .center
        priceLb.font = UIFont.systemFont(ofSize: 10)
        self.addSubview(priceLb)
        priceLb.snp.makeConstraints { (mack) in
            mack.top.equalTo(upBtn.snp.bottom).offset(COMPUTE_LENGTH(36))
            mack.width.equalTo(self.snp.width)
            mack.centerX.equalTo(self)
           
            mack.height.equalTo(COMPUTE_LENGTH(50))
        }
        
        //  create DOWN
        downBtn = UIButton(type:.custom)
        downBtn.setImage(UIImage(named:"RightView_Down_icon"), for: .normal)
        downBtn.setImage(UIImage(named:"RightView_Down_heigh"), for: .highlighted)
        downBtn.tag = 101
        downBtn.adjustsImageWhenHighlighted = false;
        downBtn.addTarget(self, action: #selector(addTradingPositionsNumber), for: .touchUpInside)
        self.addSubview(downBtn)
        downBtn.snp.makeConstraints { (mack) in
            mack.top.equalTo(upBtn.snp.bottom).offset(COMPUTE_LENGTH(102))
            mack.centerX.equalTo(self)
            mack.width.equalTo(upBtn.snp.width)
            mack.height.equalTo(upBtn.snp.height)
        }
    }
    
    
    func addTradingPositionsNumber(btn : UIButton) {
        
        var number = 0
        if btn.tag == 100 {
            number += 1
           
    
            self.delegate?.tradingValue(compassPoint: .tradingUp, number: number)
            print("点击买涨")
            
        }else{
            number += 1
             self.delegate?.tradingValue(compassPoint: .tradingDown, number: number)
            print("点击买跌")
        }
        
        
    }
    
    
}
