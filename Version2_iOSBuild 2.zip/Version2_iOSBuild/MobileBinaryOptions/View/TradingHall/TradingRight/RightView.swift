//
//  RightView.swift
//  podTest2
//
//  Created by Jerry song on 17/1/17.
//  Copyright © 2017年 Test. All rights reserved.
//  用一个大的View 视图来存放 投资金额，买涨买跌，  OpenPositions and Closed positions  底部三部分的

import UIKit


/**
 *  投资金额状态
 */
enum InvestmentAmountStatus {
    case InvestmentAmountValid      //合法
    case InvestmentAmountOngoing    //正在输入
    case InvestmentAmountUndersize  //投资金额太小
    case InvestmentAmountOversize   //投资金额过大
    case InvestmentAmountNotMultiplesOfAmountStep //不是amountStep的倍数
    case InvestmentAmountInvalid    //非法
    case InvestmentAmountBalanceNotEnough  //余额不足

}


// 声明一个代理方法  告诉控制器去实现 该View 类中的代理方法
protocol RightViewDelegate:NSObjectProtocol{
    func toViewControllerImplementationMethods()
    
    func transactionToViewController()
    func openToClosePosiTableViewCell()
    
}



class RightView: UIView,InvestMentViewDelegate,TransactionDetailsViewDelegate,TradingOperationsViewDelegate {

    weak var delegate :RightViewDelegate?
    
    
    let investView = InvestMentView()
    let tradngOperationsView = TradingOperationsView()
    let transactionView = TransactionDetailsView()
    var investmentAmountStatus = InvestmentAmountStatus.self
    
    
    
    
    //  创建交易大厅左边的UI 视图
    func createRightTradingView() {
        
        let rightBGImg = UIImageView.init()
        rightBGImg.image = UIImage(named: "Right_bg")
        rightBGImg.isUserInteractionEnabled = true
        self.addSubview(rightBGImg)
        rightBGImg.snp.makeConstraints { (mack) in
            mack.top.left.width.height.equalTo(self)
        }
        
        
        
        self.investView.createContentView()
        self.investView.delegate = self;
        self.addSubview(self.investView)
        self.investView.snp.makeConstraints { (mack) in
            mack.top.equalTo(self.snp.top)
            mack.left.equalTo(self.snp.left)
            mack.width.equalTo(self.snp.width)
            mack.height.equalTo(COMPUTE_LENGTH(350))
        }
        
        
        // 买涨买跌的 view
        self.tradngOperationsView.createContentView()
        self.tradngOperationsView.delegate = self
        self.addSubview(self.tradngOperationsView)
        self.tradngOperationsView.snp.makeConstraints { (mack) in
            mack.top.equalTo(self.investView.snp.bottom).offset(COMPUTE_LENGTH(83))
            mack.left.width.height.equalTo(self.investView)
        }
        
        
        // 交易详情 View
        self.transactionView.createTransactionDetailsContent()
        self.transactionView.delegate = self
        self.addSubview(self.transactionView)
        self.transactionView.snp.makeConstraints { (mack) in
            mack.top.equalTo(self.tradngOperationsView.snp.bottom)
            mack.left.width.height.equalTo(self.tradngOperationsView)
        }
        
    }
    
    
    //  实现弹出视图的方法
    func popupCalculatorViw() {
        
        print("看看是否可以使用")
        //  执行右边视图的代理方法  去执行
        self.delegate?.toViewControllerImplementationMethods()
    }
    
    //  进入到正在交易详情页面
    func createOpenPositionsView() {
        self.delegate?.transactionToViewController()
        
    }
    //  进入已经交易结束页面
    func createClosePositionsView() {
       self.delegate?.openToClosePosiTableViewCell()
        
    }
    
    
    func changeInvestmentAmount(compassPoint: CompassPoint, number: Int ){
    
        self.investView.investMentAmount(compassPoint: compassPoint, number: number)
    
    }
    
    func tradingValue(compassPoint: TradingPoint, number: Int) {
        if compassPoint == .tradingUp {
            
            self.transactionView.setOpenPositionsNumber(number: number)
        }else{
            
            self.transactionView.setOpenPositionsNumber(number: number)
        }
        
    }
    
    /**
     *  根据金额合法性显示提示信息
     */
    func setInvestmentAmountStatus(investmentAmountStatus : InvestmentAmountStatus) {
        
//        self.investmentAmountStatus = investmentAmountStatus
        
        
        switch investmentAmountStatus {
        case .InvestmentAmountValid:
            
            changeUpAndDownBtn(enabled: true)
            
        case .InvestmentAmountOngoing:
            changeUpAndDownBtn(enabled: true)
        case .InvestmentAmountUndersize:
            changeUpAndDownBtn(enabled: true)
        case .InvestmentAmountOversize:
            changeUpAndDownBtn(enabled: true)
        case .InvestmentAmountNotMultiplesOfAmountStep:
            changeUpAndDownBtn(enabled: true)
        case .InvestmentAmountInvalid:
            changeUpAndDownBtn(enabled: true)
        case .InvestmentAmountBalanceNotEnough:
            changeUpAndDownBtn(enabled: true)
        default:
            changeUpAndDownBtn(enabled: true)
        }
  
    }
    
    
    func changeUpAndDownBtn(enabled : Bool) {
        //  如果在投资金额不合法的情况下  取消买涨  买跌点击效果
        self.tradngOperationsView.upBtn.isEnabled = enabled
        self.tradngOperationsView.downBtn.isEnabled = enabled
        
        
    }

}
