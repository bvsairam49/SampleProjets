//
//  InvestMentView.swift
//  podTest2
//
//  Created by Jerry song on 17/1/17.
//  Copyright © 2017年 Test. All rights reserved.
//

import UIKit

//  Swift 中代理的使用
protocol InvestMentViewDelegate : NSObjectProtocol {
    //  设置协议的方法
    func popupCalculatorViw()
}

class InvestMentView: UIView {
    
    
    // 用weak 定义一个代理属性
    weak var delegate:InvestMentViewDelegate?
    var  acctBtn :UIButton = UIButton()
    
    func createContentView() {
     
        // create InvestmentLb 
        let investmentLb = UILabel.init()
        investmentLb.text = "Investment"
        investmentLb.font = UIFont.systemFont(ofSize: 14)
        investmentLb.textColor = kColorTimeframeNormal()
        self.addSubview(investmentLb)
        investmentLb.snp.makeConstraints { (mack) in
            mack.top.equalTo(COMPUTE_LENGTH(29))
            mack.left.equalTo(COMPUTE_LENGTH(30))
            mack.width.equalTo(self.snp.width)
            mack.height.equalTo(COMPUTE_LENGTH(40))
        }
        
        //  create subtractionBtn
        let subtractBtn :UIButton = UIButton.init(type: .custom)
        subtractBtn.setImage(UIImage(named:"RightView_minus_icon"), for: .normal)
        subtractBtn.setImage(UIImage(named:"RightView_minus_heigh"), for: .highlighted)
        subtractBtn.tag = 100
        subtractBtn.addTarget(self, action: #selector(subTractionAcctBtn), for: .touchUpInside)
        self.addSubview(subtractBtn)
        subtractBtn.snp.makeConstraints { (mack) in
            mack.top.equalTo(self.snp.top).offset(COMPUTE_LENGTH(100))
            mack.left.equalTo(COMPUTE_LENGTH(30))
            mack.width.equalTo(COMPUTE_LENGTH(80))
            mack.height.equalTo(COMPUTE_LENGTH(80))
        }
        
 
        //  create $ symbol
        let symbolLb = UILabel.init()
        symbolLb.text = "$"
        symbolLb.textColor = kColorTimeframeNormal()
        self.addSubview(symbolLb)
        symbolLb.snp.makeConstraints { (mack) in
            mack.top.equalTo(investmentLb.snp.centerY).offset(COMPUTE_LENGTH(66))
            mack.left.equalTo(subtractBtn.snp.right).offset(COMPUTE_LENGTH(43))
            mack.width.equalTo(COMPUTE_LENGTH(45))
            mack.height.equalTo(COMPUTE_LENGTH(50))
        }
        
        // create account of
        let acctBtn : UIButton = UIButton.init(type: .custom)
        acctBtn.setTitle("20", for: .normal)
        acctBtn.addTarget(self, action: #selector(createPopupCalculatorViw), for:. touchUpInside)
        self.acctBtn = acctBtn
        acctBtn.titleLabel?.font = UIFont.systemFont(ofSize: 13)
        self.addSubview(acctBtn)
        acctBtn.snp.makeConstraints { (mack) in
            mack.top.equalTo(symbolLb.snp.top)
            mack.left.equalTo(symbolLb.snp.right)
            mack.width.equalTo(COMPUTE_LENGTH(200))
            mack.height.equalTo(symbolLb.snp.height)
        }

        //  create subtractionBtn
        let addBtn :UIButton = UIButton.init(type: .custom)
        addBtn.setImage(UIImage(named:"RightView_plus_icon"), for: .normal)
        addBtn.setImage(UIImage(named:"RightView_plus_height"), for: .highlighted)
        addBtn.tag = 101
        addBtn.addTarget(self, action: #selector(tapped), for: .touchUpInside)
        self.addSubview(addBtn)
        addBtn.snp.makeConstraints { (mack) in
            mack.top.equalTo(subtractBtn.snp.top)
            mack.right.equalTo(self.snp.right).offset(COMPUTE_LENGTH(-30))
            mack.width.equalTo(COMPUTE_LENGTH(70))
            mack.height.equalTo(subtractBtn.snp.height)
        }
        
        // create profit
        let profitLb = UILabel.init()
        profitLb.text = "Profit"
        profitLb.textColor = kColorTimeframeNormal()
        profitLb.font = UIFont.systemFont(ofSize: 14)
        self.addSubview(profitLb)
        profitLb.snp.makeConstraints { (mack) in
            mack.top.equalTo(subtractBtn.snp.bottom).offset(COMPUTE_LENGTH(53))
            mack.left.equalTo(investmentLb.snp.left)
            mack.width.equalTo(investmentLb.snp.width)
            mack.height.equalTo(investmentLb.snp.height)
        }
        
        //  create $ symbol
        let earningLb = UILabel.init()
        earningLb.text = "$"
        earningLb.textColor = kColorEarning()
        self.addSubview(earningLb)
        earningLb.snp.makeConstraints { (mack) in
            mack.top.equalTo(profitLb.snp.bottom).offset(COMPUTE_LENGTH(45))
            mack.left.equalTo(profitLb.snp.left)
            mack.width.equalTo(COMPUTE_LENGTH(45))
            mack.height.equalTo(COMPUTE_LENGTH(50))
        }
        
        let winLb = UILabel.init()
        winLb.text = "8.00"
        winLb.textColor = kColorEarning()
        winLb.font = UIFont.systemFont(ofSize: 15)
        self.addSubview(winLb)
        winLb.snp.makeConstraints { (mack) in
            mack.top.equalTo(earningLb.snp.top)
            mack.left.equalTo(earningLb.snp.right).offset(COMPUTE_LENGTH(10))
            mack.height.equalTo(earningLb.snp.height)
        }
        
        let profitsLb = UILabel.init()
        profitsLb.text = "80%"
        profitsLb.textColor = kColorEarning()
        profitsLb.font = UIFont.systemFont(ofSize: 20)
        self.addSubview(profitsLb)
        profitsLb.snp.makeConstraints { (mack) in
            mack.top.equalTo(winLb.snp.centerY).offset(COMPUTE_LENGTH(-50))
            mack.left.equalTo(winLb.snp.right).offset(COMPUTE_LENGTH(78))
            mack.height.equalTo(COMPUTE_LENGTH(100))
        }
    }
    
    // 减去
    func subTractionAcctBtn(btn:UIButton)  {
        let addNum = -5
        let count = Int((self.acctBtn.titleLabel?.text)!)! + addNum
        self.acctBtn.setTitle("\(count)", for: .normal)
        print("你点击了减号btn,btn的tag为\(self.acctBtn.titleLabel?.text)")
    }
    
    // 增加
    func tapped(btn:UIButton) {
        
        let addNum = 5
        let count = Int((self.acctBtn.titleLabel?.text)!)! + addNum
        self.acctBtn.setTitle("\(count)", for: .normal)
        print("你点击了减号btn,btn的tag为\(self.acctBtn.titleLabel?.text)")
    }
    
    //  弹出键盘
    func createPopupCalculatorViw(btn:UIButton) {
        self.delegate?.popupCalculatorViw()
        
        print("该弹出键盘了")
        
    }
    
    
    // 投资金额的代理事件
    func investMentAmount(compassPoint: CompassPoint, number: Int ) {
        
        var addNum = number
        if compassPoint == .ComputeIncrease {
            print(number)
            
            var count = Int((self.acctBtn.titleLabel?.text)!)! + addNum
            if count < 0 {
                count = 0
               self.acctBtn.setTitle("\(count)", for: .normal)
            }
            self.acctBtn.setTitle("\(count)", for: .normal)
        }else if compassPoint == .ComputeDoubleUp {
           
            let count = Int((self.acctBtn.titleLabel?.text)!)! * 2
            self.acctBtn.setTitle("\(count)", for: .normal)
        }else if compassPoint == .ComputeAppendValue{
            
            var count = Int((self.acctBtn.titleLabel?.text)!)! * 10 + addNum
            if addNum == 100 {
                count = Int((self.acctBtn.titleLabel?.text)!)! * addNum
            }
            
            self.acctBtn.setTitle("\(count)", for: .normal)
        }else if compassPoint == .ComputeDelete{
        
            addNum = 0
            let count = addNum
            self.acctBtn.setTitle("\(count)", for: .normal)
        }
    }
}
