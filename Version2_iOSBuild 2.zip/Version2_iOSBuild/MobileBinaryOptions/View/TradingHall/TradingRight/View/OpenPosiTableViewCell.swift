//
//  OpenPosiTableViewCell.swift
//  podTest2
//
//  Created by Jerry song on 17/1/18.
//  Copyright © 2017年 Test. All rights reserved.
//

import UIKit



class OpenPosiTableViewCell: UITableViewCell {

    var progressView : ProgressView!
    var pr:CGFloat!
    var timer:Timer!
    
    var symbolLb:UILabel!
    var openPositionLb :UILabel!
    var closePositionLb :UILabel!
    var investmentAmountLb :UILabel!
    var amountLb :UILabel!
    var mTimeLb :UILabel!
    var profitLb :UILabel!
    var investLb : UILabel!
    var percentageLb : UILabel!
    var profitPriceLb :UILabel!
    var openPriceLb :UILabel!
    var closePriceLb :UILabel!
    
    
    var signImgView :UIImageView!
    
    
    
    
    override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        createUI()
        pr = 0
        
    }
    
    //  create Open Positions UI
    func createUI() {
        self.contentView.backgroundColor = UIColor.clear
        
        
        
        //  create cell backgroundImage
        let openPositonsBgImg : UIImageView = UIImageView.init()
//        openPositonsBgImg.image = UIImage(named: "RightView_openPosi_bg")
        
        openPositonsBgImg.backgroundColor = kColorOpenBackground()
        openPositonsBgImg.isUserInteractionEnabled = true
        self.contentView.addSubview(openPositonsBgImg)
        openPositonsBgImg.snp.makeConstraints { (mack) in
            mack.top.equalTo(COMPUTE_LENGTH(8))
            mack.left.right.height.equalTo(self.contentView)
        }

        
        progressView = ProgressView.init()
        openPositonsBgImg.addSubview(progressView)
        progressView.snp.makeConstraints { (mack) in
            mack.top.equalTo(COMPUTE_LENGTH(40))
            mack.left.equalTo(COMPUTE_LENGTH(22))
            mack.width.equalTo(COMPUTE_LENGTH(130))
            mack.height.equalTo(COMPUTE_LENGTH(129))
            
        }
        
        //定时器
        timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(timerS), userInfo: nil, repeats: true)
        
        
        
        self.symbolLb = UILabel.init()
        self.symbolLb.textColor = kColorTimeframeNormal()
        self.symbolLb.font = UIFont.systemFont(ofSize: 13)
        openPositonsBgImg.addSubview(self.symbolLb)
        self.symbolLb.snp.makeConstraints { (mack) in
            mack.top.equalTo(COMPUTE_LENGTH(8))
            mack.left.equalTo(progressView.snp.right).offset(COMPUTE_LENGTH(40))
            mack.right.equalTo(self.contentView.snp.right)
            mack.height.equalTo(COMPUTE_LENGTH(50))
        }

        // trading  up or down icon
        self.signImgView = UIImageView.init()
        signImgView.image = UIImage(named: "Trading_up-icon")
        openPositonsBgImg.addSubview(self.signImgView)
        self.signImgView.snp.makeConstraints { (mack) in
            mack.top.equalTo(COMPUTE_LENGTH(16))
            mack.right.equalTo(openPositonsBgImg.snp.right).offset(-COMPUTE_LENGTH(40))
            mack.width.equalTo(COMPUTE_LENGTH(40))
            mack.height.equalTo(COMPUTE_LENGTH(33))
        }
        
        self.openPositionLb = UILabel.init()
        self.openPositionLb.text = "Open:"
        self.openPositionLb.font = UIFont.systemFont(ofSize: 13)
        self.openPositionLb.textColor = kColorTimeframeNormal()
        openPositonsBgImg.addSubview(self.openPositionLb)
        self.openPositionLb.snp.makeConstraints { (mack) in
            mack.top.equalTo(self.symbolLb.snp.bottom).offset(COMPUTE_LENGTH(25))
            mack.left.equalTo(progressView.snp.right).offset(COMPUTE_LENGTH(30))
            mack.width.equalTo(COMPUTE_LENGTH(150))
            mack.height.equalTo(self.symbolLb.snp.height)
        }
        
        self.openPriceLb = UILabel.init()
        self.openPriceLb.text = "1.12341"
        self.openPriceLb.textColor = kColorTimeframeNormal()
        openPositonsBgImg.addSubview(self.openPriceLb)
        self.openPriceLb.font = UIFont.systemFont(ofSize: 12)
        self.openPriceLb.snp.makeConstraints { (mack) in
            mack.top.height.equalTo(self.openPositionLb)
            mack.left.equalTo(self.openPositionLb.snp.right).offset(COMPUTE_LENGTH(5))
        }
        
        
        
        
        self.closePositionLb = UILabel.init()
        self.closePositionLb.text = "Close:"
        self.closePositionLb.font = UIFont.systemFont(ofSize: 13)
        self.closePositionLb.textColor = kColorTimeframeNormal()
        openPositonsBgImg.addSubview(self.closePositionLb)
        self.closePositionLb.snp.makeConstraints { (mack) in
            mack.top.equalTo(self.openPositionLb.snp.bottom).offset(COMPUTE_LENGTH(10))
            mack.left.width.height.equalTo(openPositionLb)
        }
        self.closePriceLb = UILabel.init()
        self.closePriceLb.text = "1.12341"
        self.closePriceLb.textColor = kColorWinEnd()
        openPositonsBgImg.addSubview(self.closePriceLb)
        self.closePriceLb.font = UIFont.systemFont(ofSize: 12)
        self.closePriceLb.snp.makeConstraints { (mack) in
            mack.top.height.equalTo(self.closePositionLb)
            mack.left.equalTo(self.closePositionLb.snp.right).offset(COMPUTE_LENGTH(5))
        }

        
        
        
        //  separateLine    the divider
        let separateLine = UILabel.init()
        separateLine.backgroundColor = kColorTimeframeNormal()
        openPositonsBgImg.addSubview(separateLine)
        separateLine.snp.makeConstraints { (mack) in
            mack.top.equalTo(self.closePositionLb.snp.bottom).offset(COMPUTE_LENGTH(10))
            mack.left.equalTo(progressView.snp.right).offset(COMPUTE_LENGTH(20))
            mack.right.equalTo(openPositonsBgImg.snp.right)
            mack.height.equalTo(COMPUTE_LENGTH(2))
        }
        
        // M  trading end time
        self.mTimeLb = UILabel.init()
        self.mTimeLb.textColor = kColorTimeframeNormal()
        self.mTimeLb.text = "M15"
        self.mTimeLb.font = UIFont.systemFont(ofSize: 13)
        openPositonsBgImg.addSubview(self.mTimeLb)
        self.mTimeLb.snp.makeConstraints { (mack) in
            mack.top.equalTo(separateLine.snp.bottom).offset(COMPUTE_LENGTH(10))
            mack.left.width.height.equalTo(openPositionLb)
        }
        
        // percentageLb
        self.percentageLb = UILabel.init()
        self.percentageLb.textColor = UIColor.white
        self.percentageLb.text = "80%"
        self.percentageLb.textAlignment = .center
        self.percentageLb.font = UIFont.systemFont(ofSize: 14)
        openPositonsBgImg.addSubview(self.percentageLb)
        self.percentageLb.snp.makeConstraints { (mack) in
            mack.top.equalTo(self.mTimeLb.snp.bottom).offset(COMPUTE_LENGTH(8))
            mack.left.equalTo(self.mTimeLb)
            mack.height.equalTo(self.mTimeLb.snp.height)
        }
        
        self.profitLb = UILabel.init()
        self.profitLb.textColor = kColorTimeframeNormal()
        self.profitLb.text = "Profit"
        self.profitLb.font = UIFont.systemFont(ofSize: 13)
        openPositonsBgImg.addSubview(self.profitLb)
        self.profitLb.snp.makeConstraints { (mack) in
            mack.top.equalTo(separateLine.snp.bottom).offset(COMPUTE_LENGTH(10))
            mack.left.equalTo(mTimeLb.snp.right)
            mack.width.height.equalTo(openPositionLb)
        }
        // profitPriceLb
        self.profitPriceLb = UILabel.init()
        self.profitPriceLb.textColor = kColorLossEnd()
        self.profitPriceLb.text = "-$100"
        self.profitPriceLb.textAlignment = .center
        self.profitPriceLb.font = UIFont.systemFont(ofSize: 14)
        openPositonsBgImg.addSubview(self.profitPriceLb)
        self.profitPriceLb.snp.makeConstraints { (mack) in
            mack.top.equalTo(self.profitLb.snp.bottom).offset(COMPUTE_LENGTH(8))
            mack.left.equalTo(self.profitLb)
            mack.height.equalTo(self.profitLb.snp.height)
        }

        // Amount
        self.amountLb = UILabel.init()
        self.amountLb.textColor = kColorTimeframeNormal()
        self.amountLb.text = "Amount"
        self.amountLb.font = UIFont.systemFont(ofSize: 13)
        openPositonsBgImg.addSubview(self.amountLb)
        self.amountLb.snp.makeConstraints { (mack) in
            mack.left.equalTo(COMPUTE_LENGTH(8))
            mack.width.equalTo(COMPUTE_LENGTH(160))
            mack.top.height.equalTo(mTimeLb)
        }
        
        // invest
        self.investLb = UILabel.init()
        self.investLb.textColor = UIColor.white
        self.investLb.text = "$100"
        self.investLb.textAlignment = .center
        self.investLb.font = UIFont.systemFont(ofSize: 14)
        openPositonsBgImg.addSubview(self.investLb)
        self.investLb.snp.makeConstraints { (mack) in
            mack.top.equalTo(self.amountLb.snp.bottom).offset(COMPUTE_LENGTH(8))
            mack.centerX.equalTo(self.amountLb)
            mack.height.equalTo(self.amountLb.snp.height)
//            mack.height.equalTo(mTimeLb)
        }
    }
    
    func timerS() {
        
        if pr >= 1.0 {
            
            pr = 0
            timer.invalidate()
            progressView.circleBezierPath(bgcolor: UIColor.white, color: kColorWinEnd() ,width: COMPUTE_LENGTH(130) ,endTitle: "win",endTitleColor:kColorWinEnd(),progress: 1.0)
        }else{
            pr = pr + 0.1
            print("\(pr)")
            progressView.circleBezierPath(bgcolor: UIColor.white, color: kColorWinEnd() ,width: COMPUTE_LENGTH(130) ,endTitle: "win",endTitleColor:kColorWinEnd(),progress: pr)
        }
    }

    
    
    //自动生成的报错
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    


}
