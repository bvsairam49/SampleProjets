//
//  ClosePosiTableViewCell.swift
//  podTest2
//
//  Created by Jerry song on 17/2/4.
//  Copyright © 2017年 Test. All rights reserved.
//

import UIKit

/**
 *  BO 交易状态
 */
enum BOTradingStatus {
    case BOTradingStatusProceed
    case BOTradingStatusWin
    case BOTradingStatusLose
    case BOTradingStatusTie
    case BOTradingStatusCount
}




class ClosePosiTableViewCell: UITableViewCell {

    var progressView : ProgressView!
    var pr:CGFloat!
    var timer:Timer!
    
    var symbolLb:UILabel!   // 品种名称
    var endTimeLb :UILabel!  // 结束时间
    var mTimeLb :UILabel!     // 1M,5M,15M
    var amountLb :UILabel!    //  $ 100
    var profitLb :UILabel!
    
    var signImgView :UIImageView!
    
    
    
    
    override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        createUI()
        pr = 0
    }
    
    //  create Open Positions UI
    func createUI() {
        
        //  create cell backgroundImage
        let closePositonsBgImg : UIImageView = UIImageView.init()
//        closePositonsBgImg.image = UIImage(named: "RightView_openPosi_bg")
        closePositonsBgImg.backgroundColor = kColorOpenBackground()
        closePositonsBgImg.isUserInteractionEnabled = true
        self.contentView.addSubview(closePositonsBgImg)
        closePositonsBgImg.snp.makeConstraints { (mack) in
            mack.top.equalTo(COMPUTE_LENGTH(8))
            mack.left.right.height.equalTo(self.contentView)
            
        }
        
        progressView = ProgressView.init()
    

        closePositonsBgImg.addSubview(progressView)
        progressView.snp.makeConstraints { (mack) in
            mack.top.equalTo(COMPUTE_LENGTH(40))
            mack.left.equalTo(COMPUTE_LENGTH(22))
            mack.width.equalTo(COMPUTE_LENGTH(130))
            mack.height.equalTo(COMPUTE_LENGTH(129))
            
        }
        //定时器
        timer = Timer.scheduledTimer(timeInterval: 0.5, target: self, selector: #selector(timerS), userInfo: nil, repeats: true)
        
        
        self.symbolLb = UILabel.init()
        self.symbolLb.textColor = kColorTimeframeNormal()
        self.symbolLb.font = UIFont.systemFont(ofSize: 13)
        closePositonsBgImg.addSubview(self.symbolLb)
        self.symbolLb.snp.makeConstraints { (mack) in
            mack.top.equalTo(COMPUTE_LENGTH(8))
            mack.left.equalTo(progressView.snp.right).offset(COMPUTE_LENGTH(40))
            mack.right.equalTo(self.contentView.snp.right)
            mack.height.equalTo(COMPUTE_LENGTH(50))
        }
        
        // trading  up or down icon
        self.signImgView = UIImageView.init()
        signImgView.image = UIImage(named: "Trading_up-icon")
        closePositonsBgImg.addSubview(self.signImgView)
        self.signImgView.snp.makeConstraints { (mack) in
            mack.top.equalTo(COMPUTE_LENGTH(16))
            mack.right.equalTo(closePositonsBgImg.snp.right).offset(-COMPUTE_LENGTH(60))
            mack.width.equalTo(COMPUTE_LENGTH(40))
            mack.height.equalTo(COMPUTE_LENGTH(33))
        }
        
        
        self.endTimeLb = UILabel.init()
        self.endTimeLb.text = "11:23:52"
        self.endTimeLb.font = UIFont.systemFont(ofSize: 10)
        self.endTimeLb.textColor = kColorTimeframeNormal()
        closePositonsBgImg.addSubview(self.endTimeLb)
        self.endTimeLb.snp.makeConstraints { (mack) in
            mack.top.equalTo(self.symbolLb.snp.bottom).offset(COMPUTE_LENGTH(10))
            mack.left.width.height.equalTo(symbolLb)
        }
        
        
        // M  trading end time
        self.mTimeLb = UILabel.init()
        self.mTimeLb.textColor = kColorTimeframeNormal()
        self.mTimeLb.text = "M15"
        self.mTimeLb.font = UIFont.systemFont(ofSize: 13)
        closePositonsBgImg.addSubview(self.mTimeLb)
        self.mTimeLb.snp.makeConstraints { (mack) in
            mack.top.equalTo(endTimeLb)
            mack.left.equalTo(closePositonsBgImg.snp.right).offset(-COMPUTE_LENGTH(120))
            mack.width.height.equalTo(symbolLb)
        }
        // Amount
        self.amountLb = UILabel.init()
        self.amountLb.textColor = kColorTimeframeNormal()
        self.amountLb.text = "$100"
        self.amountLb.font = UIFont.systemFont(ofSize: 13)
        closePositonsBgImg.addSubview(self.amountLb)
        self.amountLb.snp.makeConstraints { (mack) in
            mack.top.equalTo(endTimeLb.snp.bottom).offset(COMPUTE_LENGTH(10))
            mack.left.width.equalTo(endTimeLb)
            mack.height.equalTo(COMPUTE_LENGTH(80))
        }
        
        self.profitLb = UILabel.init()
        self.profitLb.textColor =  kColorWinEnd()
//        self.profitLb.text = "$78"
        self.profitLb.font = UIFont.systemFont(ofSize: 15)
        closePositonsBgImg.addSubview(self.profitLb)
        self.profitLb.snp.makeConstraints { (mack) in
            mack.top.equalTo(amountLb.snp.top)
            mack.left.equalTo(self.mTimeLb.snp.left).offset(-COMPUTE_LENGTH(20))
            mack.right.equalTo(closePositonsBgImg.snp.right)
            
        }
    }
    
    func timerS() {
        
//        if pr == 0 {
//            
//            pr = 0
//            timer.invalidate()
//            
//        }else{
//            pr = pr + 0.1
//            print("\(pr)")
//            progressView.circleBezierPath(bgcolor: UIColor.white, color: UIColor.purple ,width: COMPUTE_LENGTH(130) ,endTitle: "LOSS", progress: pr)
//        }
    }
    
   // MARK: - 暂用这个方法
    
    func boTradingStatusFunction(boTradingStatus : BOTradingStatus) {
        
        if  boTradingStatus == .BOTradingStatusWin{
            
            progressViewCenter(coloer: kColorWinEnd(), lable: "WIN",lableColor:kColorWinEnd())
            
        }else if boTradingStatus == .BOTradingStatusLose{
           
            progressViewCenter(coloer: kColorLossEnd(), lable: "LOSS",lableColor:kColorLossEnd())
            self.profitLb.text = "-$79"
            self.profitLb.textColor =  kColorLossEnd()
            signImgView.image = UIImage(named: "Trading_down-icon")
        }else if boTradingStatus == .BOTradingStatusTie{
            
            progressViewCenter(coloer: kColorTieEnd(), lable: "TIE",lableColor:kColorTieEnd())
            self.profitLb.textColor =  UIColor.white
        }

    }
    
    func progressViewCenter(coloer : UIColor , lable : String ,lableColor : UIColor) {
        pr = 0
        timer.invalidate()
        progressView.circleBezierPath(bgcolor: UIColor.white, color: coloer ,width: COMPUTE_LENGTH(130) ,endTitle: lable,endTitleColor:lableColor, progress: 1.0)
        
    }
    
    
    //自动生成的报错
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }


}
