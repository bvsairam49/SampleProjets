//
//  progressView.swift
//  MobileBinaryOptions
//
//  Created by Jerry song on 17/2/8.
//  Copyright © 2017年 Broctagon. All rights reserved.
//

import UIKit

class ProgressView: UIView {

    var shapeLayer:CAShapeLayer!
    var BGShapeLayer:CAShapeLayer!
    var lable:UILabel!
    
    public func circleBezierPath(bgcolor:UIColor,color:UIColor,width:CGFloat,endTitle:String,endTitleColor:UIColor,progress:CGFloat) {
        
        //标签
        if lable == nil {
            
            lable = UILabel.init()
            self.addSubview(lable)
            lable.textColor = endTitleColor
            lable.font = UIFont.systemFont(ofSize: 12)
            lable.textAlignment = .center
            lable.snp.makeConstraints({ (mack) in
                mack.centerY.equalTo(self)
                mack.centerX.equalTo(self)
                
            })
        }
        
        
        //背景圈
        BGShapeLayer = CAShapeLayer.init()
        BGShapeLayer.frame = CGRect.init(x: 0, y: 0, width: width, height: width)
        BGShapeLayer.fillColor = UIColor.clear.cgColor
        BGShapeLayer.strokeColor = bgcolor.cgColor
        BGShapeLayer.lineWidth = 2.0
        BGShapeLayer.strokeStart = 0
        BGShapeLayer.strokeEnd = 1
        BGShapeLayer.lineDashPattern = [2,2]
        
        //显示圈
        shapeLayer = CAShapeLayer.init()
        shapeLayer.frame = CGRect.init(x: 0, y: 0, width: width, height: width)
        shapeLayer.fillColor = UIColor.clear.cgColor
        shapeLayer.strokeColor = color.cgColor
        shapeLayer.lineWidth = 2.0
        shapeLayer.strokeStart = 0
        shapeLayer.strokeEnd = progress
        shapeLayer.lineDashPattern = [2,2]
        
        let circlePath = UIBezierPath.init(ovalIn: CGRect.init(x: 0, y: 0, width: width, height: width))
        BGShapeLayer.path = circlePath.cgPath
        self.layer.addSublayer(BGShapeLayer)
        shapeLayer.path = circlePath.cgPath
        self.layer.addSublayer(shapeLayer)
        
        if progress >= 1.0 {
            lable.text = endTitle
        }else{
            lable.text = String(describing: progress)
        }
        
    }
}
