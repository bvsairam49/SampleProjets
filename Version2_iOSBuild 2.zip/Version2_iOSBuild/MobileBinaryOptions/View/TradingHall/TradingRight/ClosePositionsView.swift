//
//  ClosePositionsVC.swift
//  podTest2
//
//  Created by Jerry song on 17/2/4.
//  Copyright © 2017年 Test. All rights reserved.
//

import UIKit



//  create a delegate function
protocol ClosePositionsViewDelegate : NSObjectProtocol {
    
    func closeClosePositionsViewTableView();
    func createTradingParticularsView(titleLb :String ,profit profitLb:String);
    func createPushTradingHistroy()
    
}


class ClosePositionsView: UIView,UITableViewDataSource,UITableViewDelegate {
    weak var delegate :ClosePositionsViewDelegate?
    
    //  tableView
    var tableView :UITableView!
    //   重用标识
    var identifier :String!
    var itemStringArr :[String]!
    var profitArr :[String]!
    var endArray :[String] = []
    
//    var headerView = UIView()
    
    func createUI() {
        
        createHeadView()
        createFootHistoryView()

        self.identifier = "cell"
        self.itemStringArr = ["EURUSDbo","EURUSD","AREUSDbo"]
        self.profitArr = ["$60","80","$100"]
        // win loss tie
        self.endArray = ["WIN","LOSS","TIE"]
        
        self.tableView = UITableView.init()
        tableView.delegate = self
        tableView.dataSource = self
        tableView.separatorColor = UIColor.clear
        tableView.backgroundColor = UIColor.clear
        self.addSubview(tableView)
        //注册 纯代码 cell
        tableView.register(ClosePosiTableViewCell.self, forCellReuseIdentifier: self.identifier)
        
        tableView.snp.makeConstraints { (mack) in
            mack.top.equalTo(COMPUTE_LENGTH(82))
            mack.left.right.equalTo(self)
            mack.bottom.equalTo(self).offset(-COMPUTE_LENGTH(130))
        }
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return itemStringArr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: self.identifier)as! ClosePosiTableViewCell
        cell.backgroundColor = UIColor.clear
//        cell.selectionStyle = UITableViewCellSelectionStyleNone
        //赋值
        cell.symbolLb.text = "\(self.itemStringArr[indexPath.row])"
        cell.profitLb.text = "\(self.profitArr[indexPath.row])"
        if indexPath.row == 0 {
            cell.boTradingStatusFunction(boTradingStatus: .BOTradingStatusWin)
        }
        if indexPath.row == 1 {
            cell.boTradingStatusFunction(boTradingStatus: .BOTradingStatusLose)
        }
        if indexPath.row == 2 {
            cell.boTradingStatusFunction(boTradingStatus: .BOTradingStatusTie)
        }
        
        return cell
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        
        self.delegate?.createTradingParticularsView(titleLb: self.itemStringArr[indexPath.row], profit: self.profitArr[indexPath.row])
        
        print(self.itemStringArr[indexPath.row])
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        return 80.0
    }
    
    func createHeadView() {
        //  创建tableView 的头部视图
        let headImage :UIImageView = UIImageView.init()
        headImage.image = UIImage(named: "RightView_head_bg")
        headImage.isUserInteractionEnabled = true

        self.addSubview(headImage)
        headImage.snp.makeConstraints { (mack) in
            mack.top.equalTo(0)
            mack.left.equalTo(0)
            mack.width.equalTo(self)
            mack.height.equalTo(COMPUTE_LENGTH(82))
        }
        
        //  Create TableView headView closeBtn
        let closeBtn = UIButton(type: .custom)
        closeBtn.frame = CGRect.init(x: 4, y:4, width: COMPUTE_LENGTH(55), height: COMPUTE_LENGTH(55))
        closeBtn.setBackgroundImage(UIImage(named:"RightView_back_icon"), for: .normal)
        closeBtn.addTarget(self, action: #selector(closeTableView), for: .touchUpInside)
        headImage.addSubview(closeBtn)
        
        //  Closed podsitions
        let closedLb = UILabel.init()
        closedLb.text = "Closed positions"
        closedLb.font = UIFont.systemFont(ofSize: 13)
        closedLb.textColor = kColorTimeframeNormal()
        closedLb.textAlignment = .center
        closedLb.frame = CGRect.init(x: 0, y: 4, width: 150, height: COMPUTE_LENGTH(50))
        headImage.addSubview(closedLb)

        
    }
    
    //  Full Trade History View
    func createFootHistoryView() {
        let footHistoryView :UIView = UIView.init()

        footHistoryView.backgroundColor = kColorOpenBackground()
        self.addSubview(footHistoryView)
        footHistoryView.snp.makeConstraints { (mack) in
            mack.top.equalTo(COMPUTE_LENGTH(958))
            mack.left.equalTo(0)
            mack.width.equalTo(self)
            mack.height.equalTo(COMPUTE_LENGTH(120))
        }
        
        //  Create TableView  historyBtn
        let historyBtn = UIButton(type: .custom)
        historyBtn.setTitle("Full Trade History", for: .normal)
        historyBtn.setTitleColor(kColorTimeframeNormal(), for: .normal)
       
        historyBtn.titleLabel?.font = UIFont.systemFont(ofSize: 11)
    historyBtn.setBackgroundImage(UIImage(named:"Open-positions"), for: .normal)
        historyBtn.addTarget(self, action: #selector(openPushTradingHistroy), for: .touchUpInside)
        footHistoryView.addSubview(historyBtn)
        historyBtn.snp.makeConstraints { (mack) in
            mack.centerY.equalTo(footHistoryView)
            mack.left.equalTo(COMPUTE_LENGTH(44))
            mack.right.equalTo(self.snp.right).offset(-COMPUTE_LENGTH(22))
            mack.height.equalTo(COMPUTE_LENGTH(80))
            
        }
    }
    
    
    func closeTableView() {
        
        
        
        self.delegate?.closeClosePositionsViewTableView()
        
    }
    //  push TradingHistroyVC
    func openPushTradingHistroy() {
        self.delegate?.createPushTradingHistroy()
        
        
    }
    
}
