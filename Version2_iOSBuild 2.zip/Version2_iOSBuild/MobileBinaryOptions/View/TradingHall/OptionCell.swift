//
//  OptionCell.swift
//  MobileBinaryOptions
//
//  Created by GE on 17/1/20.
//  Copyright © 2017年 pc003. All rights reserved.
//

import UIKit

protocol OptionCellDelegate :NSObjectProtocol {
    func showIndicatorSettingView(indicatorType: IndicatorType)
}

class OptionCell: UITableViewCell {
    
    @IBOutlet weak var settingBtn: BaseBtn!
    @IBOutlet weak var infoLb: UILabel!
    @IBOutlet weak var tickOnImgView: UIImageView!
    @IBOutlet weak var separateLine: UIView!
    
    var info = ""
    
    var _isShowSetting = false
    var isShowSetting: Bool {
        get {
            return _isShowSetting
        }
        set {
            _isShowSetting = newValue
            self.settingBtn.isHidden = !_isShowSetting
        }
    }
    
    var _isTickedOn = false
    var isTickedOn: Bool {
        get {
            return _isTickedOn
        }
        set {
            _isTickedOn = newValue
            
            if self.isShowSetting {
                self.settingBtn.isSelected = _isTickedOn
            }
        }
    }
    
    weak var delegate: OptionCellDelegate?
    var indicatorType = IndicatorType.zero

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        self.backgroundColor = .clear
        
        self.settingBtn.setImage(UIImage(named: "setting_normal.png"), for: .normal)
        self.settingBtn.setImage(UIImage(named: "setting_press.png"), for: .selected)
        let inset = 15.0 - COMPUTE_LENGTH(40.0 / 2.0)
        self.settingBtn.imageEdgeInsets = UIEdgeInsetsMake(inset, inset, inset, inset)
        
        self.infoLb.textColor = kColorTimeframeNormal()
        self.infoLb.font = FONT_CUSTOM(10.0)
        
        self.tickOnImgView.image = UIImage(named: "checkMark.png")
        
        self.infoLb.snp.makeConstraints { (make) in
            make.left.equalTo(self.settingBtn.snp.right)
            make.centerX.equalTo(self)
            make.centerY.equalTo(self)
        }
        
        self.separateLine.snp.makeConstraints { (make) in
            make.left.equalTo(COMPUTE_LENGTH(14.0))
            make.right.equalTo(self).offset(-COMPUTE_LENGTH(14.0))
            make.bottom.equalTo(self).offset(-1)
            make.height.equalTo(1)
        }
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        self.infoLb.text = self.info
        
        if self.isShowSetting {
            self.infoLb.textAlignment = .left
            self.settingBtn.snp.remakeConstraints({ (make) in
                make.left.equalTo(COMPUTE_LENGTH(38.0 - 15.0))
                make.width.height.equalTo(30.0)
                make.centerY.equalTo(self)
            })
        }else {
            self.infoLb.textAlignment = .center
            self.settingBtn.snp.remakeConstraints({ (make) in
                make.left.equalTo(COMPUTE_LENGTH(20.0))
                make.top.width.height.equalTo(0)
            })
        }
        
        if self.isTickedOn {
            self.tickOnImgView.snp.remakeConstraints({ (make) in
                make.right.equalTo(self).offset(-COMPUTE_LENGTH(38.0))
                make.width.equalTo(COMPUTE_LENGTH(32.0))
                make.height.equalTo(COMPUTE_LENGTH(26.0))
                make.centerY.equalTo(self)
            })
        }else {
            self.tickOnImgView.snp.remakeConstraints({ (make) in
                make.right.equalTo(self).offset(-COMPUTE_LENGTH(38.0))
                make.top.width.height.equalTo(0)
            })
        }
    }
    
    @IBAction func showSettingView(_ sender: BaseBtn) {
        self.delegate?.showIndicatorSettingView(indicatorType: self.indicatorType)
    }

    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
