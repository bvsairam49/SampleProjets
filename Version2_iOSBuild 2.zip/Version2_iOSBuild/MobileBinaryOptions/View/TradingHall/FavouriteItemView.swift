//
//  FavouriteItemView.swift
//  MobileBinaryOptions
//
//  Created by GE on 17/2/4.
//  Copyright © 2017年 Broctagon. All rights reserved.
//

import UIKit

protocol FavouriteItemViewDelegate : NSObjectProtocol {
    func itemViewDidSelect(itemView: FavouriteItemView)
    func itemViewDidRemove(itemView: FavouriteItemView)
}

class FavouriteItemView: UIView {
    let infoLabel = UILabel()
    let underLineView = UIView()
    let deleteBtn = BaseBtn()
    
    var symbol = ""
    var timeframe = ""
    
    var isSelected = false
    var isProceed = false   // if true, symbol has trade in proceed, twinkle self
    
    weak var delegate :FavouriteItemViewDelegate?
    
    init(symbol: String, timeframe: String) {
        super.init(frame: .zero)
        
        self.symbol = symbol
        self.timeframe = timeframe
        
        self.createUI()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func createUI() {
        self.addSubview(self.infoLabel)
        self.addSubview(self.underLineView)
        self.addSubview(self.deleteBtn)
        
        self.infoLabel.font = FONT_CUSTOM(7.0)
        self.infoLabel.textAlignment = .center
        self.infoLabel.numberOfLines = 2
        self.infoLabel.textColor = kColorTimeframeNormal()
        self.infoLabel.text = self.symbol + "\n" + self.timeframe
        self.infoLabel.snp.makeConstraints { (make) in
            make.edges.equalTo(self)
        }
        
        self.underLineView.snp.makeConstraints { (make) in
            make.left.right.bottom.equalTo(self)
            make.height.equalTo(1.0)
        }
        
        self.deleteBtn.setImage(UIImage(named: "delete_normal.png"), for: .normal)
        self.deleteBtn.snp.makeConstraints { (make) in
            make.bottom.right.equalTo(self.underLineView)
            make.width.height.equalTo(COMPUTE_LENGTH(30.0 + 10.0))
        }
    }
}
