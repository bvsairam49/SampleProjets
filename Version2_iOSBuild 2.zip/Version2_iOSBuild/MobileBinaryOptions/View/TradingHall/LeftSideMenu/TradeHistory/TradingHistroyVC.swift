//
//  TradingHistroyVC.swift
//  MobileBinaryOptions
//
//  Created by ALOK KUMAR on 07/02/17.
//  Copyright © 2017 Broctagon. All rights reserved.
//

import UIKit

class TradingHistroyVC: BaseVC ,UITableViewDelegate,UITableViewDataSource  {

    var accBackGroundView = UIView()
    
    // Header Label
    var accHeaderView = UIView()
    var accHeaderSecondView = UIView()
    var accManagementLabel = UILabel()
    var accManagementCancelBtn = UIButton()
     var OrderNumberLabel = UILabel()
    var dateLabel  = UILabel()
    var symbolLabel = UILabel()
    var actionLabel = UILabel()
    var openLabel = UILabel()
    var closeLabel = UILabel()
    var amountLabel = UILabel()
    var profitLabel = UILabel()
    var internalLabel = UILabel()
    var resultLabel = UILabel()
    let DisplaytableView = UITableView()
    
    //cell data
    var orderArray = NSMutableArray()
    var dateArray =  NSMutableArray()
    var symbolArray = NSMutableArray()
    var amountArray = NSMutableArray()
    var profitArray = NSMutableArray()
    var intervalArray = NSMutableArray()
    var resultArray = NSMutableArray()
    
    // Account management Page
    var profileBtn  = UIButton()
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.createUIForAccountManagement()
        self.createHeadingLabel()
        self.creationOfTable()
       orderArray = ["876543234","567543621","854123907","567890123","567543621","854123907","567890123"]
        
          symbolArray = ["EURUSDbo","USDJPYbo","GBPUSDbo","USDCvaro","USDADBbo","NZDUSDbo","EURGBPbo"]
        
        amountArray = ["$35","$45","$25","$35","$45","$25","$32"]
        
        profitArray = ["$ -200(78%)","$ -200(78%)","$ -300(78%)","$ -100(78%)","$ -200(78%)","$ -200(78%)","$ -200(78%)"]
        
        intervalArray = ["1.2M","1.6M","1.4M","1.5M","1.7M","1.8M","1.9M"]
        
        resultArray  = ["win","Loss","win","Loss","win","Loss","Loss"]
        
        

//        DisplaytableView.delegate      =   self
//        DisplaytableView.dataSource    =   self
        
        
    }
    
    // MARK:- Create UI for Controls.
    func createUIForAccountManagement(){
        
        // AccountManagementBG view
        let frame = CGRect(x: CGFloat(0), y: CGFloat(0), width: SCREEN_WIDTH(), height: SCREEN_HEIGHT())
        let backgroundImage = UIImageView(frame: frame)
        backgroundImage.image = UIImage(named: "landscape_background@3x.png")
        self.accBackGroundView.insertSubview(backgroundImage, at: 0)
        self.view.addSubview(self.accBackGroundView)
        
        //Header view
        accHeaderView = UIView(frame: CGRect(x: 10, y:10, width: SCREEN_WIDTH()-20, height: 44))
        accHeaderView.backgroundColor = UIColor.clear
        accHeaderView.backgroundColor = UIColor.init(patternImage: UIImage(named: "bg2.png")!)
        self.view.addSubview(accHeaderView)
        //Second header View
       accHeaderSecondView = UIView(frame: CGRect(x: 10, y:55, width: SCREEN_WIDTH()-20, height: 35))
       accHeaderSecondView.backgroundColor = UIColor.clear
       accHeaderSecondView.backgroundColor = UIColor.init(patternImage: UIImage(named: "title_bg@3x.png")!)
        self.view.addSubview(accHeaderSecondView)
        
        // Title label
//        accManagementLabel = UILabel(frame: CGRect(x: 0, y:0, width: SCREEN_WIDTH(), height: 44))
//        accManagementLabel.text = "Account Management"
//        accManagementLabel.textColor = UIColor.yellow
//        accManagementLabel.textAlignment = .center
//        accManagementLabel.font = UIFont.systemFont(ofSize: 20)
//        accHeaderView.addSubview(accManagementLabel)
        
        //  cancel Button
        accManagementCancelBtn = UIButton(frame: CGRect(x:(SCREEN_WIDTH() * 2/100), y:10, width: 20, height: 20))
        accManagementCancelBtn.setImage(UIImage(named: "back_icon@3x.png"), for: .normal)
        // accManagementCancelBtn.addTarget(self, action:#selector(self.backBtnAction), for: .touchUpInside)
        accHeaderView.addSubview(accManagementCancelBtn)
         accManagementCancelBtn.addTarget(self, action: #selector(buttonAction), for: .touchUpInside)
        
        // Heading button
        profileBtn = UIButton(frame: CGRect(x: (SCREEN_WIDTH()*25/100), y:20, width: ((SCREEN_WIDTH()-(SCREEN_WIDTH()*52/100))/1), height: 30))
        profileBtn.setImage(UIImage(named: "mt4-icon@3x.png"), for: .normal)
        profileBtn.setTitle("Full Trade History", for: .normal)
        profileBtn.titleEdgeInsets = UIEdgeInsetsMake(0, 10, 0, -10)
        profileBtn.titleLabel?.font = UIFont.systemFont(ofSize: 16)
        // profileBtn.addTarget(self, action:#selector(self.backBtnAction), for: .touchUpInside)
        self.view.addSubview(profileBtn)
    }
    //action  called for backButton
    func buttonAction(sender: UIButton!) {
        let _ = self.navigationController?.popViewController(animated: true)
    }
    
    
    func createHeadingLabel(){
        
                OrderNumberLabel = UILabel(frame: CGRect(x:(SCREEN_WIDTH() * -43/100), y:-5, width: SCREEN_WIDTH(), height: 44))
                OrderNumberLabel.text = "#Order\n Number"
                OrderNumberLabel.textColor = UIColor.white
                OrderNumberLabel.textAlignment = .center
                OrderNumberLabel.font = UIFont.systemFont(ofSize: 10)
                OrderNumberLabel.lineBreakMode = NSLineBreakMode.byWordWrapping
                OrderNumberLabel.numberOfLines = 0
               accHeaderSecondView.addSubview(OrderNumberLabel)
        
             dateLabel = UILabel(frame: CGRect(x: (SCREEN_WIDTH() * -34/100), y:-5, width: SCREEN_WIDTH(), height: 44))
             dateLabel .text = "Date"
             dateLabel .textColor = UIColor.white
             dateLabel .textAlignment = .center
             dateLabel .font = UIFont.systemFont(ofSize: 10)
             dateLabel .lineBreakMode = NSLineBreakMode.byWordWrapping
            accHeaderSecondView.addSubview(dateLabel )
        
        
       symbolLabel = UILabel(frame: CGRect(x: (SCREEN_WIDTH() * -25/100), y:-5, width: SCREEN_WIDTH(), height: 44))
        symbolLabel .text = "Symbol"
       symbolLabel .textColor = UIColor.white
        symbolLabel .textAlignment = .center
        symbolLabel .font = UIFont.systemFont(ofSize: 10)
       symbolLabel.lineBreakMode = NSLineBreakMode.byWordWrapping
       accHeaderSecondView.addSubview(symbolLabel)
        
        
        actionLabel = UILabel(frame: CGRect(x: (SCREEN_WIDTH() * -16/100), y:-5, width: SCREEN_WIDTH(), height: 44))
      actionLabel .text = "Action"
       actionLabel .textColor = UIColor.white
       actionLabel .textAlignment = .center
        actionLabel .font = UIFont.systemFont(ofSize: 10)
       actionLabel.lineBreakMode = NSLineBreakMode.byWordWrapping
        accHeaderSecondView.addSubview(actionLabel)

        openLabel = UILabel(frame: CGRect(x: (SCREEN_WIDTH() * -7/100), y:-5, width: SCREEN_WIDTH(), height: 44))
        openLabel .text = "Open"
        openLabel .textColor = UIColor.white
        openLabel .textAlignment = .center
        openLabel .font = UIFont.systemFont(ofSize: 10)
        openLabel.lineBreakMode = NSLineBreakMode.byWordWrapping
        accHeaderSecondView.addSubview(openLabel)
        
        closeLabel = UILabel(frame: CGRect(x: (SCREEN_WIDTH() * -0/100), y:-5, width: SCREEN_WIDTH(), height: 44))
         closeLabel .text = "Close"
         closeLabel .textColor = UIColor.white
         closeLabel .textAlignment = .center
        closeLabel .font = UIFont.systemFont(ofSize: 10)
         closeLabel.lineBreakMode = NSLineBreakMode.byWordWrapping
        accHeaderSecondView.addSubview( closeLabel)
       
        amountLabel = UILabel(frame: CGRect(x: (SCREEN_WIDTH() * 10/100), y:-5, width: SCREEN_WIDTH(), height: 44))
         amountLabel .text = "Amount"
         amountLabel .textColor = UIColor.white
         amountLabel .textAlignment = .center
         amountLabel .font = UIFont.systemFont(ofSize: 10)
         amountLabel.lineBreakMode = NSLineBreakMode.byWordWrapping
        accHeaderSecondView.addSubview(  amountLabel)
        
        profitLabel  = UILabel(frame: CGRect(x: (SCREEN_WIDTH() * 20/100), y:-5, width: SCREEN_WIDTH(), height: 44))
       profitLabel .text = "profit"
        profitLabel .textColor = UIColor.white
       profitLabel .textAlignment = .center
        profitLabel .font = UIFont.systemFont(ofSize: 10)
        profitLabel.lineBreakMode = NSLineBreakMode.byWordWrapping
        accHeaderSecondView.addSubview(profitLabel)
        
        
        internalLabel  = UILabel(frame: CGRect(x: (SCREEN_WIDTH() * 29/100), y:-5, width: SCREEN_WIDTH(), height: 44))
         internalLabel .text = "Interval"
         internalLabel  .textColor = UIColor.white
        internalLabel  .textAlignment = .center
        internalLabel  .font = UIFont.systemFont(ofSize: 10)
       internalLabel .lineBreakMode = NSLineBreakMode.byWordWrapping
        accHeaderSecondView.addSubview ( internalLabel )

        
       resultLabel  = UILabel(frame: CGRect(x: (SCREEN_WIDTH() * 39/100), y:-5, width: SCREEN_WIDTH(), height: 44))
        resultLabel .text = "Result"
        resultLabel .textColor = UIColor.white
        resultLabel .textAlignment = .center
        resultLabel .font = UIFont.systemFont(ofSize: 10)
        resultLabel.lineBreakMode = NSLineBreakMode.byWordWrapping
        accHeaderSecondView.addSubview(resultLabel)
        
    
        
    }
    
    func creationOfTable(){
        
        
        DisplaytableView.frame = CGRect(x: 10, y: 91, width: SCREEN_WIDTH()-20, height: SCREEN_HEIGHT()-(SCREEN_HEIGHT()*27/100))
        DisplaytableView.bounces = true
        DisplaytableView.backgroundView = UIImageView(image: UIImage(named: "landscape_background@3x.png"))
//        DisplaytableView.backgroundColor = UIColor.clear
        DisplaytableView.layoutMargins = UIEdgeInsets.zero
        DisplaytableView.separatorInset = UIEdgeInsets.zero
        DisplaytableView.dataSource = self
        DisplaytableView.delegate = self
//        DisplaytableView.contentInset = UIEdgeInsetsMake(0, 0, 120, 0)
        DisplaytableView.allowsSelection = true
        DisplaytableView.reloadData()
        self.view.addSubview(DisplaytableView)
//    DisplaytableView.frame = CGRect(x: 10, y: 91, width: SCREEN_WIDTH()-20, height: 302)
//        print("hight",SCREEN_HEIGHT())
//        
//        DisplaytableView.backgroundView = UIImageView(image: UIImage(named: "landscape_background@3x.png"))
//        
//        self.view.addSubview(DisplaytableView)
//        
        
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return orderArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell: HistoryCell? = nil
//        let cellIdentifier: String = "\("Cell")\(Int(indexPath.row))"
        let cellIdentifier: String = "HistoryCell"
        cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier) as! HistoryCell?
        
        if cell == nil {
            cell = HistoryCell(style: .default, reuseIdentifier: cellIdentifier)
        }
        
        cell?.tblOrderNumberLabel.text = orderArray[indexPath.row] as? String
        cell?.tblDateLabel .text = "12-07-2016\n 18:3254"
        cell?.tblSymbolLabel .text =  symbolArray[indexPath.row] as? String
        
        if cell?.tblResultLabel.text == "win" {
            cell?.actionImgView.image = UIImage(named: "Trading_down-icon.png")
            cell?.tblResultLabel.textColor = UIColor.red
    
        }
        else{
            cell?.actionImgView.image = UIImage(named: "Trading_up-icon.png")
            cell?.tblResultLabel.textColor = UIColor.green
        }
        
        cell?.tblOpenLabel .text = "0.6758"
        cell?.tblCloseLabel .text = "0.6756"
        cell?.tblAmountLabel .text = amountArray[indexPath.row] as? String
        cell?.tblProfitLabel .text = profitArray[indexPath.row] as? String
        cell?.tblInternalLabel .text = intervalArray[indexPath.row] as? String
        cell?.tblResultLabel.text = resultArray[indexPath.row] as? String
        
        return cell!
    }
    
    func tableView(_ tableView: UITableView, shouldHighlightRowAt indexPath: IndexPath) -> Bool {
        return false
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override var shouldAutorotate: Bool {
        return true
    }
    
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return .landscape
    }
    


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
