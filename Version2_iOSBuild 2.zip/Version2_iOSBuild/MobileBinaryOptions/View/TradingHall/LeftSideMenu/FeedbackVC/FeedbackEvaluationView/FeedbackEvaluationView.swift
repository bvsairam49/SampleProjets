//
//  FeedbackEvaluationView.swift
//  MobileBinaryOptions
//
//  Created by Anandh on 2/10/17.
//  Copyright © 2017 Broctagon. All rights reserved.
//

import UIKit

class FeedbackEvaluationView: UIView {
    
    // BackGroundView
    var feedbackevolutionView = UIView()
    
    // Rate label
    var headerLabel = UILabel()
    
    
    //Star rating View
    var starRatingVIew =  UIView()
    var starButton = UIButton()
    var starcode =  Int()
    var tagValue = Int ()
    
    // Buttons 
    var sendBtn = UIButton()
    
    var cancelBtn = UIButton()
    
    // MARK:- Initializing Frame
    override init(frame: CGRect) {
        super.init(frame:frame)
        self.addControlsForEvolutionView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    // MARK:- Add UI Controls For View
    
    func addControlsForEvolutionView(){
            // FeedBackView
        let frame = CGRect(x: CGFloat(SCREEN_WIDTH()/4), y: CGFloat(SCREEN_HEIGHT()/4), width: SCREEN_WIDTH()/2, height: SCREEN_HEIGHT()/2)
        let backgroundImage = UIImageView(frame: frame)
        backgroundImage.image = UIImage(named: "bg2.png")
        self.feedbackevolutionView.insertSubview(backgroundImage, at: 0)
        self.addSubview(self.feedbackevolutionView)
        
        // Rate Label
        headerLabel = UILabel(frame: CGRect(x: CGFloat((SCREEN_WIDTH()/4)+30), y: CGFloat((SCREEN_HEIGHT()/4)+30), width: SCREEN_WIDTH()/2 - 60, height: 20))
        headerLabel.text = "How would you rate this service?"
        headerLabel.textColor = UIColor.white
        headerLabel.textAlignment = .center
        headerLabel.font = UIFont.systemFont(ofSize: 14)
        feedbackevolutionView.addSubview(headerLabel)
        
        
        
        // Star rating view 
        starRatingVIew.frame = CGRect(x: CGFloat((SCREEN_WIDTH()/3)+40), y: CGFloat(headerLabel.frame.size.height+headerLabel.frame.origin.y+20), width: CGFloat((SCREEN_WIDTH()/3-80)), height: CGFloat(20))
        feedbackevolutionView.addSubview(starRatingVIew)
        for starcode in 0..<5 {
            starButton = UIButton(frame: CGRect(x: CGFloat(20 * starcode), y: CGFloat(0), width: CGFloat(30), height: CGFloat(20)))
            starButton.tag = starcode + 300
            starButton.addTarget(self, action: #selector(self.starRating(_:)), for: .touchUpInside)
            starButton.setImage(UIImage(named: "star_border_press.png"), for: .normal)
            starRatingVIew.addSubview(starButton)
        }
        self.addSubview(starRatingVIew)
        
        // Submit Button
        sendBtn = UIButton(frame: CGRect(x:(headerLabel.frame.origin.x+(SCREEN_WIDTH()/2 - 80)/6), y:(starRatingVIew.frame.size.height+starRatingVIew.frame.origin.y+20), width:(SCREEN_WIDTH()/2 - 80)/3, height: 30))
        sendBtn.setBackgroundImage(UIImage(named: "btn2@3x.png"), for: .normal)
        sendBtn.setTitle("Send", for: .normal)
        sendBtn.titleLabel?.font = UIFont.systemFont(ofSize: 14)
        sendBtn.addTarget(self, action:#selector(self.sendButtonAction(_:)), for: .touchUpInside)
        sendBtn.titleEdgeInsets = UIEdgeInsetsMake(0, 0, 0, -8)
        self.addSubview(sendBtn)
        
        // cancel Button
        cancelBtn = UIButton(frame: CGRect(x:(sendBtn.frame.origin.x+sendBtn.frame.size.width+(SCREEN_WIDTH()/2 - 80)/8), y:(starRatingVIew.frame.size.height+starRatingVIew.frame.origin.y+20), width:(SCREEN_WIDTH()/2 - 80)/3, height: 30))
        cancelBtn.setBackgroundImage(UIImage(named: "btn2@3x.png"), for: .normal)
        cancelBtn.setTitle("Cancel", for: .normal)
        cancelBtn.titleLabel?.font = UIFont.systemFont(ofSize: 14)
        cancelBtn.addTarget(self, action:#selector(self.cancelButtonAction(_:)), for: .touchUpInside)
        cancelBtn.titleEdgeInsets = UIEdgeInsetsMake(0, 0, 0, -8)
        self.addSubview(cancelBtn)
        
    }
    
    
    // MARK:- Button Action Methods
    func starRating(_ sender: UIButton) {
        tagValue = sender.tag
        for starcode in 300..<305 {
            starButton = (starRatingVIew.viewWithTag(starcode) as? UIButton)!
            if starcode <= sender.tag {
                starButton.setImage(UIImage(named: "star_press.png"), for: .normal)
            }
            else {
                starButton.setImage(UIImage(named: "star_border_press.png"), for: .normal)
            }
        }
    }
    
    func sendButtonAction(_ sender: UIButton) {
        sender.isSelected = !sender.isSelected
        if (sender.isSelected) {
            sendBtn.setBackgroundImage(UIImage(named: "btn2_press@3x.png"), for: .normal)
            print("Button action")
        }
        else{
            print("Button")
            sendBtn.setBackgroundImage(UIImage(named: "btn2@3x.png"), for: .normal)
        }
    }
    
    func cancelButtonAction(_ sender: UIButton) {
        sender.isSelected = !sender.isSelected
        if (sender.isSelected) {
            cancelBtn.setBackgroundImage(UIImage(named: "btn2_press@3x.png"), for: .normal)
            print("Button action")
             removeFromSuperview() 
        }
        else{
            print("Button")
            cancelBtn.setBackgroundImage(UIImage(named: "btn2@3x.png"), for: .normal)
            
        }
    }
    
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
