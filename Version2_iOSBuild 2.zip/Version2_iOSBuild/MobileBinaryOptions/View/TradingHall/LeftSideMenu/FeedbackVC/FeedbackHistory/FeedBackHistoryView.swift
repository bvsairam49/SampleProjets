//
//  FeedbackHistoryView.swift
//  MobileBinaryOptions
//
//  Created by Anandh on 2/10/17.
//  Copyright © 2017 Broctagon. All rights reserved.
//

import UIKit

class FeedbackHistoryView: UIView,UITableViewDelegate,UITableViewDataSource {
    
    // FeedBackHistory  BackgroundView
    var  feedBackView = UIView()

     var feedbackHistorytableView: UITableView  =   UITableView()
    
    //Star rating View
    var starRatingVIew =  UIView()
    var starButton = UIButton()
    var starcode =  Int()
    var tagValue = Int ()
    var starWidth = Int()
 
    
    // Buttons
    var feedbackContentBtn = UIButton()
    var feedbackHistoryBtn = UIButton()
    
    var SubheadingArray = NSMutableArray()
     var headingArray = NSMutableArray()
    var reloadArray = NSMutableArray()
    var indexSelectedValue = Int()
     var  imageName = String()
    var  imageName1 = String()
    var serviceImgView = UIImageView()
    var starImgView = UIImageView()
    var selected : Bool? = false

    var selectedCellIndexPath: NSIndexPath?
    let selectedCellHeight: CGFloat = 70.0
    let unselectedCellHeight: CGFloat = 30.0
    

    
    // MARK:- Initializing Frame
    override init(frame: CGRect) {
        super.init(frame:frame)
        self.addControlsForFeedBackContentView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    
    // MARK:- Add Controls For UI
    
    func addControlsForFeedBackContentView()
    {
        headingArray = ["What is the menimum Withdrawal amount for a trade?","","How much profit can be made","","What is the menimum Withdrawal amount for a trade?","","What is the SellingPrice"]
        SubheadingArray = ["The minimum amount withdarwal is 10$","","The minimum amount withdarwal is 10$","","The minimum amount withdarwal is 10$","","The minimum amount withdarwal is 10$"]
        reloadArray = ["Respond","","Respond","","Respond","","Respond"]
        // FeedBackView
//        let frame = CGRect(x: CGFloat(0), y: CGFloat(0), width: SCREEN_WIDTH(), height: SCREEN_HEIGHT()*80/100)
//        let backgroundImage = UIImageView(frame: frame)
//        backgroundImage.image = UIImage(named: "bg2.png")
//        self.feedBackView.insertSubview(backgroundImage, at: 0)
//        self.addSubview(self.feedBackView)
        
        // FeddBackContent Button
        if(SCREEN_WIDTH() <= 568)
        {
            feedbackContentBtn = UIButton(frame: CGRect(x: (SCREEN_WIDTH()*24/100)+10, y:15, width:((SCREEN_WIDTH()-(SCREEN_WIDTH()*48/100))/2), height: 30))
        }
        else
        {
            feedbackContentBtn = UIButton(frame: CGRect(x: (SCREEN_WIDTH()*26/100)+10, y:15, width: ((SCREEN_WIDTH()-(SCREEN_WIDTH()*52/100))/2), height: 30))
        }
        feedbackContentBtn.setTitle("Feedback Content", for: .normal)
        feedbackContentBtn.titleEdgeInsets = UIEdgeInsetsMake(0,-(feedbackContentBtn.frame.size.width/4), 0, 0)
        feedbackContentBtn.titleLabel?.font = UIFont.systemFont(ofSize: 14)
        feedbackContentBtn.titleLabel?.textAlignment = .left
        feedbackContentBtn.alpha = 0.5
        feedbackContentBtn.addTarget(self, action:#selector(self.feedBackContentBtnAction(_:)), for: .touchUpInside)
        self.addSubview(feedbackContentBtn)
        
        // FeddBackHistory Button
        if(SCREEN_WIDTH() <= 568)
        {
            feedbackHistoryBtn = UIButton(frame: CGRect(x:((feedbackContentBtn.frame.origin.x+feedbackContentBtn.frame.size.width+(SCREEN_WIDTH()*48/100)/8)), y:15, width: ((SCREEN_WIDTH()-(SCREEN_WIDTH()*48/100))/2), height: 30))
        }
        else
        {
            feedbackHistoryBtn = UIButton(frame: CGRect(x: (feedbackContentBtn.frame.origin.x+feedbackContentBtn.frame.size.width+(SCREEN_WIDTH()*8/100)), y:15, width: ((SCREEN_WIDTH()-(SCREEN_WIDTH()*52/100))/2), height: 30))
        }
        feedbackHistoryBtn.setTitle("Feedback history", for: .normal)
        feedbackHistoryBtn.titleLabel?.font = UIFont.systemFont(ofSize: 14)
        feedbackHistoryBtn.alpha = 1.0
        // feedbackHistoryBtn.addTarget(self, action:#selector(self.backBtnAction), for: .touchUpInside)
        
        self.addSubview(feedbackHistoryBtn)
        
        // FeedBackHistory Tableview
        feedbackHistorytableView.frame = CGRect(x: CGFloat(SCREEN_WIDTH()*10/100)+10, y: 55, width: CGFloat(SCREEN_WIDTH()-(SCREEN_WIDTH()*20/100)), height: CGFloat(SCREEN_HEIGHT()*72/100))
        //tableView = UITableView
        feedbackHistorytableView.backgroundColor = UIColor.clear
        feedbackHistorytableView.delegate      =   self
        feedbackHistorytableView.dataSource    =   self
        feedbackHistorytableView.register(UITableViewCell.self, forCellReuseIdentifier: "feedbackHistoryTableViewCell")
        self.addSubview(self.feedbackHistorytableView)
        self.feedbackHistorytableView.rowHeight = 70
        feedbackHistorytableView.separatorColor = UIColor.clear
    }
    
   
    // MARK:- Tableview datasource and Delegate Method
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return headingArray.count
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
       
        var cell: feedbackHistoryTableViewCell? = nil
        //        let cellIdentifier: String = "\("Cell")\(Int(indexPath.row))"
        let cellIdentifier: String = "feedbackHistoryTableViewCell"
        cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier) as! feedbackHistoryTableViewCell?
        cell?.backgroundColor = UIColor.clear
        cell?.contentView.backgroundColor = UIColor.clear
        
        
        if cell == nil {
            cell = feedbackHistoryTableViewCell(style: .default, reuseIdentifier: cellIdentifier)
            
          }
         
        cell?.tblHeadinLabel .text = headingArray[indexPath.row] as? String
        cell?.tblHeadinLabel.textColor = UIColor(red:255/255, green:160/255, blue:102/255, alpha:1.0)
        cell?.SubHeadingLabel .text = SubheadingArray[indexPath.row] as? String
        cell?.respond .text = reloadArray[indexPath.row] as? String
        

        if(selected == false){
            cell?.respond.font = UIFont.systemFont(ofSize: 0.0)
            if(indexPath.row == indexSelectedValue){
             cell?.SubHeadingLabel.font = UIFont.systemFont(ofSize: 0.0)
                
            starRatingVIew.isHidden=true
                
              
            }
            
        }else{
            cell?.respond.font = UIFont.systemFont(ofSize: 15.0)
            if(indexPath.row == indexSelectedValue){
                  cell?.SubHeadingLabel.font = UIFont.systemFont(ofSize: 15.0)
                
                
                if(indexPath.row == 0){
                starRatingVIew.isHidden=false
                   
                }
                
            }
            else{
            cell?.SubHeadingLabel.font = UIFont.systemFont(ofSize: 0.0)
                 cell?.respond.font = UIFont.systemFont(ofSize: 0.0)
                if(indexPath.row == 0){
                    starRatingVIew.isHidden=true
                    
                }
            }
            
        }
        
               
       
        return cell!
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
      //  let selectedCellIndexPath: IndexPath?
      print(indexPath.row)
        
       
            if(selected == true){
                feedbackHistorytableView.reloadData()
                selected = false
                
                
            }else{
                
                
                selected = true
                feedbackHistorytableView.reloadData()
                
                
                print("indepax path selected",indexPath.row)
                
                
                
            }
        
        indexSelectedValue=indexPath.row
        
       
    }
    
 func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
    
    print(selected!)
    
    if(selected == true){
        
    if(indexPath.row == indexSelectedValue){
        
        return selectedCellHeight
    }
    else{
        return unselectedCellHeight
        }
    }
    
    else{
        
       return unselectedCellHeight
      }
    }
    
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        
        
        
        if(indexPath.row == 1){
            cell.contentView.alpha = 0.0
            cell.isUserInteractionEnabled = false
            
        }
        if(indexPath.row == 3){
            cell.contentView.alpha = 0.0
            cell.isUserInteractionEnabled = false
        }
        if(indexPath.row == 5){
            cell.contentView.alpha = 0.0
            cell.isUserInteractionEnabled = false
        }
        
        
        if(indexPath.row == 0)
        {
            imageName = "service_icon@3x.png"
            let image = UIImage(named: imageName)
            let imageView = UIImageView(image: image!)
            imageView.frame = CGRect(x: (SCREEN_WIDTH() * 53/100), y:8, width: 15, height: 12)
            print("imagewidth",SCREEN_WIDTH())
            cell.contentView.addSubview(imageView)
            
            imageName1 = "star_border_press@3x.png"
            let image1 = UIImage(named: imageName1)
            let imageView1 = UIImageView(image: image1!)
            imageView1.frame = CGRect(x: (SCREEN_WIDTH() * 57/100), y:8, width: 15, height: 12)
            print("imagewidth",SCREEN_WIDTH())
            cell.contentView.addSubview(imageView1)
          
            starRatingVIew.frame = CGRect(x: CGFloat((SCREEN_WIDTH() * 46/100)+40), y: CGFloat(43), width: CGFloat((SCREEN_WIDTH()/3-80)), height: CGFloat(20))
            cell.contentView.addSubview(starRatingVIew)
            for starcode in 0..<5 {
             starButton = UIButton(frame: CGRect(x: CGFloat(20 * starcode), y: CGFloat(0), width: CGFloat(30), height: CGFloat(20)))
                    //feedbackHistorytableView.reloadData()
                
                starButton.tag = starcode + 300
                starButton.addTarget(self, action: #selector(self.starRating(_:)), for: .touchUpInside)
                starButton.setImage(UIImage(named: "star_border_press.png"), for: .normal)
                starRatingVIew.addSubview(starButton)
            }
            cell.contentView.addSubview(starRatingVIew)
            
            
            
            
        }
        
       
    }
    // MARK:- Button Action Methods
    func starRating(_ sender: UIButton) {
//        tagValue = sender.tag
            var feedbackView = FeedbackEvaluationView()
        feedbackView = FeedbackEvaluationView.init(frame: CGRect(x:0, y:0, width: (SCREEN_WIDTH()), height: SCREEN_HEIGHT()*80/100))
        self.addSubview(feedbackView)
    }
    
    // MARK:- Button Actions
    
    func feedBackContentBtnAction(_ sender:UIButton)
    {
        print("feedbackContentView")
        
    }
    func feedBackHistoryBtnAction(_ sender:UIButton)
    {
        print("feedbackHistory")
    }


    
  
    
    
    // MARK:- Add Controls For UI
    
//    func addControlsForFeedBackContentView()
//    {
//        // FeedBackView
//        let frame = CGRect(x: CGFloat(0), y: CGFloat(0), width: SCREEN_WIDTH(), height: SCREEN_HEIGHT()*80/100)
//        let backgroundImage = UIImageView(frame: frame)
//        backgroundImage.image = UIImage(named: "bg2.png")
//        self.feedBackView.insertSubview(backgroundImage, at: 0)
//        self.addSubview(self.feedBackView)
//        
//        // FeddBackContent Button
//        if(SCREEN_WIDTH() <= 568)
//        {
//            feedbackContentBtn = UIButton(frame: CGRect(x: (SCREEN_WIDTH()*24/100)+10, y:15, width:((SCREEN_WIDTH()-(SCREEN_WIDTH()*48/100))/2), height: 30))
//        }
//        else
//        {
//            feedbackContentBtn = UIButton(frame: CGRect(x: (SCREEN_WIDTH()*26/100)+10, y:15, width: ((SCREEN_WIDTH()-(SCREEN_WIDTH()*52/100))/2), height: 30))
//        }
//        feedbackContentBtn.setTitle("Feedback Content", for: .normal)
//        feedbackContentBtn.titleEdgeInsets = UIEdgeInsetsMake(0,-(feedbackContentBtn.frame.size.width/4), 0, 0)
//        feedbackContentBtn.titleLabel?.font = UIFont.systemFont(ofSize: 14)
//        feedbackContentBtn.titleLabel?.textAlignment = .left
//        feedbackContentBtn.alpha = 0.5
//        // feedbackContentBtn.addTarget(self, action:#selector(self.backBtnAction), for: .touchUpInside)
//        self.addSubview(feedbackContentBtn)
//        
//        // FeddBackHistory Button
//        if(SCREEN_WIDTH() <= 568)
//        {
//            feedbackHistoryBtn = UIButton(frame: CGRect(x:((feedbackContentBtn.frame.origin.x+feedbackContentBtn.frame.size.width+(SCREEN_WIDTH()*48/100)/8)), y:15, width: ((SCREEN_WIDTH()-(SCREEN_WIDTH()*48/100))/2), height: 30))
//        }
//        else
//        {
//            feedbackHistoryBtn = UIButton(frame: CGRect(x: (feedbackContentBtn.frame.origin.x+feedbackContentBtn.frame.size.width+(SCREEN_WIDTH()*8/100)), y:15, width: ((SCREEN_WIDTH()-(SCREEN_WIDTH()*52/100))/2), height: 30))
//        }
//        feedbackHistoryBtn.setTitle("Feedback history", for: .normal)
//        feedbackHistoryBtn.titleLabel?.font = UIFont.systemFont(ofSize: 14)
//        feedbackHistoryBtn.alpha = 1.0
//        // feedbackHistoryBtn.addTarget(self, action:#selector(self.backBtnAction), for: .touchUpInside)
//        self.addSubview(feedbackHistoryBtn)
//    }
    /*
     // Only override draw() if you perform custom drawing.
     // An empty implementation adversely affects performance during animation.
     override func draw(_ rect: CGRect) {
     // Drawing code
     }
     */

}
