//
//  FeedbackTableViewCell.swift
//  MobileBinaryOptions
//
//  Created by Anandh on 2/10/17.
//  Copyright © 2017 Broctagon. All rights reserved.
//

import UIKit

class FeedbackTableViewCell: UITableViewCell {

    @IBOutlet weak var feedBacklabel: UILabel!
    
    @IBOutlet weak var feedbackExpandableLabel: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
