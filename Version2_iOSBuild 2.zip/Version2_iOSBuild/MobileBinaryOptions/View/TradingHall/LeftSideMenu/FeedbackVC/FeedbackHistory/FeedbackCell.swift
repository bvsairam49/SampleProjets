//
//  FeedbackCell.swift
//  MobileBinaryOptions
//
//  Created by GE on 17/2/11.
//  Copyright © 2017年 Broctagon. All rights reserved.
//

import UIKit

class FeedbackCell: UITableViewCell {
    
    let backView = UIView() /// including all content view
    let questionLb = UILabel()
    let repliedBtn = BaseBtn()   /// the question had been replied, show repliedBtn
    let starBtn = BaseBtn()
    let answerLb = UILabel()
    let rateView = UIView()     /// rate with stars
    
    var question = ""
    var answer = ""
    var isReplied = false   /// true: show repliedBtn
    var isStar = false      /// true: show starBtn
    var starCount = 0
    
    var isShowAnswer = false    /// true: show answerLb and rateView

    override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        self.createUI()
        
        self.rateView.backgroundColor = .red
        self.questionLb.backgroundColor = .gray
        self.answerLb.backgroundColor = .blue
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func createUI() {
        self.backgroundColor = .clear
        
        self.contentView.addSubview(self.backView)
        self.backView.addSubview(self.questionLb)
        self.backView.addSubview(self.repliedBtn)
        self.backView.addSubview(self.starBtn)
        self.backView.addSubview(self.answerLb)
        self.backView.addSubview(self.rateView)
        
        self.createRateView()   /// create rate view
        
        self.backView.showCorner(3, borderWidth: 1, borderColor: .white)
        
        self.questionLb.textColor = kColorTimeframeSelected()
        self.questionLb.font = FONT_CUSTOM(15.0)
        self.questionLb.numberOfLines = 0
        
        self.answerLb.textColor = kColorWhite()
        self.answerLb.font = FONT_CUSTOM(15.0)
        self.answerLb.numberOfLines = 0
        
        self.starBtn.setImage(UIImage(named: "star_border_press.png"), for: .normal)
        
        self.repliedBtn.setImage(UIImage(named: "service_icon.png"), for: .normal)
        
        self.backView.snp.makeConstraints { (make) in
            make.top.left.equalTo(1)
            make.right.equalTo(self.contentView).offset(-1)
            make.bottom.equalTo(self.contentView).offset(-1)
            make.bottom.equalTo(self.answerLb.snp.bottom).offset(10)
        }
        
        self.questionLb.snp.makeConstraints { (make) in
            make.top.equalTo(10)
            make.left.equalTo(15)
            make.right.equalTo(self.backView).offset(-15 - 20 - COMPUTE_LENGTH(45.0 * 2))
            make.height.equalTo(20)
        }
        
        self.repliedBtn.snp.makeConstraints { (make) in
            make.left.equalTo(self.questionLb.snp.right).offset(20)
            make.width.height.equalTo(COMPUTE_LENGTH(40.0))
            make.centerY.equalTo(self.questionLb)
        }
        
        self.starBtn.snp.makeConstraints { (make) in
            make.left.equalTo(self.repliedBtn.snp.right).offset(5)
            make.width.height.equalTo(COMPUTE_LENGTH(40.0))
            make.centerY.equalTo(self.questionLb)
        }
        
        self.answerLb.snp.makeConstraints { (make) in
            make.top.equalTo(self.questionLb.snp.bottom).offset(5)
            make.left.equalTo(self.questionLb)
            make.right.equalTo(self.rateView.snp.left).offset(-5)
        }
        
        self.rateView.snp.makeConstraints { (make) in
            make.bottom.equalTo(self.answerLb)
            make.right.equalTo(self.backView).offset(-10)
            make.width.equalTo(COMPUTE_LENGTH(40.0 * 5 + 20.0 * 6))
            make.height.equalTo(self.answerLb.snp.height).priority(500)
            make.height.lessThanOrEqualTo(20).priority(1000)
        }
    }
    
    func createRateView() {
        for i in 0..<5 {
            let starBtn = BaseBtn()
            if i < self.starCount {
                starBtn.setImage(UIImage(named: "star_press.png"), for: .normal)
            }else {
                starBtn.setImage(UIImage(named: "star_border_press.png"), for: .normal)
            }
            self.rateView.addSubview(starBtn)
            
            starBtn.snp.makeConstraints({ (make) in
                make.width.height.equalTo(COMPUTE_LENGTH(40.0))
                make.centerY.equalTo(self.rateView)
                make.left.equalTo(COMPUTE_LENGTH(20.0 + 60.0 * CGFloat(i)))
            })
        }
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        self.questionLb.text = self.question
        self.answerLb.text = self.answer
        
        self.repliedBtn.isHidden = !self.isReplied
        self.starBtn.isHidden = !self.isStar
    }
}
