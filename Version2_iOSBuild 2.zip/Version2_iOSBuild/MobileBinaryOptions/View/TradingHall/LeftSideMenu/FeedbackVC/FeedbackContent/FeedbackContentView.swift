
//
//  FeedbackContentView.swift
//  MobileBinaryOptions
//
//  Created by Anandh on 2/10/17.
//  Copyright © 2017 Broctagon. All rights reserved.
//

import UIKit

class FeedbackContentView: UIView , UITextFieldDelegate,UITextViewDelegate{
    
    // FeedBackView  BackgroundView
    var  feedBackView = UIView()
    
    // Buttons
    var feedbackContentBtn = UIButton()
    var feedbackHistoryBtn = UIButton()
    
    // label
    var feedBackContentlabel = UILabel()
    var requiredLabel = UILabel()
    
    // TextView
    var feedbackContentTextView = UITextView()
    var feedBackBtn = UIButton()
    
    //ContactNumber
    var contactnumberLabel = UILabel()
    var optionalLabel = UILabel()
    var contactNumberTextField = UITextField()
    
    // Submitbutton
    var submitBtn = UIButton()
    
    

    // MARK:- Initializing Frame
    override init(frame: CGRect) {
        super.init(frame:frame)
        self.addControlsForFeedBackContentView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    
    // MARK:- Add Controls For UI
    
    func addControlsForFeedBackContentView()
    {
        // FeedBackView
        let frame = CGRect(x: CGFloat(0), y: CGFloat(0), width: SCREEN_WIDTH(), height: SCREEN_HEIGHT())
        let backgroundImage = UIImageView(frame: frame)
        backgroundImage.image = UIImage(named: "bg2.png")
        self.feedBackView.insertSubview(backgroundImage, at: 0)
        self.addSubview(self.feedBackView)
        
        // FeddBackContent Button
        if(SCREEN_WIDTH() <= 568)
        {
            feedbackContentBtn = UIButton(frame: CGRect(x: (SCREEN_WIDTH()*24/100)+10, y:15, width:((SCREEN_WIDTH()-(SCREEN_WIDTH()*48/100))/2), height: 30))
        }
        else
        {
            feedbackContentBtn = UIButton(frame: CGRect(x: (SCREEN_WIDTH()*26/100)+10, y:15, width: ((SCREEN_WIDTH()-(SCREEN_WIDTH()*52/100))/2), height: 30))
        }
        feedbackContentBtn.setTitle("Feedback Content", for: .normal)
        feedbackContentBtn.titleEdgeInsets = UIEdgeInsetsMake(0,-(feedbackContentBtn.frame.size.width/4), 0, 0)
        feedbackContentBtn.titleLabel?.font = UIFont.systemFont(ofSize: 14)
        feedbackContentBtn.titleLabel?.textAlignment = .left
        feedbackContentBtn.alpha = 1
        feedbackContentBtn.addTarget(self, action:#selector(feedBackContentBtnAction(_:)), for: .touchUpInside)
        self.addSubview(feedbackContentBtn)
        
        // FeddBackHistory Button
        if(SCREEN_WIDTH() <= 568)
        {
            feedbackHistoryBtn = UIButton(frame: CGRect(x:((feedbackContentBtn.frame.origin.x+feedbackContentBtn.frame.size.width+(SCREEN_WIDTH()*48/100)/8)), y:15, width: ((SCREEN_WIDTH()-(SCREEN_WIDTH()*48/100))/2), height: 30))
        }
        else
        {
            feedbackHistoryBtn = UIButton(frame: CGRect(x: (feedbackContentBtn.frame.origin.x+feedbackContentBtn.frame.size.width+(SCREEN_WIDTH()*8/100)), y:15, width: ((SCREEN_WIDTH()-(SCREEN_WIDTH()*52/100))/2), height: 30))
        }
        feedbackHistoryBtn.setTitle("Feedback history", for: .normal)
        feedbackHistoryBtn.titleLabel?.font = UIFont.systemFont(ofSize: 14)
        feedbackHistoryBtn.alpha = 0.5
        feedbackHistoryBtn.addTarget(self, action:#selector(self.feedBackHistoryBtnAction(_:)), for: .touchUpInside)
        self.addSubview(feedbackHistoryBtn)
        
        //  feedBack  content label
        if(SCREEN_WIDTH() <= 568)
        {
            feedBackContentlabel = UILabel(frame: CGRect(x:(SCREEN_WIDTH()*24/100), y:(feedbackHistoryBtn.frame.size.height+feedbackHistoryBtn.frame.origin.y+(SCREEN_HEIGHT()*4/100)), width:SCREEN_WIDTH()/3, height: 20))
        }
        else
        {
            feedBackContentlabel = UILabel(frame: CGRect(x:(SCREEN_WIDTH()*26/100), y:(feedbackHistoryBtn.frame.size.height+feedbackHistoryBtn.frame.origin.y+(SCREEN_HEIGHT()*4/100)), width:SCREEN_WIDTH()/3, height: 20))
        }
        feedBackContentlabel.text = "Feedback Content"
        feedBackContentlabel.textColor = UIColor.white
        feedBackContentlabel.font = UIFont.systemFont(ofSize: 14)
        self.addSubview(feedBackContentlabel)
        
        //  Requiredlabel
        requiredLabel = UILabel(frame: CGRect(x:(feedBackContentlabel.intrinsicContentSize.width+feedBackContentlabel.frame.origin.x+5), y:(feedbackHistoryBtn.frame.size.height+feedbackHistoryBtn.frame.origin.y+(SCREEN_HEIGHT()*4/100)), width:(SCREEN_WIDTH()/6), height: 20))
        requiredLabel.text = "(Required)"
        requiredLabel.textColor = UIColor.white
        requiredLabel.font = UIFont.systemFont(ofSize: 12)
        requiredLabel.alpha = 0.5
        self.addSubview(requiredLabel)
        
        // feedback contentView
        if(SCREEN_WIDTH() <= 568)
        {
            feedbackContentTextView = UITextView(frame: CGRect(x:(feedBackContentlabel.frame.origin.x), y:(feedBackContentlabel.frame.size.height+feedBackContentlabel.frame.origin.y+3), width:(SCREEN_WIDTH()-SCREEN_WIDTH()*48/100)+20, height:(SCREEN_HEIGHT())*21/100))
        }
        else
        {
            feedbackContentTextView = UITextView(frame: CGRect(x:(feedBackContentlabel.frame.origin.x), y:(feedBackContentlabel.frame.size.height+feedBackContentlabel.frame.origin.y+6), width:(SCREEN_WIDTH()-SCREEN_WIDTH()*48/100)+20, height:(SCREEN_HEIGHT())*28/100))
        }
        feedbackContentTextView.backgroundColor = UIColor.red
        feedbackContentTextView.autocorrectionType = .no
        feedbackContentTextView.text = "Write your Placeholder"
        feedbackContentTextView.textAlignment = .left
        feedbackContentTextView.textColor = UIColor.white
        feedbackContentTextView.delegate = self
        feedbackContentTextView.isScrollEnabled = true
        feedbackContentTextView.backgroundColor = UIColor.clear
        let imageView = UIImageView(frame: feedbackContentTextView.frame)
        imageView.image = UIImage(named: "txt_bg1@3x.png")
        self.addSubview(imageView)
        self.bringSubview(toFront: feedbackContentTextView)
        
        //  Contact number Label
        contactnumberLabel = UILabel(frame: CGRect(x:(feedbackContentTextView.frame.origin.x), y:(feedbackContentTextView.frame.size.height+feedbackContentTextView.frame.origin.y+8), width:(SCREEN_WIDTH()/3), height: 20))
        contactnumberLabel.text = "Contact number"
        contactnumberLabel.textColor = UIColor.white
        contactnumberLabel.font = UIFont.systemFont(ofSize: 14)
        self.addSubview(contactnumberLabel)
        
        // Optional label
        optionalLabel = UILabel(frame: CGRect(x:(contactnumberLabel.intrinsicContentSize.width+contactnumberLabel.frame.origin.x+5), y:(feedbackContentTextView.frame.size.height+feedbackContentTextView.frame.origin.y+8), width:(SCREEN_WIDTH()/6), height: 20))
        optionalLabel.text = "(Optional)"
        optionalLabel.textColor = UIColor.white
        optionalLabel.font = UIFont.systemFont(ofSize: 12)
        optionalLabel.alpha = 0.5
        self.addSubview(optionalLabel)
        
        // Contact number TextField
        if(SCREEN_WIDTH() <= 568)
        {
            contactNumberTextField = UITextField(frame: CGRect(x:(contactnumberLabel.frame.origin.x), y:(optionalLabel.frame.size.height+optionalLabel.frame.origin.y+5), width:(SCREEN_WIDTH()-SCREEN_WIDTH()*48/100)+20, height: 25))
        }
        else
        {
            contactNumberTextField = UITextField(frame: CGRect(x:(contactnumberLabel.frame.origin.x), y:(optionalLabel.frame.size.height+optionalLabel.frame.origin.y+5), width:(SCREEN_WIDTH()-SCREEN_WIDTH()*48/100)+20, height: 30))
        }
        contactNumberTextField.textAlignment = .left
        contactNumberTextField.textColor = UIColor.white
        contactNumberTextField.placeholder = "Number"
        contactNumberTextField.borderStyle = UITextBorderStyle.none
        contactNumberTextField.autocapitalizationType = .words // If you need any capitalization
        contactNumberTextField.background = UIImage(named: "txt_bg2@3x.png")
        self.addSubview(contactNumberTextField)
        // Submit Btn
        if(SCREEN_WIDTH() <= 568)
        {
            submitBtn = UIButton(frame: CGRect(x:((SCREEN_WIDTH()-(SCREEN_WIDTH()*65/100))), y:(contactNumberTextField.frame.size.height+contactNumberTextField.frame.origin.y+12), width:((SCREEN_WIDTH()-(SCREEN_WIDTH()*65/100))), height: 30))
        }
        else
        {
            submitBtn = UIButton(frame: CGRect(x:((SCREEN_WIDTH()-(SCREEN_WIDTH()*65/100))), y:44, width:((SCREEN_WIDTH()-(SCREEN_WIDTH()*65/100))), height: 30))
        }
        submitBtn.setBackgroundImage(UIImage(named: "btn@3x.png"), for: .normal)
        submitBtn.setTitle("Submit", for: .normal)
        submitBtn.titleLabel?.font = UIFont.systemFont(ofSize: 14)
        submitBtn.addTarget(self, action:#selector(self.submitButtonAction(_:)), for: .touchUpInside)
        submitBtn.isUserInteractionEnabled = true
        self.addSubview(submitBtn)
    }
    
    // MARK:- Submit Action Methods
    
    func submitButtonAction(_ sender:UIButton)
    {
        sender.isSelected = !sender.isSelected
        if (sender.isSelected) {
             submitBtn.setBackgroundImage(UIImage(named: "btn@3x.png"), for: .normal)
        }
        else{
            submitBtn.setBackgroundImage(UIImage(named: "btn_press@3x.png"), for: .normal)


        }
        
    }
    
    // MARK: - UITextfieldDelegate
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        animateViewMoving(true, moveValue: 100)
    }
    func textFieldDidEndEditing(_ textField: UITextField) {
        animateViewMoving(false, moveValue: 100)
        //        headersDictionary .setValue(textField.text, forKey: "\(textField.tag)")
        //        print(headersDictionary)
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool
    {
        textField.resignFirstResponder()
        return true
    }
    func animateViewMoving (_ up:Bool, moveValue :CGFloat){
        let movementDuration:TimeInterval = 0.3
        let movement:CGFloat = ( up ? -moveValue : moveValue)
        UIView.beginAnimations( "animateView", context: nil)
        UIView.setAnimationBeginsFromCurrentState(true)
        UIView.setAnimationDuration(movementDuration )
        self.frame = self.frame.offsetBy(dx: 0,  dy: movement)
        UIView.commitAnimations()
    }
    
    // MARK:- TextView Delegate
    
    func textViewDidBeginEditing(_ textView: UITextView) {
        if (textView.text == "Write your Placeholder")
        {
            textView.text = nil
            textView.textColor = UIColor.black
        }
    }
    
    func textViewDidEndEditing(_ textView: UITextView) {
        if textView.text.isEmpty
        {
            textView.text = "Write your Placeholder"
            textView.textColor = UIColor.lightGray
        }
        textView.resignFirstResponder()
    }
    
    
    // MARK:- Button Actions 
    
    func feedBackContentBtnAction(_ sender:UIButton)
    {
        print("feedbackContentView")
       
    }
    func feedBackHistoryBtnAction(_ sender:UIButton)
    {
         print("feedbackHistory")
    }
    
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
