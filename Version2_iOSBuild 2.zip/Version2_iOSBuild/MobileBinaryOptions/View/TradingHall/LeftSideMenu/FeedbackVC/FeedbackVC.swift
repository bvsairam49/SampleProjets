//
//  FeedbackVC.swift
//  MobileBinaryOptions
//
//  Created by Anandh on 2/10/17.
//  Copyright © 2017 Broctagon. All rights reserved.
//

import UIKit

class FeedbackVC: BaseVC , UIScrollViewDelegate {
    // create swipe gesture
    let swipeGestureLeft = UISwipeGestureRecognizer()
    let swipeGestureRight = UISwipeGestureRecognizer()
    // PageControl
    var myPageControl = UIPageControl()
    
    // Feedback backgroundView
    var feedBackGroundView = UIView()
    // Header Label
    var feedbackHeaderView = UIView()
    var feedbackLabel = UILabel()
    var cancelBtn = UIButton()
    
    // Selected page
    var  selectedIntValue = Int()
    
    // UI Subviews
    
    var feedbackContentView = FeedbackContentView()
    var feedbackhistoryView = FeedbackHistoryView()
    
    let scrollView = UIScrollView()
    var views = Array<UIView>()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        
        // HeaderView
        // AccountManagementBG view
//        let frame = CGRect(x: CGFloat(0), y: CGFloat(0), width: SCREEN_WIDTH(), height: SCREEN_HEIGHT())
//        let backgroundImage = UIImageView(frame: frame)
//        backgroundImage.image = UIImage(named: "bg2.png")
//        self.feedBackGroundView.insertSubview(backgroundImage, at: 0)
//        self.view.addSubview(self.feedBackGroundView)
        
        self.view.backgroundColor =  UIColor(patternImage: UIImage(named:"bg2.png")!)

        
        //Header view
        feedbackHeaderView = UIView(frame: CGRect(x: 0, y:0, width: SCREEN_WIDTH(), height: 44))
        feedbackHeaderView.backgroundColor = UIColor.clear
        feedbackHeaderView.backgroundColor =  UIColor(patternImage: UIImage(named:"title_bg@3x")!)
        self.view.addSubview(feedbackHeaderView)
        
        // Title label
        feedbackLabel = UILabel(frame: CGRect(x: 0, y:0, width: SCREEN_WIDTH(), height: 44))
        feedbackLabel.text = "Feedback"
        feedbackLabel.textColor = UIColor.yellow
        feedbackLabel.textAlignment = .center
        feedbackLabel.font = UIFont.systemFont(ofSize: 20)
        feedbackHeaderView.addSubview(feedbackLabel)
        
        //  cancel Button
        cancelBtn = UIButton(frame: CGRect(x: (SCREEN_WIDTH()-30), y:9, width: 25, height: 25))
        cancelBtn.setImage(UIImage(named: "close_icon@3x.png"), for: .normal)
        cancelBtn.addTarget(self, action:#selector(self.cancelButtonAction(_:)), for: .touchUpInside)
        feedbackHeaderView.addSubview(cancelBtn)
        
   
        // ScrollView
        self.scrollView.frame = CGRect(x: 0, y: 44, width: SCREEN_WIDTH(), height: SCREEN_HEIGHT()-44)
        self.scrollView.showsHorizontalScrollIndicator = false
        self.scrollView.showsVerticalScrollIndicator = true
        self.scrollView.alwaysBounceHorizontal = false
        self.scrollView.isDirectionalLockEnabled = true
        self.scrollView.isPagingEnabled = true
        self.scrollView.bounces = true
        self.scrollView.delegate = self
        scrollView.delaysContentTouches = false
        scrollView.isExclusiveTouch = true
        scrollView.isUserInteractionEnabled = true
        self.view.addSubview(self.scrollView)
        
        
                      //AddSubviews to ScrollView
        let colors = [feedbackContentView,feedbackhistoryView] as [Any]
        
        for i in 0..<colors.count {
            var frame1 = CGRect.zero
            frame1.origin.x = self.scrollView.frame.size.width * CGFloat(i)
            frame1.size = self.scrollView.frame.size
            let view1 = UIView(frame: frame1)
            view1.addSubview(colors[i] as! UIView)
            view1.isUserInteractionEnabled = true
            self.scrollView.addSubview(view1)
        }
        
        self.scrollView.contentSize = CGSize(width: self.scrollView.frame.width * CGFloat(colors.count), height: 300)
        
        // PageControl
        myPageControl = UIPageControl(frame: CGRect(x: CGFloat(0), y: CGFloat(SCREEN_HEIGHT()-20), width: SCREEN_WIDTH(), height: CGFloat(20)))
        myPageControl.backgroundColor = UIColor.clear
        myPageControl.numberOfPages = colors.count
        // get Selected tableView Index (Current index)
        // myPageControl.currentPage = (selectedIntValue - 1)

        myPageControl.pageIndicatorTintColor = UIColor.gray
        myPageControl.currentPageIndicatorTintColor = UIColor.white
        self.view.addSubview(myPageControl)
        // pageControlsAction
        myPageControl.addTarget(self, action:#selector(changePage(sender:)) , for:.valueChanged)
    }

    

    // MARK:- Button Action Methods
    func cancelButtonAction(_ sender: UIButton) {
        // TradingView
        let vc = TradingHallVC()
        let navi = BaseNavigationController(rootViewController: vc)
        navi.navigationBar.isTranslucent = false
        navi.isNavigationBarHidden = true
        self.present(navi, animated: true, completion: nil)
    }
 
    
    // MARK:- PageView
    func changePage(sender: AnyObject) -> () {
        let x = CGFloat(myPageControl.currentPage) * scrollView.frame.size.width
        scrollView.setContentOffset(CGPoint(x: x,y :0), animated: true)
    }

    
    // MARK:- SCROllView DelegateMethod
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        
        let pageNumber = round(scrollView.contentOffset.x / scrollView.frame.size.width)
        myPageControl.currentPage = Int(pageNumber)
    }
 
    // MARK:- Device Orientation
    override var shouldAutorotate: Bool {
        return true
    }
    
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return .landscape
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}
