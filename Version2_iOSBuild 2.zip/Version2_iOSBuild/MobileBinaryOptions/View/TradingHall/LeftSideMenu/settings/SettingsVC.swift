//
//  SettingsVC.swift
//  MobileBinaryOptions
//
//  Created by ALOK KUMAR on 07/02/17.
//  Copyright © 2017 Broctagon. All rights reserved.
//

import UIKit

class SettingsVC: UIViewController,UITableViewDelegate,UITableViewDataSource {
    var accBackGroundView = UIView()
    
    // Header Label
    var accHeaderView = UIView()
    var accManagementLabel = UILabel()
    var accManagementCancelBtn = UIButton()
    var  basisImg = NSMutableArray()
    var  reminderImg = NSMutableArray()
    var  displayImg = NSMutableArray()
    var languageArray = NSMutableArray()
    var languageImageArray = NSMutableArray()
    var selected : Bool? = false
    var sectionName = String()
    var sectionName1 = NSArray()
    var titlelabel = UILabel()
    // Account management Page
    var profileBtn  = UIButton()
    
    // For tableview cell
    
    
    var tableView1: UITableView  =   UITableView()
     var languageTableView: UITableView  =   UITableView()
    
    let animals : [String] = ["One Click Trading","Language"]
    let animals1 : [String] = ["Sound ","Vibration"]
    let animals2 : [String] = ["Red for Up,green for DOWN ","Green for Up,red for DOWN"]
    


    
    override func viewDidLoad() {
        super.viewDidLoad()
        basisImg  = ["trading_icon@3x.png","language_icon@3x"]
        reminderImg = ["sound_icon@3x.png","vibration_icon@3x.png"]
        displayImg  = ["up_red_icon@3x.png","down_green_icon@3x.png"]
        languageArray   = ["English","chinese"]
        languageImageArray = ["Chinese@3x.png","English@3x.png"]
        self.createUIForAccountManagement()
        languageTableView.isHidden = true
        
    }
    
    // MARK:- Create UI for Controls.
    func createUIForAccountManagement(){
        
        // AccountManagementBG view
        let frame = CGRect(x: CGFloat(0), y: CGFloat(0), width: SCREEN_WIDTH(), height: SCREEN_HEIGHT())
        let backgroundImage = UIImageView(frame: frame)
        backgroundImage.image = UIImage(named: "bg_landscape@3x.png")
        self.accBackGroundView.insertSubview(backgroundImage, at: 0)
        self.view.addSubview(self.accBackGroundView)
        
        //Header view
        accHeaderView = UIView(frame: CGRect(x: 0, y:0, width: SCREEN_WIDTH(), height: 44))
        accHeaderView.backgroundColor = UIColor.clear
        accHeaderView.backgroundColor = UIColor.init(patternImage: UIImage(named: "title_bg@3x")!)
        self.view.addSubview(accHeaderView)
        
        // Title label
        accManagementLabel = UILabel(frame: CGRect(x: 0, y:0, width: SCREEN_WIDTH(), height: 44))
        accManagementLabel.text = "Settings"
        accManagementLabel.textColor = UIColor(red:255/255, green:178/255, blue:102/255, alpha:0.8)
        accManagementLabel.textAlignment = .center
        accManagementLabel.font = UIFont.systemFont(ofSize: 15)
        accHeaderView.addSubview(accManagementLabel)
        
        //  cancel Button
        accManagementCancelBtn = UIButton(frame: CGRect(x: (SCREEN_WIDTH()-30), y:9, width: 25, height: 25))
        accManagementCancelBtn.setImage(UIImage(named: "close_icon@3x.png"), for: .normal)
         accManagementCancelBtn.addTarget(self, action:#selector(self.backBtnAction), for: .touchUpInside)
        accHeaderView.addSubview(accManagementCancelBtn)
        // mt4BindingAccountsTableView.frame = CGRect(x: CGFloat(SCREEN_WIDTH()*26/100)+10, y: CGFloat(bindMt4HeaderView.frame.size.height+bindMt4HeaderView.frame.origin.y+40), width: CGFloat(SCREEN_WIDTH()-(SCREEN_WIDTH()*52/100)), height: CGFloat(SCREEN_HEIGHT()*50/100))
        tableView1.frame = CGRect(x: CGFloat(SCREEN_WIDTH()*26/100)+10, y: CGFloat(accHeaderView.frame.size.height+accHeaderView.frame.origin.y+20), width: CGFloat(SCREEN_WIDTH()-(SCREEN_WIDTH()*52/100)), height: CGFloat(SCREEN_HEIGHT()*72/100))
        //tableView = UITableView
        tableView1.backgroundColor = UIColor.clear
        tableView1.delegate      =   self
        tableView1.dataSource    =   self
        tableView1.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
        self.view.addSubview(self.tableView1)
        
        languageTableView.frame = CGRect(x: CGFloat(SCREEN_WIDTH()*75/100)+10, y: CGFloat(accHeaderView.frame.size.height+accHeaderView.frame.origin.y+70), width: CGFloat(SCREEN_WIDTH()-(SCREEN_WIDTH()*80/100)), height: CGFloat(SCREEN_HEIGHT()*21/100))
        
        //tableView = UITableView
        languageTableView.backgroundView = UIImageView(image: UIImage(named: "bg_landscape@3x.png"))
       
           languageTableView.isScrollEnabled=true
      
        
        
     
        languageTableView.backgroundColor = UIColor.clear
        languageTableView.delegate      =   self
        languageTableView.dataSource    =   self
        languageTableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell1")
        self.view.addSubview(self.languageTableView)
        
        
    }
    
    func backBtnAction(){
        let _ = self.navigationController?.popViewController(animated: true)
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        var section = 0
        if(tableView == tableView1){
            return 3
            
        }
        else{
            section = 1
        }
        
      return section
    }
    

    
//    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
//        
//        sectionName1 = ["Basis","Reminder","Display"];
//        // var sectionName: String
//        switch section {
//        case 0:
//        sectionName = NSLocalizedString("Basis", comment: "Basis")
//            
//        case 1:
//            sectionName = NSLocalizedString("Reminder", comment: "Reminder")
//        case 2:
//            sectionName = NSLocalizedString("Display", comment: "Display")
//        // ...
//        default:
//            sectionName = ""
//        }
//        return sectionName
//    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if(tableView == tableView1){
        return 35;
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let footerView = UIView(frame: CGRect(x: 0, y:0, width:tableView.frame.size.width, height: 25))
        if(tableView == tableView1){
        
        //    self.myTableView.tableFooterView = footerView;
        footerView.backgroundColor = UIColor.init(patternImage: UIImage(named: "bg2.png")!)
        
        let label = UILabel(frame: CGRect(x:10, y:6, width: tableView.frame.size.width, height: 25))
        label.textAlignment = NSTextAlignment .center
       label.textColor = UIColor.white
         label.font = UIFont.systemFont(ofSize: 10)
        label.alpha = 0.5
      
        
      
        
        footerView.addSubview(label)
        
        if(section == 0 ){
        label.text = "Basis"
            
        }
        
        if(section == 1 ){
            label.text = "Reminder"

            
        }
        
        if(section == 2 ){
            label.text = "Display"
            
            
        }
            
            return footerView
            
        }
        
        else{
            
       return nil
            
            
        }
        
    }
   
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        if(tableView == tableView1){
            
        
        if(section == 0)
        {
            return animals.count
        }
        if(section == 1)
        {
            return animals1.count
        }
        if(section == 2)
        {
            return animals2.count
        }
        return 0
        }
        if(tableView == languageTableView){
            return languageArray.count
        }
        
        return 0
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell3:UITableViewCell=UITableViewCell(style: UITableViewCellStyle.subtitle, reuseIdentifier: "cell3")
        if(tableView == tableView1){
        let cell:UITableViewCell=UITableViewCell(style: UITableViewCellStyle.subtitle, reuseIdentifier: "cell")
        cell.textLabel!.textColor = UIColor .white
        
        cell.textLabel?.adjustsFontSizeToFitWidth = true
        cell.textLabel?.minimumScaleFactor = 0.1
        cell.textLabel?.font = UIFont.systemFont(ofSize: 14.0)
        cell.selectionStyle = .none
        
        if(indexPath.section == 0)
        {
            
            if(indexPath.row == 0){
            //let switchview = UISwitch(frame: CGRect(x: 40.0, y:9, width: 40, height: 25))
                //switchview.tag = 111
              
                
                let switchDemo = UISwitch(frame:CGRect(x: 150, y: 300,width: 30,height:0))
                switchDemo.isOn = false
                switchDemo.setOn(true, animated: false)
               // switchDemo.addTarget(self, action: "switchValueDidChange:", forControlEvents: .ValueChanged)
                self.view!.addSubview(switchDemo)
               
                cell.accessoryView = switchDemo
               
              
//                switchview.addTarget(self, action: #selector(self.updateSwitchAtIndexPath), for: .touchUpInside)

            }
            
            if(indexPath.row == 1){
                let imageView = UIImageView(image: UIImage(named: "right_icon@3x.png"))
                cell.accessoryView = imageView
                
                
            }
//
            cell.textLabel!.text = animals [indexPath.row]

            cell.imageView?.image =  UIImage(named: basisImg[indexPath.row] as! String)
        }
       if (indexPath.section == 1){
        
        if(indexPath.row == 0){
            
            let switchDemo = UISwitch(frame:CGRect(x: 150, y: 300,width: 30,height:0))
            switchDemo.isOn = false
            switchDemo.setOn(true, animated: false)
            // switchDemo.addTarget(self, action: "switchValueDidChange:", forControlEvents: .ValueChanged)
            self.view!.addSubview(switchDemo)
            
            cell.accessoryView = switchDemo
            
            

        }
        
        if(indexPath.row == 1){
        
            let switchDemo = UISwitch(frame:CGRect(x: 150, y: 300,width: 30,height:0))
            switchDemo.isOn = false
            switchDemo.setOn(true, animated: false)
            // switchDemo.addTarget(self, action: "switchValueDidChange:", forControlEvents: .ValueChanged)
            self.view!.addSubview(switchDemo)
            
            cell.accessoryView = switchDemo
            
            
        }
        
            cell.textLabel!.text = animals1 [indexPath.row]
            cell.imageView?.image = UIImage(named: reminderImg[indexPath.row] as! String )
        }
          if (indexPath.section == 2)
        {
            
                       cell.textLabel!.text = animals2 [indexPath.row]
            cell.imageView?.image = UIImage(named: displayImg[indexPath.row] as! String )
        }
        cell.backgroundColor = UIColor.clear
        return cell;
            
        }
        
        else if(tableView == languageTableView){
            
            
            let cell:UITableViewCell=UITableViewCell(style: UITableViewCellStyle.subtitle, reuseIdentifier: "cell1")
            cell.selectionStyle = .none
           cell.textLabel!.text = languageArray [indexPath.row] as? String
            cell.imageView?.image = UIImage(named: languageImageArray[indexPath.row] as! String )
             cell.textLabel!.textColor = UIColor .white
             cell.textLabel?.adjustsFontSizeToFitWidth=true
             cell.backgroundColor = UIColor.clear
            return cell
        }
        
        return cell3
    }
    

    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        
        
        if(tableView == tableView1){
            
            if(indexPath.section == 0)
            {
                if(indexPath.row==1){
                    
                    if(selected == true){
                        languageTableView.isHidden = false
                        selected=false
                         self.viewSlideInFromLeft(toTop: languageTableView)
                        
                        
                    }else{
                        
                        languageTableView.isHidden = true
                        selected = true
                        self.viewSlideInFromRight(toTop: languageTableView)
                        
                    }
                
            
                }
                
            }
       
        if(indexPath.section == 2){
            
            if(indexPath.row == 0){
                if let cell = tableView.cellForRow(at: indexPath) {
                    if cell.accessoryType == .checkmark
                    {
                        cell.accessoryType = .none
                        cell.textLabel?.textColor = UIColor.white
                        
                    }
                    else
                    {
                        cell.accessoryType = .checkmark
                        cell.textLabel?.textColor = UIColor(red:255/255, green:178/255, blue:102/255, alpha:1.0)
                        cell.tintColor = UIColor(red:255/255, green:178/255, blue:102/255, alpha:1.0)
                        // self.tableView.separatorColor = UIColor(red:255/255, green:178/255, blue:102/255, alpha:1.0)
                    }
                }
        
    }
            
            
            if(indexPath.row == 1){
                if let cell = tableView.cellForRow(at: indexPath) {
                    if cell.accessoryType == .checkmark
                    {
                        cell.accessoryType = .none
                        cell.textLabel?.textColor = UIColor.white
                        
                        
                    }
                    else
                    {
                        cell.accessoryType = .checkmark
                        cell.textLabel?.textColor = UIColor(red:255/255, green:178/255, blue:102/255, alpha:1.0)
                        cell.tintColor = UIColor(red:255/255, green:178/255, blue:102/255, alpha:1.0)
                    }
                }
                
            }
    
    }
        
    }
        
        if(tableView == languageTableView){
            
            if(indexPath.row == 0){
                
                if let cell = tableView.cellForRow(at: indexPath) {
                    if cell.accessoryType == .checkmark
                    {
                        cell.accessoryType = .none
                        cell.textLabel?.textColor = UIColor.white
                        
                        
                    }
                    else
                    {
                        cell.accessoryType = .checkmark
                        cell.textLabel?.textColor = UIColor(red:255/255, green:178/255, blue:102/255, alpha:1.0)
                        cell.tintColor = UIColor(red:255/255, green:178/255, blue:102/255, alpha:1.0)
                        cell.textLabel?.adjustsFontSizeToFitWidth=true
                    }
                }
                
                
            }
            
            
            if(indexPath.row == 1){
                
                if let cell = tableView.cellForRow(at: indexPath) {
                    if cell.accessoryType == .checkmark
                    {
                        cell.accessoryType = .none
                        cell.textLabel?.textColor = UIColor.white
                        
                        
                    }
                    else
                    {
                        cell.accessoryType = .checkmark
                        cell.textLabel?.adjustsFontSizeToFitWidth=true
                        cell.textLabel?.textColor = UIColor(red:255/255, green:178/255, blue:102/255, alpha:1.0)
                        cell.tintColor = UIColor(red:255/255, green:178/255, blue:102/255, alpha:1.0)
                    }
                }
                
                
            }
            
            
        }
        
    }
    
    
    func viewSlideInFromLeft(toTop views: UIView) {
        var transition: CATransition? = nil
        transition = CATransition()
        transition!.duration = 0.5
        //kAnimationDuration
        transition!.timingFunction = CAMediaTimingFunction(name: kCAMediaTimingFunctionEaseInEaseOut)
        transition!.type = kCATransitionPush
        transition!.subtype = kCATransitionFromLeft
        //transition!.delegate = self
        views.layer.add(transition!, forKey: nil)
    }
    
    func viewSlideInFromRight(toTop views: UIView) {
        var transition: CATransition? = nil
        transition = CATransition()
        transition!.duration = 0.5
        //kAnimationDuration
        transition!.timingFunction = CAMediaTimingFunction(name: kCAMediaTimingFunctionEaseInEaseOut)
        transition!.type = kCATransitionPush
        transition!.subtype = kCATransitionFromRight
        //transition!.delegate = self
        views.layer.add(transition!, forKey: nil)
    }

       override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override var shouldAutorotate: Bool {
        return true
    }
    
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return .landscape
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}
