//
//  ProfileView.swift
//  MobileBinaryOptions
//
//  Created by Anandh on 2/7/17.
//  Copyright © 2017 Broctagon. All rights reserved.
//

import UIKit

class ProfileView: UIView {
    
    // ProfileView  BackgroundView
    var  profileBackgroundView = UIView()
    
    // Header Label
    var accHeaderView = UIView()
    var accManagementLabel = UILabel()
    var accManagementCancelBtn = UIButton()
    
    // Account management Page
    var profileBtn  = UIButton()
    var mt4PasswordBtn = UIButton()
    var patternlockButton = UIButton()
    
    // TextField For Profile
    var accManagementScrollview: UIScrollView!
    var numberofFields: Int = 0
    
    // Labels
    var emailaddressLbl = UILabel()
    var seperatorLabel1 = UILabel()
    
    var nameLbl = UILabel()
    var seperatorLabel2 = UILabel()
    
    var phoneNumLbl = UILabel()
    var seperatorLabel3 = UILabel()
    
    var countryLbl = UILabel()
    var seperatorLabel4 = UILabel()
    
    var citizenShipLbl = UILabel()
    var seperatorLabel5 = UILabel()
    
    var cityLbl = UILabel()
    var seperatorLabel6 = UILabel()
    
     var addressLbl = UILabel()
     var seperatorLabel7 = UILabel()

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

    
    // MARK:- Profile View Initialization.
    
    override init(frame: CGRect) {
        super.init(frame:frame)
        self.addControlsUIForProfile()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    
    // MARK:- add UI Controls For Profile
    
    func addControlsUIForProfile() {
        // ProfileView
        let frame = CGRect(x: CGFloat(0), y: CGFloat(0), width: SCREEN_WIDTH(), height: SCREEN_HEIGHT()*80/100)
        let backgroundImage = UIImageView(frame: frame)
        backgroundImage.image = UIImage(named: "bg2.png")
        self.profileBackgroundView.insertSubview(backgroundImage, at: 0)
        self.addSubview(self.profileBackgroundView)
        
        // profile Button
        profileBtn = UIButton(frame: CGRect(x: (SCREEN_WIDTH()*20/100), y:10, width: ((SCREEN_WIDTH()*17/100)), height: 30))
        profileBtn.setImage(UIImage(named: "mt4-icon@3x.png"), for: .normal)
        profileBtn.setTitle("Profile", for: .normal)
        profileBtn.titleEdgeInsets = UIEdgeInsetsMake(0, 10, 0, -10)
        profileBtn.titleLabel?.font = FONT_CUSTOM(12)
        profileBtn.addTarget(self, action:#selector(self.profileButtonAction(_:)), for: .touchUpInside)
        self.addSubview(profileBtn)
        

        // MT4 Password Button
        mt4PasswordBtn = UIButton(frame: CGRect(x:(profileBtn.frame.origin.x+profileBtn.frame.size.width+(SCREEN_WIDTH()*3/100)), y:10, width:((SCREEN_WIDTH()*17/100)), height: 30))
        mt4PasswordBtn.setImage(UIImage(named: "key_icon@3x.png"), for: .normal)
        mt4PasswordBtn.setTitle("MT4 Password", for: .normal)
        mt4PasswordBtn.titleLabel?.font = FONT_CUSTOM(12)
        mt4PasswordBtn.titleEdgeInsets = UIEdgeInsetsMake(0, 5, 0, -5)
        mt4PasswordBtn.addTarget(self, action:#selector(self.mt4PasswordButtonAction(_:)), for: .touchUpInside)
        mt4PasswordBtn.imageEdgeInsets = UIEdgeInsetsMake(0, 0, 0, 5)
        mt4PasswordBtn.alpha = 0.5
        self.addSubview(mt4PasswordBtn)
        
        // Pattern lock Button.
        patternlockButton = UIButton(frame: CGRect(x:(mt4PasswordBtn.frame.origin.x+mt4PasswordBtn.frame.size.width+(SCREEN_WIDTH()*3/100)), y:10, width:((SCREEN_WIDTH()*17/100)), height: 30))

        patternlockButton.setImage(UIImage(named: "lock-icon@3x.png"), for: .normal)
        patternlockButton.setTitle("Pattern Lock", for: .normal)
        patternlockButton.titleLabel?.font = FONT_CUSTOM(12)
        patternlockButton.addTarget(self, action:#selector(self.patternlockButtonAction(_:)), for: .touchUpInside)
        patternlockButton.alpha = 0.5
        patternlockButton.titleEdgeInsets = UIEdgeInsetsMake(0, 0, 0, -10)
        patternlockButton.imageEdgeInsets = UIEdgeInsetsMake(0, 0, 0, 5)
        self.addSubview(patternlockButton)
        
        
        // ScrollView
        accManagementScrollview = UIScrollView()
        accManagementScrollview.frame = CGRect(x: CGFloat(SCREEN_WIDTH()*26/100), y: CGFloat(patternlockButton.frame.size.height+patternlockButton.frame.origin.y+8), width: CGFloat((SCREEN_WIDTH()*52/100)), height: CGFloat(SCREEN_HEIGHT()-(accHeaderView.frame.origin.y+accHeaderView.frame.size.height+patternlockButton.frame.size.height+patternlockButton.frame.origin.y+85)))
        accManagementScrollview.backgroundColor = UIColor.clear
        accManagementScrollview.showsHorizontalScrollIndicator = false
        accManagementScrollview.alwaysBounceHorizontal = false
        accManagementScrollview.isDirectionalLockEnabled = true
        accManagementScrollview.bounces = false
        self.addSubview(accManagementScrollview)
        
        
        // Email Label
        emailaddressLbl = UILabel(frame: CGRect(x:2, y:4, width:(accManagementScrollview.frame.size.width-4), height: 24))
        emailaddressLbl.text = "Email address"
        emailaddressLbl.backgroundColor = UIColor.clear
        emailaddressLbl.textColor = kColorProfilelabel()
        emailaddressLbl.font = FONT_CUSTOM(12)
        accManagementScrollview.addSubview(emailaddressLbl)
        
        // Seperator Label
        seperatorLabel1 = UILabel(frame: CGRect(x:0, y:(emailaddressLbl.frame.size.height+emailaddressLbl.frame.origin.y), width:accManagementScrollview.frame.size.width, height: 1))
        seperatorLabel1.backgroundColor = kColorProfileSeperatorlabel()
        numberofFields += 1
        accManagementScrollview.addSubview(seperatorLabel1)
     
        //Name Label
        nameLbl = UILabel(frame: CGRect(x:2, y:(seperatorLabel1.frame.size.height+seperatorLabel1.frame.origin.y+10), width:(accManagementScrollview.frame.size.width-4), height: 24))
        nameLbl.text = "Name"
        nameLbl.textColor = kColorProfilelabel()
        nameLbl.backgroundColor = UIColor.clear
        nameLbl.font = FONT_CUSTOM(12)
        accManagementScrollview.addSubview(nameLbl)
        
        // Seperator Label
        seperatorLabel2 = UILabel(frame: CGRect(x:0, y:(nameLbl.frame.size.height+nameLbl.frame.origin.y), width:accManagementScrollview.frame.size.width, height: 1))
        seperatorLabel2.backgroundColor = kColorProfileSeperatorlabel()
        numberofFields += 1
        accManagementScrollview.addSubview(seperatorLabel2)
        
        
        //Phone Label
        phoneNumLbl = UILabel(frame: CGRect(x:2, y:(seperatorLabel2.frame.size.height+seperatorLabel2.frame.origin.y+10), width:(accManagementScrollview.frame.size.width-4), height: 24))
        phoneNumLbl.text = "Phone"
        phoneNumLbl.textColor = kColorProfilelabel()
        phoneNumLbl.backgroundColor = UIColor.clear
        phoneNumLbl.font = FONT_CUSTOM(12)
        accManagementScrollview.addSubview(phoneNumLbl)
        // Seperator Label
        seperatorLabel3 = UILabel(frame: CGRect(x:0, y:(phoneNumLbl.frame.size.height+phoneNumLbl.frame.origin.y), width:accManagementScrollview.frame.size.width, height: 1))
        seperatorLabel3.backgroundColor = kColorProfileSeperatorlabel()
        numberofFields += 1
        accManagementScrollview.addSubview(seperatorLabel3)
        
    
  
        //Country Label
        countryLbl = UILabel(frame: CGRect(x:2, y:(seperatorLabel3.frame.size.height+seperatorLabel3.frame.origin.y+10), width:(accManagementScrollview.frame.size.width-4), height: 24))
        countryLbl.text = "Country"
        countryLbl.textColor = kColorProfilelabel()
        countryLbl.backgroundColor = UIColor.clear
         countryLbl.font = FONT_CUSTOM(12)
        accManagementScrollview.addSubview(countryLbl)
        // Seperator Label
        seperatorLabel4 = UILabel(frame: CGRect(x:0, y:(countryLbl.frame.size.height+countryLbl.frame.origin.y), width:accManagementScrollview.frame.size.width, height: 1))
        seperatorLabel4.backgroundColor = kColorProfileSeperatorlabel()
        numberofFields += 1
        accManagementScrollview.addSubview(seperatorLabel4)
        
   
        //CityzenShip Label
        citizenShipLbl = UILabel(frame: CGRect(x:2, y:(seperatorLabel4.frame.size.height+seperatorLabel4.frame.origin.y+10), width:(accManagementScrollview.frame.size.width-4), height: 24))
        citizenShipLbl.text = "Citizenship"
        citizenShipLbl.textColor = kColorProfilelabel()
        citizenShipLbl.backgroundColor = UIColor.clear
        citizenShipLbl.font = FONT_CUSTOM(12)
        accManagementScrollview.addSubview(citizenShipLbl)
        // Seperator Label
        seperatorLabel5 = UILabel(frame: CGRect(x:0, y:(citizenShipLbl.frame.size.height+citizenShipLbl.frame.origin.y), width:citizenShipLbl.frame.size.width, height: 1))
        seperatorLabel5.backgroundColor = kColorProfileSeperatorlabel()
        numberofFields += 1
        accManagementScrollview.addSubview(seperatorLabel5)
        
        //City label
        cityLbl = UILabel(frame: CGRect(x:2, y:(seperatorLabel5.frame.size.height+seperatorLabel5.frame.origin.y+10), width:(accManagementScrollview.frame.size.width-4), height: 24))
        cityLbl.text = "City"
        cityLbl.textColor = kColorProfilelabel()
        cityLbl.backgroundColor = UIColor.clear
        cityLbl.font = FONT_CUSTOM(12)
        accManagementScrollview.addSubview(cityLbl)
        // Seperator Label
        seperatorLabel6 = UILabel(frame: CGRect(x:0, y:(cityLbl.frame.size.height+cityLbl.frame.origin.y), width:cityLbl.frame.size.width, height: 1))
        seperatorLabel6.backgroundColor = kColorProfileSeperatorlabel()
        numberofFields += 1
        accManagementScrollview.addSubview(seperatorLabel6)
        
        //Address Label
        addressLbl = UILabel(frame: CGRect(x:2, y:(seperatorLabel6.frame.size.height+seperatorLabel6.frame.origin.y+10), width:(accManagementScrollview.frame.size.width-4), height: 24))
        addressLbl.text = "Address"
        addressLbl.font = FONT_CUSTOM(12)
        addressLbl.textColor = kColorProfilelabel()
        accManagementScrollview.addSubview(addressLbl)
        // Seperator Label
        seperatorLabel7 = UILabel(frame: CGRect(x:0, y:(addressLbl.frame.size.height+addressLbl.frame.origin.y), width:addressLbl.frame.size.width, height: 1))
        seperatorLabel7.backgroundColor = kColorProfileSeperatorlabel()
        numberofFields += 1
        accManagementScrollview.addSubview(seperatorLabel7)
        
        // scrollView Content Size
        accManagementScrollview.contentSize = CGSize(width:CGFloat(SCREEN_WIDTH()-(SCREEN_WIDTH()*51/100)), height: CGFloat(36 * (numberofFields)))
    }
    
    // MARK:- Button Actions.
    
     func profileButtonAction(_ sender: UIButton) {
       }
     func mt4PasswordButtonAction(_ sender: UIButton) {
            }
        func patternlockButtonAction(_ sender: UIButton) {
            }
    

}
