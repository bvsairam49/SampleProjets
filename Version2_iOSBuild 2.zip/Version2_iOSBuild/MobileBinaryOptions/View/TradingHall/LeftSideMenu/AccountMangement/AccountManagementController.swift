//
//  AccountManagementController.swift
//  MobileBinaryOptions
//
//  Created by Anandh on 2/3/17.
//  Copyright © 2017 Broctagon. All rights reserved.
//

import UIKit

class AccountManagementController: BaseVC,PatternLockViewDelegate {
    
    // create swipe gesture
    let swipeGestureLeft = UISwipeGestureRecognizer()
    let swipeGestureRight = UISwipeGestureRecognizer()
    // PageControl
    var myPageControl: UIPageControl!
    // Account management backgroundView
    var accBackGroundView = UIView()
    // Header Label
    var accHeaderView = UIView()
    var accManagementLabel = UILabel()
    var accManagementCancelBtn = UIButton()
   
    // SubViews
     var profileView = ProfileView()
     var mt4passwordView = MT4PasswordView()
     var patternLockView = PatternLockView()
    
    // Selected page 
    var  selectedIntValue = Int()
    
    
    // MARK:- View Initialization.
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
            // HeaderView
        self.addHeaderView()
        
        self.view.backgroundColor =  UIColor(patternImage: UIImage(named:"bg2.png")!) 
        
        // set gesture direction
        self.swipeGestureLeft.direction = UISwipeGestureRecognizerDirection.left
        self.swipeGestureRight.direction = UISwipeGestureRecognizerDirection.right
       // add gesture target
        self.swipeGestureLeft.addTarget(self, action: #selector(AccountManagementController.handleSwipeLeft(_:)))
        self.swipeGestureRight.addTarget(self, action: #selector(AccountManagementController.handleSwipeRight(_:)))
        // add gesture in to view
        self.view.addGestureRecognizer(self.swipeGestureLeft)
        self.view.addGestureRecognizer(self.swipeGestureRight)
        
        // PageControl
        myPageControl = UIPageControl(frame: CGRect(x: CGFloat(0), y: CGFloat(SCREEN_HEIGHT()-20), width: SCREEN_WIDTH(), height: CGFloat(20)))
        myPageControl.backgroundColor = UIColor(red:0, green:0, blue:0, alpha:0.0)
        myPageControl.numberOfPages = 3
        // get Selected tableView Index (Current index)
        myPageControl.currentPage = (selectedIntValue - 1)
        myPageControl.pageIndicatorTintColor = UIColor.gray
        myPageControl.currentPageIndicatorTintColor = UIColor.white
        self.view.addSubview(myPageControl)
        // set currentPage view
        self.setCurrentPageView()
    }
    
    // MARK: - Utility function
    
    // increase page number on swift left
    func handleSwipeLeft(_ gesture: UISwipeGestureRecognizer){
        if self.myPageControl.currentPage < 3 {
            self.myPageControl.currentPage += 1
            self.setCurrentPageView()
        }
    }
    
    // reduce page number on swift right
    func handleSwipeRight(_ gesture: UISwipeGestureRecognizer){
        if self.myPageControl.currentPage != 0 {
            self.myPageControl.currentPage -= 1
            self.setCurrentPageView()
        }
    }
    
    // set current page number label
    fileprivate func setCurrentPageView(){
        // current page
        if (self.myPageControl.currentPage == 0) {
            profileView.isHidden = false
            mt4passwordView.removeFromSuperview()
            patternLockView.removeFromSuperview()
            
            self.addUIForProfile()
        }
        else if (self.myPageControl.currentPage == 1) {
            mt4passwordView .isHidden = false
            patternLockView.removeFromSuperview()
            profileView.removeFromSuperview()
            
            self.addUIForMt4Password()
        }
        else if (self.myPageControl.currentPage == 2) {
            mt4passwordView .removeFromSuperview()
            patternLockView.isHidden = false
            profileView.removeFromSuperview()
            self.addUIForPatternlock()
        }
       
    }
    // MARK:- ADD UI for Controls.
    
    func addUIForProfile(){
           // ProfileView
        profileView = ProfileView.init(frame: CGRect(x:0, y:44, width: (SCREEN_WIDTH()), height: SCREEN_HEIGHT()*80/100))
        self.view.addSubview(profileView)
      
    }
    
    func addUIForMt4Password(){
        // MT4PasswordView
        mt4passwordView = MT4PasswordView.init(frame: CGRect(x:0, y:44, width: (SCREEN_WIDTH()), height: SCREEN_HEIGHT()*80/100))
        self.view.addSubview(mt4passwordView)
    }
    
    func addUIForPatternlock(){
        // PatternLockView
        patternLockView = PatternLockView.init(frame: CGRect(x:0, y:44, width: (SCREEN_WIDTH()), height: SCREEN_HEIGHT()*80/100))
        patternLockView.delegate = self
        self.view.addSubview(patternLockView)
    }
    
    // MARK:- Common HeaderView 
    
    func addHeaderView(){
        // AccountManagementBG view
        let frame = CGRect(x: CGFloat(0), y: CGFloat(0), width: SCREEN_WIDTH(), height: SCREEN_HEIGHT())
        let backgroundImage = UIImageView(frame: frame)
        backgroundImage.image = UIImage(named: "bg1@3x.png")
        self.accBackGroundView.insertSubview(backgroundImage, at: 0)
        self.view.addSubview(self.accBackGroundView)
        
        //Header view
        accHeaderView = UIView(frame: CGRect(x: 0, y:0, width: SCREEN_WIDTH(), height: 44))
        accHeaderView.backgroundColor = UIColor.clear
        accHeaderView.backgroundColor =  UIColor(patternImage: UIImage(named:"title_bg@3x")!)
        self.view.addSubview(accHeaderView)
        
        // Title label
        accManagementLabel = UILabel(frame: CGRect(x: 0, y:0, width: SCREEN_WIDTH(), height: 44))
        accManagementLabel.text = "Account Management"
        accManagementLabel.textColor = UIColor.yellow
        accManagementLabel.textAlignment = .center
        accManagementLabel.font = UIFont.systemFont(ofSize: 20)
        accHeaderView.addSubview(accManagementLabel)
        
        //  cancel Button
        accManagementCancelBtn = UIButton(frame: CGRect(x: (SCREEN_WIDTH()-30), y:9, width: 25, height: 25))
        accManagementCancelBtn.setImage(UIImage(named: "close_icon.png"), for: .normal)
        accManagementCancelBtn.addTarget(self, action:#selector(self.cancelButtonAction(_:)), for: .touchUpInside)
        accHeaderView.addSubview(accManagementCancelBtn)
    }
    
    // MARK: - Button Action Methods
    
    func cancelButtonAction(_ sender: UIButton) {
        let vc = TradingHallVC()
        let navi = BaseNavigationController(rootViewController: vc)
        navi.navigationBar.isTranslucent = false
        navi.isNavigationBarHidden = true
        self.present(navi, animated: true, completion: nil)
    }
    
    // MARK: - PatternLockViewDelegate
    
    func didChangePatternSwitchStatus(isOn: Bool) {
        let type = isOn ? PatternLockType.setting : PatternLockType.cancel;
        let vc = PatternLockVC(type: type)
        self.present(vc, animated: true, completion: nil)
    }
    
    func didTapThePatternLock(isOn: Bool) {
        let type = isOn ? PatternLockType.modify : PatternLockType.setting;
        let vc = PatternLockVC(type: type)
        self.present(vc, animated: true, completion: nil)
    }
    
    // MARK: - Device Orientation
    
    override var shouldAutorotate: Bool {
        return true
    }

    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return .landscape
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
//
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
