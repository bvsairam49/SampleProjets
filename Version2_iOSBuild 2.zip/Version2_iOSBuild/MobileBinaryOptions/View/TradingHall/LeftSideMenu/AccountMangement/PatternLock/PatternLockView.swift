//
//  PatternLockView.swift
//  MobileBinaryOptions
//
//  Created by Anandh on 2/7/17.
//  Copyright © 2017 Broctagon. All rights reserved.
//

import UIKit

protocol PatternLockViewDelegate : NSObjectProtocol {
    func didChangePatternSwitchStatus(isOn: Bool)
    /// isOn: the pattern lock switch status
    func didTapThePatternLock(isOn: Bool)
}

class PatternLockView: UIView {
    
    // PatternLock  BackgroundView
    var  patternlockBackgroundView = UIView()
    
    // Patternlock Label
    var patternLockLabel = UILabel()
    
    // SperatorLabel
    var seperatorLabel = UILabel()
    
    // Switch
    var patternlockModeSwitch = UISwitch()
    
    // AccountManagement page
    var profileBtn  = UIButton()
    var mt4PasswordBtn = UIButton()
    var patternlockButton = UIButton()
    
    // Pattern Delegate
    weak var delegate :PatternLockViewDelegate?
    
    
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */
    
    override init(frame: CGRect) {
        super.init(frame:frame)
        self.addControlsUIForPatternlock()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    func addControlsUIForPatternlock()
    {
        // PatternLockView
        let frame = CGRect(x: CGFloat(0), y: CGFloat(0), width: SCREEN_WIDTH(), height: SCREEN_HEIGHT()*80/100)
        let backgroundImage = UIImageView(frame: frame)
        backgroundImage.image = UIImage(named: "bg2.png")
        self.patternlockBackgroundView.insertSubview(backgroundImage, at: 0)
        self.addSubview(self.patternlockBackgroundView)
        
        // profile Button
//        profileBtn = UIButton(frame: CGRect(x: (SCREEN_WIDTH()*26/100), y:64, width: ((SCREEN_WIDTH()-(SCREEN_WIDTH()*52/100))/3), height: 30))
//        if(SCREEN_WIDTH() <= 568)
//        {
//            profileBtn = UIButton(frame: CGRect(x: (SCREEN_WIDTH()*24/100), y:20, width: ((SCREEN_WIDTH()-(SCREEN_WIDTH()*48/100))/3), height: 30))
//        }
//        else
//        {
//            profileBtn = UIButton(frame: CGRect(x: (SCREEN_WIDTH()*26/100), y:20, width: ((SCREEN_WIDTH()-(SCREEN_WIDTH()*52/100))/3), height: 30))
//            
//        }
        profileBtn = UIButton(frame: CGRect(x: (SCREEN_WIDTH()*22/100), y:10, width: ((SCREEN_WIDTH()*17/100)), height: 30))
        profileBtn.setImage(UIImage(named: "mt4-icon@3x.png"), for: .normal)
        profileBtn.setTitle(LString(key: "Profile"), for: .normal)
        profileBtn.titleEdgeInsets = UIEdgeInsetsMake(0, 10, 0, -10)
        profileBtn.titleLabel?.font = FONT_CUSTOM(12)
        profileBtn.alpha = 0.5
        // profileBtn.addTarget(self, action:#selector(self.backBtnAction), for: .touchUpInside)
        self.addSubview(profileBtn)
        
        // MT4 PasswordButton
//        if(SCREEN_WIDTH() <= 568)
//        {
//            mt4PasswordBtn = UIButton(frame: CGRect(x:(profileBtn.frame.origin.x+profileBtn.frame.size.width+10), y:20, width: ((SCREEN_WIDTH()-(SCREEN_WIDTH()*48/100))/3), height: 30))
//        }
//        else
//        {
//            mt4PasswordBtn = UIButton(frame: CGRect(x:(profileBtn.frame.origin.x+profileBtn.frame.size.width+10), y:20, width: ((SCREEN_WIDTH()-(SCREEN_WIDTH()*52/100))/3), height: 30))
//            
//        }
        mt4PasswordBtn = UIButton(frame: CGRect(x:(profileBtn.frame.origin.x+profileBtn.frame.size.width+(SCREEN_WIDTH()*3/100)), y:10, width:((SCREEN_WIDTH()*17/100)), height: 30))
        mt4PasswordBtn.setImage(UIImage(named: "key_icon@3x.png"), for: .normal)
        mt4PasswordBtn.setTitle(LString(key: "MT4 Password"), for: .normal)
        mt4PasswordBtn.titleLabel?.font = FONT_CUSTOM(12)
        mt4PasswordBtn.titleEdgeInsets = UIEdgeInsetsMake(0, 5, 0, -5)
        mt4PasswordBtn.imageEdgeInsets = UIEdgeInsetsMake(0, 0, 0, 5)
        mt4PasswordBtn.alpha = 0.5
        // mt4PasswordBtn.addTarget(self, action:#selector(self.backBtnAction), for: .touchUpInside)
        self.addSubview(mt4PasswordBtn)
        
        // Pattern lock Button.
//        if(SCREEN_WIDTH() <= 568)
//        {
//            patternlockButton = UIButton(frame: CGRect(x:(mt4PasswordBtn.frame.origin.x+mt4PasswordBtn.frame.size.width+20), y:20, width:((SCREEN_WIDTH()-(SCREEN_WIDTH()*48/100))/3), height: 30))
//        }
//        else
//        {
//            patternlockButton = UIButton(frame: CGRect(x:(mt4PasswordBtn.frame.origin.x+mt4PasswordBtn.frame.size.width+20), y:20, width:((SCREEN_WIDTH()-(SCREEN_WIDTH()*52/100))/3), height: 30))
//        }
         patternlockButton = UIButton(frame: CGRect(x:(mt4PasswordBtn.frame.origin.x+mt4PasswordBtn.frame.size.width+(SCREEN_WIDTH()*3/100)), y:10, width:((SCREEN_WIDTH()*17/100)), height: 30))
        patternlockButton.setImage(UIImage(named: "lock-icon@3x.png"), for: .normal)
        patternlockButton.setTitle(LString(key: "Pattern Lock"), for: .normal)
        patternlockButton.titleLabel?.font = FONT_CUSTOM(12)
        // patternlockButton.addTarget(self, action:#selector(self.backBtnAction), for: .touchUpInside)
        patternlockButton.titleEdgeInsets = UIEdgeInsetsMake(0, 0, 0, -10)
        patternlockButton.imageEdgeInsets = UIEdgeInsetsMake(0, 0, 0, 5)
        self.addSubview(patternlockButton)
        
        // PatternLocklabel
//        if(SCREEN_WIDTH() <= 568)
//        {
//            patternLockLabel.frame = CGRect(x: CGFloat(SCREEN_WIDTH()*24/100 + SCREEN_HEIGHT()*10/100), y: CGFloat(patternlockButton.frame.size.height+patternlockButton.frame.origin.y+40), width: CGFloat(SCREEN_WIDTH()-(SCREEN_WIDTH()*48/100)), height: CGFloat(40))
//        }
//        else
//        {
//            patternLockLabel.frame = CGRect(x: CGFloat(SCREEN_WIDTH()*26/100 + SCREEN_HEIGHT()*10/100), y: CGFloat(patternlockButton.frame.size.height+patternlockButton.frame.origin.y+40), width: CGFloat(SCREEN_WIDTH()-(SCREEN_WIDTH()*52/100)), height: CGFloat(40))
//        }
        
        patternLockLabel.frame = CGRect(x: CGFloat(SCREEN_WIDTH()*26/100 + SCREEN_HEIGHT()*10/100), y: CGFloat(patternlockButton.frame.size.height+patternlockButton.frame.origin.y+(SCREEN_HEIGHT()*15/100)), width: CGFloat(SCREEN_WIDTH()*52/100), height: CGFloat(40))
        patternLockLabel.text = LString(key: "Pattern Lock")
        patternLockLabel.textColor = UIColor.white
        patternLockLabel.textAlignment = .justified
        patternLockLabel.font = FONT_CUSTOM(14)
        self.addSubview(patternLockLabel)
        
        let tapGR = UITapGestureRecognizer(target: self, action: #selector(tapThePatternLockLb))
        patternLockLabel.addGestureRecognizer(tapGR)
        
        // Switch Button
        patternlockModeSwitch=UISwitch(frame: CGRect(x:((patternLockLabel.frame.origin.x+patternLockLabel.frame.width) - 110), y:(patternlockButton.frame.size.height+patternlockButton.frame.origin.y+(SCREEN_HEIGHT()*15/100)), width:SCREEN_WIDTH()*11/100, height: 0));
        patternlockModeSwitch.isOn = false
        patternlockModeSwitch.addTarget(self, action:#selector(self.switchValueDidChange(sender:)), for: .valueChanged);
        self.addSubview(patternlockModeSwitch)
        
        // Seperator Label
        seperatorLabel = UILabel(frame: CGRect(x:CGFloat(SCREEN_WIDTH()*26/100), y:(patternLockLabel.frame.size.height+patternLockLabel.frame.origin.y), width:CGFloat(SCREEN_WIDTH()*52/100), height: 1))
        seperatorLabel.backgroundColor = UIColor.lightGray
        self.addSubview(seperatorLabel)
        
    }
    
    // Mark:- Action
    
    func tapThePatternLockLb() {
        self.delegate?.didTapThePatternLock(isOn: self.patternlockModeSwitch.isOn)
    }
    
    func switchValueDidChange(sender: UISwitch!)
    {
        self.delegate?.didChangePatternSwitchStatus(isOn: sender.isOn)
    }

}
