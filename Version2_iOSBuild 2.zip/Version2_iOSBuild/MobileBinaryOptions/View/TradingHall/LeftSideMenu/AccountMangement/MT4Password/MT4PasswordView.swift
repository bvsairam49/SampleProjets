//
//  MT4PasswordView.swift
//  MobileBinaryOptions
//
//  Created by Anandh on 2/7/17.
//  Copyright © 2017 Broctagon. All rights reserved.
//

import UIKit

class MT4PasswordView: UIView , UITableViewDelegate, UITableViewDataSource {
    
    // MT4View  BackgroundView
    var  mt4BackgroundView = UIView()
    
    // ConfirmButton
    var confirmBtn = UIButton()
    //  CancelButton 
    var cancelBtn = UIButton()
    
    //  MT4 Accounts UI 
    // MT4 AccountsTableView
     var  mt4AccountsTableView = UITableView()
    
    //Account number Label
    var accountNumberLabel = UILabel()
    // PasswordTextFiled
    var passwordTextField = UITextField()
    
    // SperatorLabel
    var seperatorLabel = UILabel()
    
    // AccountManagement page
    var profileBtn  = UIButton()
    var mt4PasswordBtn = UIButton()
    var patternlockButton = UIButton()

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */
    
    override init(frame: CGRect) {
        super.init(frame:frame)
        self.addControlsUIForMT4Password()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    func addControlsUIForMT4Password()
    {
        // MT4PasswordView
        let frame = CGRect(x: CGFloat(0), y: CGFloat(0), width: SCREEN_WIDTH(), height: SCREEN_HEIGHT()*80/100)
        let backgroundImage = UIImageView(frame: frame)
        backgroundImage.image = UIImage(named: "bg2.png")
        self.mt4BackgroundView.insertSubview(backgroundImage, at: 0)
        self.addSubview(self.mt4BackgroundView)
        
        // profile Button
//        if(SCREEN_WIDTH() <= 568)
//        {
//            profileBtn = UIButton(frame: CGRect(x: (SCREEN_WIDTH()*24/100), y:20, width: ((SCREEN_WIDTH()-(SCREEN_WIDTH()*48/100))/3), height: 30))
//        }
//        else
//        {
//            profileBtn = UIButton(frame: CGRect(x: (SCREEN_WIDTH()*26/100), y:20, width: ((SCREEN_WIDTH()-(SCREEN_WIDTH()*52/100))/3), height: 30))
//        }
             profileBtn = UIButton(frame: CGRect(x: (SCREEN_WIDTH()*22/100), y:10, width: ((SCREEN_WIDTH()*17/100)), height: 30))

        profileBtn.setImage(UIImage(named: "mt4-icon@3x.png"), for: .normal)
        profileBtn.setTitle("Profile", for: .normal)
        profileBtn.titleEdgeInsets = UIEdgeInsetsMake(0, 10, 0, -10)
        profileBtn.titleLabel?.font = FONT_CUSTOM(12)
        profileBtn.alpha = 0.5
        // profileBtn.addTarget(self, action:#selector(self.backBtnAction), for: .touchUpInside)
        self.addSubview(profileBtn)
        
        // MT4 PasswordButton
//        if(SCREEN_WIDTH() <= 568)
//        {
//            mt4PasswordBtn = UIButton(frame: CGRect(x:(profileBtn.frame.origin.x+profileBtn.frame.size.width+10), y:20, width: ((SCREEN_WIDTH()-(SCREEN_WIDTH()*48/100))/3), height: 30))
//        }
//        else
//        {
//            mt4PasswordBtn = UIButton(frame: CGRect(x:(profileBtn.frame.origin.x+profileBtn.frame.size.width+10), y:20, width: ((SCREEN_WIDTH()-(SCREEN_WIDTH()*52/100))/3), height: 30))
//        }
        mt4PasswordBtn = UIButton(frame: CGRect(x:(profileBtn.frame.origin.x+profileBtn.frame.size.width+(SCREEN_WIDTH()*3/100)), y:10, width:((SCREEN_WIDTH()*17/100)), height: 30))
        mt4PasswordBtn.setImage(UIImage(named: "key_icon@3x.png"), for: .normal)
        mt4PasswordBtn.setTitle("MT4 Password", for: .normal)
        mt4PasswordBtn.titleLabel?.font = FONT_CUSTOM(12)
        mt4PasswordBtn.titleEdgeInsets = UIEdgeInsetsMake(0, 0, 0, -10)
        // mt4PasswordBtn.addTarget(self, action:#selector(self.backBtnAction), for: .touchUpInside)
        mt4PasswordBtn.imageEdgeInsets = UIEdgeInsetsMake(0, 0, 0, 5)

        self.addSubview(mt4PasswordBtn)
        
        // Pattern lock Button.
//        if(SCREEN_WIDTH() <= 568)
//        {
//            patternlockButton = UIButton(frame: CGRect(x:(mt4PasswordBtn.frame.origin.x+mt4PasswordBtn.frame.size.width+20), y:20, width:((SCREEN_WIDTH()-(SCREEN_WIDTH()*48/100))/3), height: 30))
//        }
//        else
//        {
//            patternlockButton = UIButton(frame: CGRect(x:(mt4PasswordBtn.frame.origin.x+mt4PasswordBtn.frame.size.width+20), y:20, width:((SCREEN_WIDTH()-(SCREEN_WIDTH()*52/100))/3), height: 30))
//        }
        patternlockButton = UIButton(frame: CGRect(x:(mt4PasswordBtn.frame.origin.x+mt4PasswordBtn.frame.size.width+(SCREEN_WIDTH()*3/100)), y:10, width:((SCREEN_WIDTH()*17/100)), height: 30))
        patternlockButton.setImage(UIImage(named: "lock-icon@3x.png"), for: .normal)
        patternlockButton.setTitle("Pattern Lock", for: .normal)
        patternlockButton.titleLabel?.font = FONT_CUSTOM(12)
        // patternlockButton.addTarget(self, action:#selector(self.backBtnAction), for: .touchUpInside)
        patternlockButton.alpha = 0.5
        patternlockButton.titleEdgeInsets = UIEdgeInsetsMake(0, 0, 0, -10)
        self.addSubview(patternlockButton)
        
        // MT4PasswordsView
//        if(SCREEN_WIDTH() <= 568)
//        {
//             mt4AccountsTableView.frame = CGRect(x: CGFloat(SCREEN_WIDTH()*24/100)+20, y: CGFloat(patternlockButton.frame.size.height+patternlockButton.frame.origin.y+10), width: CGFloat(SCREEN_WIDTH()-(SCREEN_WIDTH()*48/100)), height: CGFloat(SCREEN_HEIGHT()-(mt4BackgroundView.frame.origin.y + 20 + (profileBtn.frame.size.height * 3)+84)))
//        }
//        else
//        {
//               mt4AccountsTableView.frame = CGRect(x: CGFloat(SCREEN_WIDTH()*26/100)+20, y: CGFloat(patternlockButton.frame.size.height+patternlockButton.frame.origin.y+10), width: CGFloat(SCREEN_WIDTH()-(SCREEN_WIDTH()*52/100)), height: CGFloat(SCREEN_HEIGHT()-(mt4BackgroundView.frame.origin.y + 20 + (profileBtn.frame.size.height * 3)+84)))
//        }
       mt4AccountsTableView.frame = CGRect(x: CGFloat(SCREEN_WIDTH()*26/100), y: CGFloat(patternlockButton.frame.size.height+patternlockButton.frame.origin.y+(SCREEN_HEIGHT()*8/100)), width: CGFloat((SCREEN_WIDTH()*52/100)), height: CGFloat(SCREEN_HEIGHT()-(mt4BackgroundView.frame.origin.y+(profileBtn.frame.size.height * 3)+(SCREEN_HEIGHT()*34/100))))
        mt4AccountsTableView.backgroundColor = UIColor.clear
        mt4AccountsTableView.layoutMargins = UIEdgeInsets.zero
        mt4AccountsTableView.separatorInset = UIEdgeInsets.zero
        mt4AccountsTableView.dataSource = self
        mt4AccountsTableView.delegate = self
        mt4AccountsTableView.allowsSelection = true
        mt4AccountsTableView.reloadData()
        self.addSubview(mt4AccountsTableView)
        
        //Confirm Btn
        if(SCREEN_WIDTH() <= 568)
        {
            confirmBtn = UIButton(frame: CGRect(x:(mt4AccountsTableView.frame.origin.x+20), y:(mt4AccountsTableView.frame.size.height+mt4AccountsTableView.frame.origin.y+10), width:((SCREEN_WIDTH()-(SCREEN_WIDTH()*48/100))/3), height: 30))
        }
        else
        {
             confirmBtn = UIButton(frame: CGRect(x:(mt4AccountsTableView.frame.origin.x+20), y:(mt4AccountsTableView.frame.size.height+mt4AccountsTableView.frame.origin.y+10), width:((SCREEN_WIDTH()-(SCREEN_WIDTH()*52/100))/3), height: 30))
        }
        confirmBtn.setBackgroundImage(UIImage(named: "btn2@3x.png"), for: .normal)
        confirmBtn.setTitle("Confirm", for: .normal)
        confirmBtn.titleLabel?.font = UIFont.systemFont(ofSize: 14)
        confirmBtn.addTarget(self, action:#selector(self.confirmButtonAction(_:)), for: .touchUpInside)
        confirmBtn.titleLabel?.font = FONT_CUSTOM(14)
        confirmBtn.titleEdgeInsets = UIEdgeInsetsMake(0, 0, 0, -8)
        self.addSubview(confirmBtn)
        
        //Cancel Btn
        if(SCREEN_WIDTH() <= 568)
        {
             cancelBtn = UIButton(frame: CGRect(x:(confirmBtn.frame.origin.x+confirmBtn.frame.size.width+40), y:(mt4AccountsTableView.frame.size.height+mt4AccountsTableView.frame.origin.y+10), width:((SCREEN_WIDTH()-(SCREEN_WIDTH()*48/100))/3), height: 30))
        }
        else
        {
            cancelBtn = UIButton(frame: CGRect(x:(confirmBtn.frame.origin.x+confirmBtn.frame.size.width+40), y:(mt4AccountsTableView.frame.size.height+mt4AccountsTableView.frame.origin.y+10), width:((SCREEN_WIDTH()-(SCREEN_WIDTH()*52/100))/3), height: 30))
        }
        cancelBtn.setBackgroundImage(UIImage(named: "btn2@3x.png"), for: .normal)
        cancelBtn.setTitle("Cancel", for: .normal)
        cancelBtn.titleLabel?.font = FONT_CUSTOM(14)
         cancelBtn.addTarget(self, action:#selector(self.cancelButtonAction(_:)), for: .touchUpInside)
        cancelBtn.titleEdgeInsets = UIEdgeInsetsMake(0, 0, 0, -8)
        self.addSubview(cancelBtn)
    }
    
    // MARK:- TableView Datsource and Delegate methods
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 64
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 10
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell: UITableViewCell? = nil
        let cellIdentifier: String = "\("Cell")\(Int(indexPath.row))"
        cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier)
        
        if cell == nil {
            cell = UITableViewCell(style: .default, reuseIdentifier: cellIdentifier)
            cell?.backgroundColor = UIColor.clear
            mt4AccountsTableView.separatorStyle = .none

            // Mt4 AccountLabel
            accountNumberLabel = UILabel(frame: CGRect(x:0, y:2, width:mt4AccountsTableView.frame.size.width, height: 20))
            accountNumberLabel.text = "2555690:"
             accountNumberLabel.font = FONT_CUSTOM(12)
             accountNumberLabel.textColor = UIColor.white
            cell?.contentView.addSubview(accountNumberLabel)
            
            //MT4Passord TextField
            passwordTextField = UITextField(frame: CGRect(x:2, y:(accountNumberLabel.frame.size.height+accountNumberLabel.frame.origin.y+6), width:(mt4AccountsTableView.frame.size.width-4), height: 30))
            passwordTextField.placeholder = "Password"
            let color = UIColor.lightText
            passwordTextField.attributedPlaceholder = NSAttributedString(string: passwordTextField.placeholder!, attributes: [NSForegroundColorAttributeName : color])
            passwordTextField.font = FONT_CUSTOM(10)
            passwordTextField.textColor = UIColor.lightGray
            passwordTextField.keyboardType = UIKeyboardType.default
            passwordTextField.borderStyle = UITextBorderStyle.none
            passwordTextField.backgroundColor = UIColor.clear
            cell?.contentView.addSubview(passwordTextField)
            
            // Seperator Label
            seperatorLabel = UILabel(frame: CGRect(x:0, y:(passwordTextField.frame.size.height+passwordTextField.frame.origin.y), width:mt4AccountsTableView.frame.size.width, height: 1))
            seperatorLabel.backgroundColor = UIColor.lightGray
            cell?.contentView.addSubview(seperatorLabel)
        }
        return cell!
    }
    // MARK:- Button Action Methods
    func confirmButtonAction(_ sender: UIButton) {
        sender.isSelected = !sender.isSelected
        if (sender.isSelected) {
            confirmBtn.setBackgroundImage(UIImage(named: "btn2_press@3x.png"), for: .normal)
            print("Button action")
        }
        else{
            print("Button")
            confirmBtn.setBackgroundImage(UIImage(named: "btn2@3x.png"), for: .normal)
        }
    }
    
    
    func cancelButtonAction(_ sender: UIButton) {
        sender.isSelected = !sender.isSelected
        if (sender.isSelected) {
            cancelBtn.setBackgroundImage(UIImage(named: "btn2_press@3x.png"), for: .normal)
            print("Button action")
        }
        else{
            print("Button")
            cancelBtn.setBackgroundImage(UIImage(named: "btn2@3x.png"), for: .normal)
        }
    }
}
