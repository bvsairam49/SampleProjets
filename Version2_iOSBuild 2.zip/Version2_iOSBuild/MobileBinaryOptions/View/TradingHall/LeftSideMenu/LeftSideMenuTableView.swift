//
//  LeftSideMenuTableView.swift
//  MobileBinaryOptions
//
//  Created by Anandh on 1/25/17.
//  Copyright © 2017 Broctagon. All rights reserved.
//

import UIKit

// MARK: SetDelegate Method.

protocol LeftMenuTableViewDelegate: NSObjectProtocol {
    func leftMenuTabledidSelectRow(atIndexPath indexpath: Int , withNextViewController:String)
    func leftMenuTapGestureCalled()
}

class LeftSideMenuTableView: UIView,UIGestureRecognizerDelegate, UITableViewDelegate, UITableViewDataSource{
    
    // LeftSide Menu BackgroundView
    var  backgroudView = UIView()
    // AbckButton
    var  backBtn = UIButton()
    // Username label
    var  userNameLabel = UILabel()
    // leftMenuTableView
    var  leftMenuTableView = UITableView()
    weak var delegate: LeftMenuTableViewDelegate?

    // Feature array
    var menuListArray_E = NSMutableArray()
     var menuListArray_C = NSMutableArray()
    // feature image array
     var menuImageIconArray = NSMutableArray()
    // feature Image
     var menuBtnImageView = UIImageView()
    // feature name
//     var featurenameLbl = UILabel()

    // MARK:- LeftMenuside View Initialization.
    
    override init(frame: CGRect) {
        super.init(frame:frame)
        self.addControlToView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    // MARK:- Add Controls For LeftmenuSideView.
    
    func addControlToView() {
        
        
        // English Text
        menuListArray_E = ["Account Management", "Profile","MT4 Password", "Pattern Lock", "Banking", " Deposit","Withdrawal", "Trading history" ,"Settings", "Feedback","About us","Logout"]
    
        
        //  ImagesArray
         menuImageIconArray=["","mt4-icon@3x.png","key_icon@3x.png","lock-icon@3x.png","","deposit_icon@3x.png","withdrawal_icon@3x.png","history_icon@3x.png","setting_icon@3x.png","feedback_icon@3x.png","Home@3x.png","logout-icon@3x.png"]
        
        // TapGesture
        let letterTapRecognizer = UITapGestureRecognizer(target: self, action: #selector(self.highlightLetter))
        letterTapRecognizer.numberOfTapsRequired = 1
        letterTapRecognizer.delegate = self
        self.addGestureRecognizer(letterTapRecognizer)
        
        let swipeLeft = UISwipeGestureRecognizer(target: self, action: #selector(self.handleSwipeLeft))
        swipeLeft.direction = .left
        swipeLeft.delegate = self
        self.addGestureRecognizer(swipeLeft)

        // MenuView
        let frame = CGRect(x: CGFloat(0), y: CGFloat(44), width: SCREEN_WIDTH()/3, height: SCREEN_HEIGHT()-44)
        let backgroundImage = UIImageView(frame: frame)
        backgroundImage.image = UIImage(named: "bg@3x.png")
        self.backgroudView.insertSubview(backgroundImage, at: 0)
        self.addSubview(self.backgroudView)
        
       // Back Button
        backBtn = UIButton(frame: CGRect(x: 5, y:55, width: 30, height: 30))
        backBtn.setImage(UIImage(named: "back_icon@3x.png"), for: .normal)
        backBtn.addTarget(self, action:#selector(self.backBtnAction), for: .touchUpInside)
        addSubview(backBtn)
        // UserName Label
        userNameLabel.frame = CGRect(x: backBtn.frame.origin.x+30, y:55, width: (SCREEN_WIDTH()/4), height: 30)
        userNameLabel.textColor = UIColor.yellow
        userNameLabel.textAlignment = NSTextAlignment.center
        userNameLabel.text = "Will Smith"
        addSubview(userNameLabel)
        
        // Left menutable view
        leftMenuTableView.frame = CGRect(x: 20, y: 90, width:(SCREEN_WIDTH()/4), height:(SCREEN_HEIGHT()))
        leftMenuTableView.bounces = true
        leftMenuTableView.backgroundColor = UIColor.clear
        leftMenuTableView.layoutMargins = UIEdgeInsets.zero
        leftMenuTableView.separatorInset = UIEdgeInsets.zero
        leftMenuTableView.dataSource = self
        leftMenuTableView.delegate = self
        leftMenuTableView.contentInset = UIEdgeInsetsMake(0, 0, 120, 0)
        leftMenuTableView.allowsSelection = true
        
        leftMenuTableView.reloadData()
        self.addSubview(leftMenuTableView)
    }

    // MARK:- Back Button ACtion
    func backBtnAction(_ sender: Any) {
          self.removeFromSuperview()
        print("Button action")
    }
    
    // MARK:- TableView Datasource and Delegate methods.
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return menuListArray_E .count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell: UITableViewCell? = nil
        let cellIdentifier: String = "\("Cell")\(Int(indexPath.row))"
        cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier)
        if cell == nil {
            cell = UITableViewCell(style: .default, reuseIdentifier: cellIdentifier)
            cell?.backgroundColor = UIColor.clear
            cell?.selectionStyle = .none

            // ImageView
            menuBtnImageView  = UIImageView(frame: CGRect(x: CGFloat(10), y: CGFloat(12), width: CGFloat(20), height: CGFloat(20)))
            menuBtnImageView.image = UIImage(named:(named:menuImageIconArray.object(at: indexPath.row) as! String))
            menuBtnImageView.contentMode = UIViewContentMode.scaleAspectFit
            cell?.contentView.addSubview(menuBtnImageView)
            
            // feature name label
        
             let featurenameLbl = UILabel()
             featurenameLbl.frame = (frame:CGRect(x: CGFloat(menuBtnImageView.frame.size.width+menuBtnImageView.frame.origin.x+4), y: CGFloat(10), width:CGFloat(SCREEN_WIDTH()*27/100), height: 24))
            if ((indexPath.row == 0) || (indexPath.row == 4)) {
                featurenameLbl.frame = (frame:CGRect(x: CGFloat(0), y: CGFloat(0), width:CGFloat(SCREEN_WIDTH()*27/100), height: 44))
                featurenameLbl.backgroundColor = UIColor(patternImage: UIImage(named: "list_txt_bg@3x.png")!)
           
            }else
            {
                featurenameLbl.backgroundColor = UIColor.clear
            }
            featurenameLbl.text = menuListArray_E.object(at: indexPath.row) as? String
            featurenameLbl.textAlignment = .left
            featurenameLbl.font = UIFont.systemFont(ofSize: 12)
            featurenameLbl.textColor = UIColor.white
            cell?.contentView.addSubview(featurenameLbl)
        }
        return cell!
    }
    
       func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        self.delegate?.leftMenuTabledidSelectRow(atIndexPath: indexPath.row, withNextViewController: "")
    }
    
    // MARK:- Device Orientation
    
     var shouldAutorotate: Bool {
        return true
    }
    
     var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return .landscape
    }
    
    
    // MARK: -  TAP GESTURE DELEGATE METHOD
    /**
     * This method is used to set Custom delegate For Removing Left Menu from view.
     */
     func highlightLetter(_ sender: UITapGestureRecognizer) {
         if self.delegate != nil {
             self.delegate?.leftMenuTapGestureCalled()
         }
     }
    
     func handleSwipeLeft(_ sender: UITapGestureRecognizer) {
         if self.delegate != nil {
             self.delegate?.leftMenuTapGestureCalled()
         }
     }
    
     func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldReceive touch: UITouch) -> Bool {
        if (touch.view?.isDescendant(of: leftMenuTableView))! {
            return false
        }
        return true
    }
}
