//
//  SymbolCell.swift
//  MobileBinaryOptions
//
//  Created by GE on 17/2/4.
//  Copyright © 2017年 Broctagon. All rights reserved.
//

import UIKit

protocol SymbolCellDelegate : NSObjectProtocol {
    func starSymbol(symbolModel: SymbolModel)
}

class SymbolCell: UITableViewCell {

    @IBOutlet weak var starBtn: BaseBtn!
    @IBOutlet weak var symbolLb: UILabel!
    @IBOutlet weak var alarmBtn: BaseBtn!
    
    var symbolModel: SymbolModel!
    
    var isStar: Bool {
        get {
            return self.starBtn.isSelected
        }
        set {
            self.starBtn.isSelected = newValue
            self.symbolModel.isStar = newValue
        }
    }
    
    weak var delegate :SymbolCellDelegate?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        self.backgroundColor = .clear
        
        self.starBtn.setImage(UIImage(named: "star_normal.png"), for: .normal)
        self.starBtn.setImage(UIImage(named: "star_press.png"), for: .selected)
        self.starBtn.addTarget(self, action: #selector(clickStarBtn), for: .touchUpInside)
        self.starBtn.snp.makeConstraints { (make) in
            make.left.equalTo(COMPUTE_LENGTH(60.0 - 15.0))
            make.top.equalTo(0)
            make.width.height.equalTo(self.snp.height)
        }
        
        self.symbolLb.textColor = kColorTimeframeNormal()
        self.symbolLb.font = FONT_CUSTOM(13.0)
        self.symbolLb.snp.makeConstraints { (make) in
            make.left.equalTo(self.starBtn.snp.right).offset(COMPUTE_LENGTH(30.0))
            make.top.bottom.equalTo(self)
            make.right.equalTo(self.alarmBtn.snp.left)
        }
        
        self.alarmBtn.snp.makeConstraints { (make) in
            make.top.width.height.equalTo(self.starBtn)
            make.right.equalTo(self).offset(COMPUTE_LENGTH(60.0 - 15.0))
        }
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        
        self.symbolLb.text = self.symbolModel.name
        self.isStar = self.symbolModel.isStar
    }
    
    func clickStarBtn() {
        self.isStar = !self.isStar
        self.delegate?.starSymbol(symbolModel: self.symbolModel)
    }
}
