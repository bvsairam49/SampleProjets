//
//  OptionBtn.swift
//  MobileBinaryOptions
//
//  Created by GE on 17/1/17.
//  Copyright © 2017年 pc003. All rights reserved.
//

import UIKit

class OptionBtn: BaseBtn {
    
    let signImgView = UIImageView()
    let infoLb  = UILabel()
    let arrowImgView = UIImageView()
    
    var signImgName: String?
    var info = ""
    var isShowInfo = true
    
    var _isShowArrow = false
    var isShowArrow: Bool {
        get {
            return _isShowArrow
        }
        set(newValue) {
            _isShowArrow = newValue
            self.showArrow(isShowArrow: newValue)
        }
    }
    
    var isOpen: Bool {
        get {
            return self.isSelected
        }
        set(newValue) {
            if self.isSelected != newValue {
                self.turnAroundTheArrow()
            }
            
            self.isSelected = newValue
        }
    }
    
    var _backImgNameNormal = "btnBorder_normal.png"
    var backImgNameNormal: String {
        get {
            return _backImgNameNormal
        }
        set {
            _backImgNameNormal = newValue
            let backImg = self.resizableImage(imgName: newValue)
            self.setImage(backImg, for: .normal)
        }
    }
    
    var _backImgNameSelected = "btnBorder_normal.png"
    var backImgNameSelected: String {
        get {
            return _backImgNameSelected
        }
        set {
            _backImgNameSelected = newValue
            let backImg = self.resizableImage(imgName: newValue)
            self.setImage(backImg, for: .selected)
        }
    }
    
    var _infoColor = kColorTimeframeNormal()
    var infoColor: UIColor {
        get {
            return _infoColor
        }
        set {
            _infoColor = newValue
            self.infoLb.textColor = self.infoColor
        }
    }
    
    var _options = Array<String>()   // record the options for the option
    var options: Array<String> {
        get {
            return _options
        }
        set {
            _options = newValue
            self.isShowArrow = _options.count > 1
        }
    }
    
    init(signImgName: String, isShowArrow: Bool) {
        super.init(frame: .zero)
        
        self.signImgName = signImgName
        self.isShowArrow = isShowArrow
        self.isShowInfo = false
        
        self.createUI()
    }
    
    init(signImgName: String, info: String, isShowArrow: Bool) {
        super.init(frame: .zero)
        
        self.signImgName = signImgName
        self.info        = info
        self.isShowArrow = isShowArrow
        
        self.createUI()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func createUI() {
        let backImgNormal = self.resizableImage(imgName: self.backImgNameNormal)
        self.setImage(backImgNormal, for: .normal)
        let backImgSelected = self.resizableImage(imgName: self.backImgNameSelected)
        self.setImage(backImgSelected, for: .selected)
        
        self.infoLb.textAlignment = .center
        self.infoLb.textColor = self.infoColor
        self.infoLb.font = FONT_CUSTOM(9.0)
        self.infoLb.text = self.info
        
        self.addSubview(self.signImgView)
        self.addSubview(self.infoLb)
        self.addSubview(self.arrowImgView)
        
        self.signImgView.image = UIImage(named: self.signImgName!)
        self.arrowImgView.image = UIImage.init(named: "arrow_triangle.png")
        
        self.signImgView.snp.makeConstraints { (make) in
            make.width.height.equalTo(COMPUTE_LENGTH(40.0))
            make.centerY.equalTo(self)
            make.centerX.equalTo((backImgNormal.size.width)/462.0*40)
        }
        
        self.infoLb.snp.makeConstraints { (make) in
            if self.isShowInfo {
                make.left.equalTo(self.signImgView.snp.right).offset(2)
                make.right.equalTo(self.arrowImgView.snp.left).offset(-2)
                make.top.height.equalTo(self.signImgView)
            }else {
                make.left.top.width.height.equalTo(0)
            }
        }
        
        self.arrowImgView.snp.makeConstraints { (make) in
            make.right.equalTo(self).offset(-(backImgNormal.size.width)/462.0*40.0/2.0)
            
            if self.isShowArrow {
                make.width.equalTo(COMPUTE_LENGTH(28.0))
                make.height.equalTo(COMPUTE_LENGTH(28/16.0*10.0))
            }else {
                make.width.equalTo(0)
                make.height.equalTo(0)
            }
            
            make.centerY.equalTo(self)
        }
    }
    
    func resizableImage(imgName: String) -> UIImage {
        var backImg = UIImage(named: imgName)
        backImg = backImg?.resizableImage(withCapInsets: UIEdgeInsetsMake(0, (backImg?.size.width)!/462.0*40, 0, (backImg?.size.width)!/462.0*40), resizingMode: .stretch)
        return backImg!
    }
    
    // will be invoked when we set isShowArrow
    func showArrow(isShowArrow: Bool) {
        self.isEnabled = isShowArrow
        
        // will set once before createUI, but must setConstraints after addSubview
        if (self.arrowImgView.superview != nil) {
            self.arrowImgView.snp.updateConstraints { (make) in
                if self.isShowArrow {
                    make.width.equalTo(COMPUTE_LENGTH(28.0))
                    make.height.equalTo(COMPUTE_LENGTH(28/16.0*10.0))
                }else {
                    make.width.equalTo(0)
                    make.height.equalTo(0)
                }
            }
        }
    }
    
    func turnAroundTheArrow() {
        UIView.animate(withDuration: 0.3, animations: {
            self.arrowImgView.transform = self.arrowImgView.transform.rotated(by: CGFloat(M_PI))
        })
    }
    
    /*
     // Only override draw() if you perform custom drawing.
     // An empty implementation adversely affects performance during animation.
     override func draw(_ rect: CGRect) {
     // Drawing code
     }
     */
    
}
