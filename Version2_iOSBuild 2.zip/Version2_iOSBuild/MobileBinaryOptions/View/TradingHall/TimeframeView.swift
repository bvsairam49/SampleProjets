//
//  TimeframeView.swift
//  MobileBinaryOptions
//
//  Created by GE on 17/1/17.
//  Copyright © 2017年 pc003. All rights reserved.
//

import UIKit

protocol TimeframeViewDelegate : NSObjectProtocol {
    func didChangeTimeframe(timeframe: String, lastTimeframe: String)
}

class TimeframeView: UIView {
    
    var values = Array<String>()
    var selectedValue = ""
    var _selectedIndex = 0
    var selectedIndex: Int {
        get {
            return _selectedIndex
        }
        set {
            _selectedIndex = newValue
            self.didChangeSelectedIndex()
        }
    }
    
    var timeframeBtns = Array<BaseBtn>()
    var selectedBtn: BaseBtn?
    
    weak var delegate :TimeframeViewDelegate?
    
    init(values: Array<String>, selectedIndex: Int) {
        super.init(frame: .zero)
        
        self.values = values
        self.createUI()
        
        self.selectedIndex = selectedIndex
    }
    
    init(values: Array<String>, selectedValue: String) {
        super.init(frame: .zero)
        
        self.values = values
        self.createUI()
        
        self.selectedIndex = values.index(of: selectedValue)!
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func createUI() {
        let leftBtn = BaseBtn()
        leftBtn.setImage(UIImage(named: "arrow_turnLeft_normal.png"), for: .normal)
        leftBtn.tagName = "leftBtn"
        leftBtn.addTarget(self, action: #selector(turnLeftOrRight(btn:)), for: .touchUpInside)
        self.addSubview(leftBtn)
        
        leftBtn.snp.makeConstraints { (make) in
            make.top.left.equalTo(0)
            make.width.height.equalTo(self.snp.height)
        }
        
        let rightBtn = BaseBtn()
        rightBtn.setImage(UIImage(named: "arrow_turnRight_normal.png"), for: .normal)
        rightBtn.tagName = "rightBtn"
        rightBtn.addTarget(self, action: #selector(turnLeftOrRight(btn:)), for: .touchUpInside)
        self.addSubview(rightBtn)
        
        rightBtn.snp.makeConstraints { (make) in
            make.top.width.height.equalTo(leftBtn)
            make.right.equalTo(self)
        }
        
        var lastBtn: BaseBtn?
        for i in 0..<self.values.count {
            let timeframeBtn = BaseBtn()
            timeframeBtn.setTitleColor(kColorTimeframeNormal(), for: .normal)
            timeframeBtn.showBorder(1, borderColor: kColorTimeframeNormal())
            timeframeBtn.titleLabel?.textAlignment = .center
            timeframeBtn.titleLabel?.font = FONT_CUSTOM(10.0)
            timeframeBtn.setTitle(self.values[i], for: .normal)
            timeframeBtn.tag = i
            self.addSubview(timeframeBtn)
            
            timeframeBtn.addTarget(self, action: #selector(selectTimeframe(btn:)), for: .touchUpInside)
            
            timeframeBtn.snp.makeConstraints({ (make) in
                if i == 0 {
                    make.left.equalTo(leftBtn.snp.right).offset(1)
                }else if let tempBtn = lastBtn {
                    make.left.equalTo(tempBtn.snp.right).offset(1)
                    make.width.equalTo(tempBtn)
                    if i == self.values.count-1 {
                        make.right.equalTo(rightBtn.snp.left).offset(-1)
                    }
                }
                
                make.top.height.equalTo(self)
            })
            
            timeframeBtns.append(timeframeBtn)
            lastBtn = timeframeBtn
        }
    }
    
    func turnLeftOrRight(btn: BaseBtn) {
        if btn.tagName ==  "leftBtn" && self.selectedIndex > 0 {
            self.selectedIndex -= 1
        }else if btn.tagName ==  "rightBtn" && self.selectedIndex < timeframeBtns.count - 1 {
            self.selectedIndex += 1
        }
    }
    
    func selectTimeframe(btn: BaseBtn) {
        self.selectedIndex = btn.tag
    }
    
    func didChangeSelectedIndex() {
        if let lastSelectedBtn = self.selectedBtn {
            lastSelectedBtn.setTitleColor(kColorTimeframeNormal(), for: .normal)
            lastSelectedBtn.showBorder(1, borderColor: kColorTimeframeNormal())
        }
        self.selectedBtn = timeframeBtns[self.selectedIndex]
        self.selectedBtn?.setTitleColor(kColorTimeframeSelected(), for: .normal)
        self.selectedBtn?.showBorder(1, borderColor: kColorTimeframeSelected())
        self.selectedValue = values[self.selectedIndex]
    }
    
}
