//
//  HistoryCell.swift
//  MobileBinaryOptions
//
//  Created by GE on 17/2/11.
//  Copyright © 2017年 Broctagon. All rights reserved.
//

import UIKit

class HistoryCell: UITableViewCell {
    
    let tblOrderNumberLabel = UILabel()
    let tblDateLabel  = UILabel()
    let tblSymbolLabel = UILabel()
    let tblActionLabel = UILabel()
    let tblOpenLabel = UILabel()
    let tblCloseLabel = UILabel()
    let tblAmountLabel = UILabel()
    let tblProfitLabel = UILabel()
    let tblInternalLabel = UILabel()
    let tblResultLabel = UILabel()
    
    var actionImgView = UIImageView()   // up or down icon

    override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        self.createUI()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func createUI() {
        self.backgroundColor = .clear
        
        self.tblOrderNumberLabel.frame = CGRect(x:(SCREEN_WIDTH() * -43/100), y:-5, width: SCREEN_WIDTH(), height: 44)
        self.tblOrderNumberLabel.textColor = UIColor.white
        self.tblOrderNumberLabel.textAlignment = .center
        self.tblOrderNumberLabel.font = UIFont.systemFont(ofSize: 10)
        self.tblOrderNumberLabel.lineBreakMode = NSLineBreakMode.byWordWrapping
        self.tblOrderNumberLabel.numberOfLines = 0
        self.contentView.addSubview(self.tblOrderNumberLabel)
        
        self.tblDateLabel.frame = CGRect(x: (SCREEN_WIDTH() * -34/100), y:-5, width: SCREEN_WIDTH(), height: 44)
        self.tblDateLabel.numberOfLines = 2
        self.tblDateLabel.textColor = UIColor.white
        self.tblDateLabel.textAlignment = .center
        self.tblDateLabel.font = UIFont.systemFont(ofSize: 10)
        self.tblDateLabel.lineBreakMode = NSLineBreakMode.byWordWrapping
        self.contentView.addSubview(self.tblDateLabel)
        
        self.tblSymbolLabel.frame = CGRect(x: (SCREEN_WIDTH() * -25/100), y:-5, width: SCREEN_WIDTH(), height: 44)
        self.tblSymbolLabel.textColor = UIColor.yellow
        self.tblSymbolLabel.textAlignment = .center
        self.tblSymbolLabel.font = UIFont.systemFont(ofSize: 10)
        self.tblSymbolLabel.lineBreakMode = NSLineBreakMode.byWordWrapping
        self.contentView.addSubview(self.tblSymbolLabel)
        
        self.actionImgView.frame = CGRect(x: (SCREEN_WIDTH() * 34/100), y:8, width: 12, height: 9)
        self.contentView.addSubview(self.actionImgView)
        
        self.tblOpenLabel.frame = CGRect(x: (SCREEN_WIDTH() * -7/100), y:-5, width: SCREEN_WIDTH(), height: 44)
        self.tblOpenLabel.textColor = UIColor.white
        self.tblOpenLabel.textAlignment = .center
        self.tblOpenLabel.font = UIFont.systemFont(ofSize: 10)
        self.tblOpenLabel.lineBreakMode = NSLineBreakMode.byWordWrapping
        self.contentView.addSubview(self.tblOpenLabel)
        
        self.tblCloseLabel.frame = CGRect(x: (SCREEN_WIDTH() * -0/100), y:-5, width: SCREEN_WIDTH(), height: 44)
        self.tblCloseLabel.textColor = UIColor.white
        self.tblCloseLabel.textAlignment = .center
        self.tblCloseLabel.font = UIFont.systemFont(ofSize: 10)
        self.tblCloseLabel.lineBreakMode = NSLineBreakMode.byWordWrapping
        self.contentView.addSubview(self.tblCloseLabel)
        
        self.tblAmountLabel.frame = CGRect(x: (SCREEN_WIDTH() * 10/100), y:-5, width: SCREEN_WIDTH(), height: 44)
        self.tblAmountLabel.textColor = UIColor.white
        self.tblAmountLabel.textAlignment = .center
        self.tblAmountLabel.font = UIFont.systemFont(ofSize: 10)
        self.tblAmountLabel.lineBreakMode = NSLineBreakMode.byWordWrapping
        self.contentView.addSubview(self.tblAmountLabel)
        
        
        self.tblProfitLabel.frame = CGRect(x: (SCREEN_WIDTH() * 20/100), y:-5, width: SCREEN_WIDTH(), height: 44)
        self.tblProfitLabel.textColor = UIColor.white
        self.tblProfitLabel.textAlignment = .center
        self.tblProfitLabel.font = UIFont.systemFont(ofSize: 10)
        self.tblProfitLabel.lineBreakMode = NSLineBreakMode.byWordWrapping
        self.contentView.addSubview(tblProfitLabel)
        
        self.tblInternalLabel.frame = CGRect(x: (SCREEN_WIDTH() * 29/100), y:-5, width: SCREEN_WIDTH(), height: 44)
        self.tblInternalLabel.textColor = UIColor.white
        self.tblInternalLabel.textAlignment = .center
        self.tblInternalLabel.font = UIFont.systemFont(ofSize: 10)
        self.tblInternalLabel.lineBreakMode = NSLineBreakMode.byWordWrapping
        self.contentView.addSubview(self.tblInternalLabel)
        
        self.tblResultLabel.frame = CGRect(x: (SCREEN_WIDTH() * 39/100), y:-5, width: SCREEN_WIDTH(), height: 44)
        self.tblResultLabel.textAlignment = .center
        self.tblResultLabel.font = UIFont.systemFont(ofSize: 10)
        self.tblResultLabel.lineBreakMode = NSLineBreakMode.byWordWrapping
        self.contentView.addSubview(self.tblResultLabel)
    }
}
