//
//  CustomAlertView.swift
//  MobileBinaryOptions
//
//  Created by GE on 17/2/4.
//  Copyright © 2017年 Broctagon. All rights reserved.
//

import UIKit

class CustomAlertView: UIView {
    
    let titleLb = UILabel()
    let closeBtn = BaseBtn()
    let contentView = UIView()
    let detailsView = UIView()  /// content details view
    let controlView = UIView()  /// control btns backView
    
    var title = ""
    var btnTitles = Array<String>()

    init(title: String, btnTitles: Array<String>) {
        super.init(frame: .zero)
        
        self.title = title
        self.btnTitles = btnTitles
        
        self.createUI()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    func createUI() {
        self.createBasicUI()
        self.createCustomUI()
    }
    
    func createBasicUI() {
        let alertBackView = UIView()
        self.addSubview(alertBackView)
        
        /*******   topView   *******/
        
        let topBackImgView = UIImageView()
        topBackImgView.isUserInteractionEnabled = true
        topBackImgView.image = UIImage(named: "alertTitle_background.png")
        alertBackView.addSubview(topBackImgView)
        
        self.titleLb.textAlignment = .center
        self.titleLb.font = FONT_CUSTOM(15.0)
        self.titleLb.textColor = kColorTimeframeSelected()
        self.titleLb.text = self.title
        topBackImgView.addSubview(self.titleLb)
        
        self.closeBtn.setImage(UIImage(named: "close_circle.png"), for: .normal)
        self.closeBtn.addTarget(self, action: #selector(close), for: .touchUpInside)
        topBackImgView.addSubview(self.closeBtn)
        
        /*******   contentView   *******/
        
        alertBackView.addSubview(self.contentView)
        
        let contentBackImgView = UIImageView()
        contentBackImgView.image = UIImage(named: "alertView_background.png")
        self.contentView.addSubview(contentBackImgView)
        
        self.contentView.addSubview(self.detailsView)
        self.contentView.addSubview(self.controlView)
        
        self.createControlBtns()
        
        alertBackView.snp.makeConstraints { (make) in
            make.width.equalTo(COMPUTE_LENGTH(939.0))
            make.center.equalTo(self)
            make.bottom.equalTo(self.contentView)
        }
        
        topBackImgView.snp.makeConstraints { (make) in
            make.top.left.width.equalTo(alertBackView)
            make.height.equalTo(COMPUTE_LENGTH(83.0))
        }
        
        self.titleLb.snp.makeConstraints { (make) in
            make.top.height.centerX.equalTo(topBackImgView)
            make.width.equalTo(topBackImgView).offset(-COMPUTE_LENGTH(130.0))
        }
        
        self.closeBtn.snp.makeConstraints { (make) in
            make.width.height.equalTo(COMPUTE_LENGTH(50.0 + 30.0))
            make.right.equalTo(topBackImgView).offset(-COMPUTE_LENGTH(15.0))
            make.centerY.equalTo(topBackImgView)
        }
        
        self.contentView.snp.makeConstraints { (make) in
            make.left.right.equalTo(alertBackView)
            make.top.equalTo(topBackImgView.snp.bottom).offset(1.0)
            make.bottom.equalTo(self.controlView)
        }
        
        contentBackImgView.snp.makeConstraints { (make) in
            make.edges.equalTo(self.contentView)
        }
        
        self.detailsView.snp.makeConstraints { (make) in
            make.left.right.top.equalTo(self.contentView)
        }
        
        self.controlView.snp.makeConstraints { (make) in
            make.left.right.equalTo(self.contentView)
            make.top.equalTo(self.detailsView.snp.bottom)
            
            if self.btnTitles.count > 0 {
                make.height.equalTo(COMPUTE_LENGTH(75.0 + 30.0))
            }else {
                make.height.equalTo(0)
            }
        }
    }
    
    func createControlBtns() {
        if self.btnTitles.count == 0 {
            return
        }
        
        let btnBackView = UIView()
        self.controlView.addSubview(btnBackView)
        
        var lastBtn: BaseBtn?
        for title in self.btnTitles {
            let controlBtn = BaseBtn()
            controlBtn.titleLabel?.font = FONT_CUSTOM(13.0)
            controlBtn.setTitle(title, for: .normal)
            controlBtn.showCorner(COMPUTE_LENGTH(75.0 / 2.0), borderWidth: 1.0, borderColor: kColorTimeframeSelected())
            btnBackView.addSubview(controlBtn)
            
            controlBtn.snp.makeConstraints({ (make) in
                make.top.height.equalTo(btnBackView)
                make.width.equalTo(COMPUTE_LENGTH(222.0))
                if let tempBtn = lastBtn {
                    make.left.equalTo(tempBtn.snp.right).offset(COMPUTE_LENGTH(69.0))
                }else {
                    make.left.equalTo(0)
                }
            })
            
            lastBtn = controlBtn
        }
        
        btnBackView.snp.makeConstraints { (make) in
            make.centerX.equalTo(self.controlView)
            make.top.equalTo(0)
            make.height.equalTo(COMPUTE_LENGTH(75.0))
            if let tempBtn = lastBtn {
                make.right.equalTo(tempBtn)
            }
        }
    }
    
    func createCustomUI() {
        
    }
    
    func close() {
        self.removeFromSuperview()
    }
}
