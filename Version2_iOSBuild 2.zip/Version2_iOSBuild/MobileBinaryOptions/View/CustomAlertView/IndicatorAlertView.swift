//
//  IndicatorAlertView.swift
//  MobileBinaryOptions
//
//  Created by GE on 17/2/4.
//  Copyright © 2017年 Broctagon. All rights reserved.
//

import UIKit

enum IndicatorType : Int {
    
    case BOLL
    case MACD
    case KD
    case SMA
    case RSI
    case EMA
    case zero
}

//public struct IndicatorType : OptionSet {
//    public init(rawValue: UInt)
//    
//    public static var BOLL: IndicatorType { get }
//    public static var MACD: IndicatorType { get }
//    public static var KD: IndicatorType { get }
//    public static var SMA: IndicatorType { get }
//    public static var RSI: IndicatorType { get }
//    public static var EMA: IndicatorType { get }
//    public static var Zero: IndicatorType { get }
//}

class IndicatorAlertView: CustomAlertView {
    
    var indicatorType: IndicatorType = IndicatorType.zero
    
    init(indicatorType: IndicatorType, title: String, btnTitles: Array<String>) {
        self.indicatorType = indicatorType
        super.init(title: title, btnTitles: btnTitles)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func createCustomUI() {
        super.createCustomUI()
        
        let array = ["K Period:","D Period:","Slowing:"]
        
        var lastLb: UILabel?
        for info in array {
            let keyLb = UILabel()
            keyLb.font = FONT_CUSTOM(13.0)
            keyLb.textColor = .white
            keyLb.text = info
            self.detailsView.addSubview(keyLb)
            
            let slider = UISlider()
            slider.thumbImage(for: .normal)
            slider.setThumbImage(UIImage(named: "sliderTrack.png"), for: .normal)
            self.detailsView.addSubview(slider)
            
            keyLb.snp.makeConstraints({ (make) in
                make.left.equalTo(COMPUTE_LENGTH(100.0))
                make.width.equalTo(COMPUTE_LENGTH(220.0))
                make.height.equalTo(COMPUTE_LENGTH(80.0))
                if let tempLb = lastLb {
                    make.top.equalTo(tempLb.snp.bottom).offset(COMPUTE_LENGTH(40.0))
                }else {
                    make.top.equalTo(COMPUTE_LENGTH(70.0))
                }
            })
            
            slider.snp.makeConstraints { (make) in
                make.left.equalTo(keyLb.snp.right).offset(5)
                make.right.equalTo(self.detailsView).offset(-COMPUTE_LENGTH(100.0))
                make.top.height.equalTo(keyLb)
            }
            
            lastLb = keyLb
        }
        
        self.detailsView.snp.makeConstraints { (make) in
            if let tempLb = lastLb {
                make.bottom.equalTo(tempLb.snp.bottom).offset(COMPUTE_LENGTH(70.0))
            }
        }
    }

}
