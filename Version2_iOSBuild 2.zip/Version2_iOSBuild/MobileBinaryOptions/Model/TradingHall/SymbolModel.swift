//
//  SymbolModel.swift
//  MobileBinaryOptions
//
//  Created by GE on 17/2/10.
//  Copyright © 2017年 Broctagon. All rights reserved.
//

import UIKit

class SymbolModel: BaseModel {
    
    var name = ""
    var isStar = false  /// use in PickSymbolVC
    
    
}
