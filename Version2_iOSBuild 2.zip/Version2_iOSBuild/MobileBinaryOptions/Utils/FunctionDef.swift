//
//  FunctionDef.swift
//  MobileBinaryOptions
//
//  Created by GE on 17/2/4.
//  Copyright © 2017年 Broctagon. All rights reserved.
//

import UIKit

func SCREEN_WIDTH() -> CGFloat {
    return UIScreen.main.bounds.width
}

func SCREEN_HEIGHT() -> CGFloat {
    return UIScreen.main.bounds.height
}

func COMPUTE_LENGTH(_ length: CGFloat) -> CGFloat {
    let originLength: CGFloat = SCREEN_WIDTH() > SCREEN_HEIGHT() ? 2208.0 : 1242.0
    return length / originLength * SCREEN_WIDTH()
}


// MARK: - LocalizedString

let kLanguage = "kLanguage"
let kLanguageDidChangeNotification = "kLanguageDidChangeNotification"

let LANG_ZH = "zh"
let LANG_EN = "en"

func LString(key: String) -> String {
    return NSLocalizedString(key, tableName: appLanguage(), bundle: .main, value: "", comment: "")
}

func appLanguage() -> String? {
    return UserDefaults.standard.object(forKey: kLanguage) as! String?
}

func setLanguage(lang: String) {
    UserDefaults.standard.set(lang, forKey: kLanguage)
    UserDefaults.standard.synchronize()
    NotificationCenter.default.post(name: NSNotification.Name(rawValue: kLanguageDidChangeNotification), object: nil)
}

func isChineseLanguage() -> Bool {
    return (appLanguage() == LANG_ZH)
}



