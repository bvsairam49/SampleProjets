//
//  FontDef.swift
//  MobileBinaryOptions
//
//  Created by GE on 17/2/7.
//  Copyright © 2017年 Broctagon. All rights reserved.
//

import UIKit

func FONT_CUSTOM(_ fontSize: CGFloat) -> UIFont {
    return UIFont.systemFont(ofSize: fontSize)
}

/// compute text rect with font and size
func kGetTextRect(text: NSString,font: UIFont,size: CGSize) -> CGRect {
    let attributes = [NSFontAttributeName: font]
    let option = NSStringDrawingOptions.usesLineFragmentOrigin
    let rect: CGRect = text.boundingRect(with: size, options: option, attributes: attributes, context: nil)
    return rect;
}
