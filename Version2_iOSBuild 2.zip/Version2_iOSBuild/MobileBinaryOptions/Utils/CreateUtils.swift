//
//  CreateUtils.swift
//  podTest2
//
//  Created by Jerry song on 17/2/14.
//  Copyright © 2017年 Test. All rights reserved.
//

import UIKit

class CreateUtils: NSObject {
    
    
    class func createLabelWithText(text :String,TextColor textColor:UIColor,FontSize fontSize:CGFloat) ->UILabel{
        
        let label = UILabel.init()
        label.textColor = textColor
        label.font = FONT_CUSTOM(fontSize) 
        label.text = text
        return label
    }
    
    class func createLabel(frame :CGRect,labelText text:String,textColor:UIColor,FontSize fontSize:CGFloat) ->UILabel{
        let label = UILabel.init()
        label.frame = frame
        label.text = text
        label.textColor = textColor
        label.font = FONT_CUSTOM(fontSize)
        return label
    }
    
    class func createButtonWithtitle(title :String,TitleColor titleColor:UIColor,FontSize fontSize:CGFloat) ->UIButton {
        
        let button = UIButton.init(type: .custom)
        button.setTitle(title, for: .normal)
        button.setTitleColor(titleColor, for: .normal)
        button.titleLabel?.font = FONT_CUSTOM(fontSize)
        return button
    }
    
    class func createButton(frame :CGRect?,Title title:String,TitleColor titleColor:UIColor,FontSize fontSize:CGFloat,BackgroundColor backgroundColor :UIColor?) ->UIButton {
        
        let button = UIButton.init(type: .custom)
        button.setTitle(title, for: .normal)
        button.setTitleColor(titleColor, for: .normal)
        button.titleLabel?.font = FONT_CUSTOM(fontSize)
        if (frame != nil) {
            
            button.frame = frame!
        }
        if (backgroundColor != nil) {
             button.backgroundColor = backgroundColor
        }
       
        return button
    }
    
    
    class func createTextFieldWithTitle(title :String,TitleColor titleColor:UIColor,FontSize fontSize:CGFloat,TextAlignment textAlignment: NSTextAlignment)->UITextField{
        
        let testField = UITextField.init()
        testField.placeholder = title
        testField.textAlignment = textAlignment
        testField.textColor = titleColor
        testField.font = FONT_CUSTOM(fontSize) 
        return testField
    }
    
    
    
    
    
    
}
