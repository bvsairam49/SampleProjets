//
//  ColorDef.swift
//  MobileBinaryOptions
//
//  Created by GE on 17/1/19.
//  Copyright © 2017年 pc003. All rights reserved.
//

import UIKit

func kColorWhite() -> UIColor {
    return .white
}

func kColorTimeframeNormal() -> UIColor {
    return UIColor(red: 255.0 / 255.0, green: 255.0 / 255.0, blue: 255.0 / 255.0, alpha: 0.3)
}

func kColorTimeframeSelected() -> UIColor {
    return UIColor(red: 249.0 / 255.0, green: 199.0 / 255.0, blue: 81.0 / 255.0, alpha: 1.0)
}

func kColorBalanceText() -> UIColor {
    return UIColor(red: 222.0 / 255.0, green: 193.0 / 255.0, blue: 91.0 / 255.0, alpha: 1.0)
}

func kColorBalance() -> UIColor {
    return UIColor(red: 214.0 / 255.0, green: 212.0 / 255.0, blue: 31.0 / 255.0, alpha: 1.0)
}

func kColorDeposit() -> UIColor {
    return UIColor(red: 206.0 / 255.0, green: 206.0 / 255.0, blue: 38.0 / 255.0, alpha: 1.0)
}

func kColorFavouriteSelected() -> UIColor {
    return UIColor(red: 175.0 / 255.0, green: 142.0 / 255.0, blue: 27.0 / 255.0, alpha: 1.0)
}


func kColorEarning() -> UIColor {
    return UIColor(red: 31.0/255, green: 214.0/255, blue: 164.0/255, alpha: 1.0)
}

func kColorWinEnd() -> UIColor {
    return UIColor(red: 231.0/255, green: 106.0/255, blue: 112.0/255, alpha: 1.0)
}

func kColorLossEnd() -> UIColor {
    return UIColor(red: 31.0/255, green: 214.0/255, blue: 164.0/255, alpha: 1.0)
}

func kColorTieEnd() -> UIColor {
    return UIColor(red: 249.0/255, green: 199.0/255, blue: 81.0/255, alpha: 1.0)
}

func kColorPrice() -> UIColor {
    return UIColor(red: 214.0/255, green: 212.0/255, blue: 31.0/255, alpha: 1.0)
}
func kColorDouble() -> UIColor {
    return UIColor(red: 249.0/255, green: 199.0/255, blue: 81.0/255, alpha: 1.0)
}
func kColorOpenBackground() -> UIColor {
    return UIColor(red: 255.0/255, green: 255.0/255, blue: 255.0/255, alpha: 0.15)
}
func kColorProfilelabel() -> UIColor {
    return UIColor(red: 119.0 / 255.0, green: 144.0 / 255.0, blue: 171.0 / 255.0, alpha: 1.0)
}
func kColorProfileSeperatorlabel() -> UIColor {
    return UIColor(red: 142.0 / 255.0, green: 153.0 / 255.0, blue: 172.0 / 255.0, alpha: 1.0)
}
