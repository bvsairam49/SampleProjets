//
//  TradingHallVC.swift
//  MobileBinaryOptions
//
//  Created by GE on 17/1/16.
//  Copyright © 2017年 pc003. All rights reserved.
//

import UIKit

class TradingHallVC: BaseVC,UITableViewDataSource,UITableViewDelegate,TimeframeViewDelegate,RightViewDelegate,NumberPadViewDelegate,OpenPositionViewDelegate,TradingParticularsViewDelegate,ClosePositionsViewDelegate,OptionCellDelegate,LeftMenuTableViewDelegate {
    
    let numberPadVeiw = NumberPadView()
    let openPositionsView = OpenPositionsView()   // openVC
    let closepositionsView = ClosePositionsView()  // closeVC
    
    let tradingParticularsView = TradingParticularsView()
    var tradingHistroyVC  = TradingHistroyVC()  // tradingHistroyVC
    
    let topView = UIView()
    let bottomView = UIView()
    let tradingRightView = RightView()
    let topRightView = UIView()
    let chartView = UIView()
    
    
    let userBtn = OptionBtn(signImgName: "mt4_icon_normal.png", info: "12345678", isShowArrow: false)
    let symbolBtn = OptionBtn(signImgName: "star_normal.png", info: "EURUSDbo", isShowArrow: true)
    let periodBtn = OptionBtn(signImgName: "period_icon_normal.png", info: "15M-78%", isShowArrow: true)
    
    let indicatorBtn = OptionBtn(signImgName: "indicator_icon_normal.png", isShowArrow: true)
    let timeLb = UILabel()
    let favouriteView = FavouriteView(values: ["123","456","789"], selectedValue: "123")
    
    var timeframeView: TimeframeView?
    
    let balanceLb = UILabel()
    let depositBtn = OptionBtn(signImgName: "deposit.png", info: LString(key: "Deposit"), isShowArrow: false)
    
    var userTableView: BaseTableView?
    var periodTableView: BaseTableView?
    var indicatorTableView: BaseTableView?
    let pickSymbolVC = PickSymbolVC()
    
    //record the selected btn,use for showing one optionsTV at a time
    var selectedOptionBtn: OptionBtn?
    var selectedOptionTV: BaseTableView?
    
    // Left SlideMenu
    let menuSlider = LeftSideMenuTableView()

    
    var isFullScreen = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        self.createUI()
        
        self.balanceLb.text = "$ 10,000"
        self.timeLb.text = "24 June 2016 09:45:00 +02:00"
        
        self.userBtn.options = ["12345678","87654321"]
        self.periodBtn.options = ["1M - 80%","5M - 78%","30M - 75%"]
        self.indicatorBtn.options = ["BB","MACD","KD","SMA","RSI","EMA"]
    }
    
    // MARK: - Basic UI
    
    func createUI() {
        let backgroungImgView = UIImageView(image: UIImage(named: "landscape_background.png"))
        backgroungImgView.isUserInteractionEnabled = true
        self.view.addSubview(backgroungImgView)
        
        backgroungImgView.snp.makeConstraints { (make) in
            make.edges.equalTo(self.view)
        }
        
        self.createTopView()
        self.createChartView()
        self.createBottomView()
        self.createRightView()
        self.createTopRightView() 
        
        self.view.bringSubview(toFront: self.chartView)
        self.view.bringSubview(toFront: self.bottomView)
        
        self.createOptionTableViews()
        self.createMenuSlider()
    }
    
    func createTopView() {
        self.view.addSubview(self.topView)
        
        self.topView.snp.makeConstraints { (make) in
            make.left.equalTo(COMPUTE_LENGTH(27.0))
            make.width.equalTo(COMPUTE_LENGTH(1608.0))
            make.top.equalTo(COMPUTE_LENGTH(20.0))
            make.height.equalTo(COMPUTE_LENGTH(100.0))
        }
        
        let menuBtn = BaseBtn()
        menuBtn.setImage(UIImage(named: "menu.png"), for: .normal)
        menuBtn.imageEdgeInsets = UIEdgeInsetsMake(COMPUTE_LENGTH((100.0-38.0)/2.0), 0, COMPUTE_LENGTH((100.0-38.0)/2.0), COMPUTE_LENGTH(100.0-48.0))
        menuBtn.addTarget(self, action: #selector(showMenuSlider), for: .touchUpInside)
        self.topView.addSubview(menuBtn)
        
        menuBtn.snp.makeConstraints { (make) in
            make.left.top.height.equalTo(self.topView)
            make.width.equalTo(self.topView.snp.height)
        }
        
        let logoImgView = UIImageView(image: UIImage(named: "Starfish-Logo.png"))
        self.topView.addSubview(logoImgView)
        
        logoImgView.snp.makeConstraints { (make) in
            make.left.equalTo(menuBtn.snp.right).offset(COMPUTE_LENGTH(20.0))
            make.width.equalTo(COMPUTE_LENGTH(278.0))
            make.height.equalTo(COMPUTE_LENGTH(88.0))
            make.centerY.equalTo(self.topView)
        }
        
        self.userBtn.tagName = "userBtn"
        self.symbolBtn.tagName = "symbolBtn"
        self.periodBtn.tagName = "periodBtn"
        self.userBtn.addTarget(self, action: #selector(showOptionTableView(optionBtn:)), for: .touchUpInside)
        self.symbolBtn.addTarget(self, action: #selector(showOptionTableView(optionBtn:)), for: .touchUpInside)
        self.periodBtn.addTarget(self, action: #selector(showOptionTableView(optionBtn:)), for: .touchUpInside)
        self.topView.addSubview(self.userBtn)
        self.topView.addSubview(self.symbolBtn)
        self.topView.addSubview(self.periodBtn)
        
        self.userBtn.snp.makeConstraints { (make) in
            make.left.equalTo(logoImgView.snp.right).offset(COMPUTE_LENGTH(88.0))
            make.height.equalTo(COMPUTE_LENGTH(84.0))
            make.centerY.equalTo(self.topView)
        }
        
        self.symbolBtn.snp.makeConstraints { (make) in
            make.left.equalTo(self.userBtn.snp.right).offset(COMPUTE_LENGTH(40.0))
            make.width.height.centerY.equalTo(self.userBtn)
        }
        
        self.periodBtn.snp.makeConstraints { (make) in
            make.left.equalTo(self.symbolBtn.snp.right).offset(COMPUTE_LENGTH(40.0))
            make.width.height.centerY.equalTo(self.symbolBtn)
            make.right.equalTo(self.topView)
        }
    }
    
    func createChartView() {
        self.chartView.backgroundColor = UIColor(patternImage: UIImage(named: "chart_background.png")!)
        self.view.addSubview(self.chartView)
        
        self.chartView.snp.makeConstraints { (make) in
            make.left.right.equalTo(self.topView)
            make.top.equalTo(self.topView.snp.bottom).offset(5)
            make.bottom.equalTo(self.view).offset(-COMPUTE_LENGTH(140.0))
        }
        
        let values = ["M1","M5","M15","M30","H1","H4","D1","W1","MN",]
        self.timeframeView = TimeframeView(values: values, selectedValue: "M1")
        self.chartView.addSubview(self.timeframeView!)
        self.timeframeView?.snp.makeConstraints({ (make) in
            make.top.equalTo(COMPUTE_LENGTH(18.0))
            make.left.equalTo(COMPUTE_LENGTH(16.0))
            make.height.equalTo(COMPUTE_LENGTH(60.0))
            let btnWidth: CGFloat = CGFloat(values.count) * 130.0 + 60.0 * 2.0
            make.width.equalTo(COMPUTE_LENGTH(btnWidth)).priority(500)
            make.width.lessThanOrEqualTo(COMPUTE_LENGTH(1440.0)).priority(1000)
        })
        
        let expandBtn = BaseBtn()
        expandBtn.setImage(UIImage(named: "expand.png"), for: .normal)
        expandBtn.imageEdgeInsets = UIEdgeInsetsMake(COMPUTE_LENGTH(23.0),COMPUTE_LENGTH(23.0),COMPUTE_LENGTH(23.0),COMPUTE_LENGTH(23.0))
        expandBtn.addTarget(self, action: #selector(expandToFullScreen), for: .touchUpInside)
        self.chartView.addSubview(expandBtn)
        
        expandBtn.snp.makeConstraints({ (make) in
            make.top.right.equalTo(self.chartView)
            make.width.height.equalTo(COMPUTE_LENGTH(44.0 + 23.0 * 2))
        })
    }
    
    func createBottomView() {
        self.view.addSubview(self.bottomView)
        
        self.bottomView.snp.makeConstraints { (make) in
            make.left.right.equalTo(self.chartView)
            make.top.equalTo(self.chartView.snp.bottom).offset(COMPUTE_LENGTH(20.0))
            make.bottom.equalTo(self.view).offset(-COMPUTE_LENGTH(20.0))
        }
        
        self.indicatorBtn.turnAroundTheArrow()
        self.indicatorBtn.tagName = "indicatorBtn"
        self.indicatorBtn.addTarget(self, action: #selector(showOptionTableView(optionBtn:)), for: .touchUpInside)
        self.bottomView.addSubview(self.indicatorBtn)
        self.indicatorBtn.snp.makeConstraints { (make) in
            make.left.equalTo(0)
            make.width.equalTo(COMPUTE_LENGTH(150.0))
            make.height.equalTo(self.symbolBtn)
            make.centerY.equalTo(self.bottomView)
        }
        
        self.timeLb.textColor = kColorTimeframeNormal()
        self.timeLb.font = FONT_CUSTOM(8.0)
        self.bottomView.addSubview(self.timeLb)
        self.timeLb.snp.makeConstraints { (make) in
            make.left.equalTo(self.indicatorBtn.snp.right).offset(COMPUTE_LENGTH(20.0))
            make.centerY.equalTo(self.bottomView)
        }
        
        self.bottomView.addSubview(self.favouriteView)
        self.favouriteView.snp.makeConstraints { (make) in
            make.left.equalTo(self.timeLb.snp.right).offset(COMPUTE_LENGTH(100.0))
            make.height.equalTo(self.indicatorBtn)
            make.right.centerY.equalTo(self.bottomView)
        }
    }
    
    func createRightView() {
        self.view.addSubview(self.tradingRightView)
        self.tradingRightView.createRightTradingView()
        self.tradingRightView.delegate = self
        self.tradingRightView.snp.makeConstraints { (mack) in
            mack.top.equalTo(COMPUTE_LENGTH(140))
            mack.left.equalTo(self.view.snp.right).offset(COMPUTE_LENGTH(-552))
            mack.right.equalTo(self.view.snp.right).offset(COMPUTE_LENGTH(-27))
            mack.bottom.equalTo(self.view.snp.bottom).offset(-COMPUTE_LENGTH(22))
            
        }
    }
    
    func createTopRightView() {
        self.view.addSubview(self.topRightView)
        
        self.topRightView.snp.makeConstraints { (make) in
            make.top.bottom.equalTo(self.topView)
            make.left.right.equalTo(self.tradingRightView)
        }
        
        let balanceTextLb = UILabel()
        balanceTextLb.textColor = kColorBalanceText()
        balanceTextLb.font = FONT_CUSTOM(10.0)
        balanceTextLb.text = "Balance"
        self.topRightView.addSubview(balanceTextLb)
        balanceTextLb.snp.makeConstraints { (make) in
            make.left.top.equalTo(0)
            make.width.equalTo(COMPUTE_LENGTH(220.0))
        }
        
        self.balanceLb.font = FONT_CUSTOM(12.0)
        self.balanceLb.adjustsFontSizeToFitWidth = true
        self.balanceLb.textColor = kColorBalance()
        self.topRightView.addSubview(self.balanceLb)
        self.balanceLb.snp.makeConstraints { (make) in
            make.left.bottom.equalTo(self.topRightView)
            make.width.equalTo(balanceTextLb)
        }
        
        self.depositBtn.backImgNameNormal = "btnBorder_press"
        self.depositBtn.backImgNameSelected = "btnBorder_press"
        self.depositBtn.infoColor = kColorDeposit()
        self.depositBtn.tagName = "depositBtn"
        self.depositBtn.addTarget(self, action: #selector(goToDepositVC), for: .touchUpInside)
        self.topRightView.addSubview(self.depositBtn)
        self.depositBtn.snp.makeConstraints { (make) in
            make.left.equalTo(self.balanceLb.snp.right).offset(COMPUTE_LENGTH(20))
            make.right.equalTo(self.topRightView)
            make.height.equalTo(self.userBtn)
            make.centerY.equalTo(self.topRightView)
        }
    }
    
    func createMenuSlider() {
//        self.view.addSubview(self.menuSlider)
//        
//        menuSlider.snp.makeConstraints { (make) in
//            make.left.top.bottom.equalTo(self.view)
//            make.width.equalTo(0)
//        }
    }
    
    // MARK: - Other UI
    
    func createOptionTableViews() {
        self.userTableView = self.createOptionTableView(optionBtn: self.userBtn)
        self.periodTableView = self.createOptionTableView(optionBtn: self.periodBtn)
        self.indicatorTableView = self.createOptionTableView(optionBtn: self.indicatorBtn)
    }
    
    func createOptionTableView(optionBtn: OptionBtn) -> BaseTableView {
        let backImgView = UIImageView()
        let backImg = UIImage(named: "optionTV_background.png")
        backImgView.image = backImg?.resizableImage(withCapInsets: UIEdgeInsetsMake(20, 20, 20, 20), resizingMode: .stretch)
        backImgView.isHidden = true
        self.view.addSubview(backImgView)
        
        let optionTableView = BaseTableView()
        optionTableView.backgroundColor = .clear
        optionTableView.separatorStyle = .none
        optionTableView.dataSource = self
        optionTableView.delegate = self
        self.view.addSubview(optionTableView)
        
        optionTableView.register(UINib(nibName: "OptionCell", bundle: nil), forCellReuseIdentifier: "OptionCell")
        
        optionTableView.bigBackgroundImgView = backImgView
        
        backImgView.snp.makeConstraints { (make) in
            make.top.equalTo(optionTableView).offset(-COMPUTE_LENGTH(20.0))
            make.left.equalTo(optionTableView).offset(-COMPUTE_LENGTH(28.0))
            make.bottom.right.equalTo(optionTableView).offset(COMPUTE_LENGTH(25.0))
        }
        
        optionTableView.snp.makeConstraints { (make) in
            make.left.equalTo(optionBtn)
            make.height.equalTo(0)
            if optionBtn.tagName == "indicatorBtn" {
                make.bottom.equalTo(self.bottomView.snp.top)
                make.width.equalTo(optionBtn).multipliedBy(3.0)
            }else {
                make.top.equalTo(self.topView.snp.bottom)
                make.width.equalTo(optionBtn)
            }
        }
        return optionTableView
    }
    
    
    
    // MARK: - button function
    
    func showMenuSlider() {
        menuSlider.frame = CGRect(x: 0, y: 0, width: 300, height: self.view.height)
        menuSlider.delegate = self
        self.view.addSubview(menuSlider)
    }
    
    func showOptionTableView(optionBtn: OptionBtn) {
        if let selectedBtn = self.selectedOptionBtn {
            if selectedBtn != optionBtn {
                if selectedBtn.tagName == "symbolBtn" {
                    self.hidePickSymbolView()
                }else {
                    self.hideOptionsView(optionBtn: selectedBtn, optionTableView: self.selectedOptionTV!)
                }
            }
        }
        optionBtn.isOpen = !optionBtn.isOpen
        
        self.selectedOptionBtn = optionBtn
        switch optionBtn.tagName {
        case "userBtn":
            self.userTableView?.bigBackgroundImgView?.isHidden = false
            self.showoptionTableView(optionBtn: optionBtn, optionTableView: self.userTableView!)
            self.selectedOptionTV = self.userTableView
            break
        case "symbolBtn":
            self.selectedOptionTV = nil
            self.showPickSymbolView()
            break
        case "periodBtn":
            self.periodTableView?.bigBackgroundImgView?.isHidden = false
            self.showoptionTableView(optionBtn: optionBtn, optionTableView: self.periodTableView!)
            self.selectedOptionTV = self.periodTableView
            break
        case "indicatorBtn":
            self.indicatorTableView?.bigBackgroundImgView?.isHidden = false
            self.showoptionTableView(optionBtn: optionBtn, optionTableView: self.indicatorTableView!)
            self.selectedOptionTV = self.indicatorTableView
            break
        default:
            break
        }
        
        if optionBtn.isOpen == false {
            self.selectedOptionBtn = nil
            self.selectedOptionTV = nil
        }
    }
    
    func showoptionTableView(optionBtn: OptionBtn, optionTableView: BaseTableView) {
        if optionBtn.isOpen == false {
            DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 0.4) {
                if optionBtn.isOpen == false {
                    /// if status still false, hidden
                    optionTableView.bigBackgroundImgView?.isHidden = true
                }
            }
        }
        
        UIView.animate(withDuration: 0.5) { 
            optionTableView.snp.updateConstraints({ (make) in
                if optionBtn.isOpen {
                    let height = CGFloat(optionBtn.options.count) * 30.0 < COMPUTE_LENGTH(800.0) ? CGFloat(optionBtn.options.count) * 30.0 : COMPUTE_LENGTH(800.0)
                    make.height.equalTo(height)
                }else {
                    make.height.equalTo(0)
                }
            })
            self.view.layoutIfNeeded()
        }
    }
    
    func showPickSymbolView() {
        if self.pickSymbolVC.view.superview == nil {
            self.addChildViewController(self.pickSymbolVC)
            self.view.addSubview(self.pickSymbolVC.view)
            
            self.pickSymbolVC.view.snp.makeConstraints({ (make) in
                make.centerX.equalTo(self.symbolBtn)
                make.top.equalTo(self.topView.snp.bottom)
                make.width.equalTo(COMPUTE_LENGTH(1000.0))
                make.height.equalTo(COMPUTE_LENGTH(800.0 ))
            })
            
            self.pickSymbolVC.view.isHidden = true
        }
        
        if self.pickSymbolVC.view.isHidden {
            self.pickSymbolVC.showInParentVC()
        }else {
            self.hidePickSymbolView()
        }
    }
    
    func expandToFullScreen() {
        self.isFullScreen = !self.isFullScreen
        
        if self.isFullScreen == true {
            self.hideAllPopUpViews()
            
            UIView.animate(withDuration: 1.5) {
                self.chartView.snp.remakeConstraints({ (make) in
                    make.left.equalTo(self.topView)
                    make.top.right.equalTo(self.topRightView)
                    make.bottom.equalTo(self.view).offset(-COMPUTE_LENGTH(140.0))
                })
                
//                self.tradingRightView.snp.remakeConstraints { (make) in
//                    make.left.equalTo(self.topView.snp.right).offset(COMPUTE_LENGTH(30.0))
//                    make.right.equalTo(self.view).offset(-COMPUTE_LENGTH(27.0))
//                    make.top.equalTo(self.topView.snp.bottom).offset(5)
//                    make.bottom.equalTo(self.chartView)
//                }
                
                self.topView.alpha = 0
                self.topRightView.alpha = 0
                self.tradingRightView.alpha = 0
                
                self.view.layoutIfNeeded()
            }
        }else {
            UIView.animate(withDuration: 1.5) {
                self.chartView.snp.remakeConstraints { (make) in
                    make.left.right.equalTo(self.topView)
                    make.top.equalTo(self.topView.snp.bottom).offset(5)
                    make.bottom.equalTo(self.view).offset(-COMPUTE_LENGTH(140.0))
                }
                
//                self.tradingRightView.snp.remakeConstraints { (make) in
//                    make.left.equalTo(self.topView.snp.right).offset(COMPUTE_LENGTH(30.0))
//                    make.right.equalTo(self.view).offset(-COMPUTE_LENGTH(27.0))
//                    make.top.equalTo(self.topView.snp.bottom).offset(5)
//                    make.bottom.equalTo(self.bottomView)
//                }
                
                self.topView.alpha = 1.0
                self.topRightView.alpha = 1.0
                self.tradingRightView.alpha = 1.0
                
                self.view.layoutIfNeeded()
            }
        }
    }
    
    func goToDepositVC() {
        let vc = DepositeViewController()
        let navi = BaseNavigationController(rootViewController: vc)
        navi.navigationBar.isTranslucent = false
        navi.isNavigationBarHidden = true
        self.present(navi, animated: true, completion: nil)
    }
    
    // MARK: - Hide PopUp Views
    
    func hideAllPopUpViews() {
        self.hidePickSymbolView()
        self.hideOptionsView(optionBtn: self.userBtn, optionTableView: self.userTableView!)
        self.hideOptionsView(optionBtn: self.periodBtn, optionTableView: self.periodTableView!)
        self.hideOptionsView(optionBtn: self.indicatorBtn, optionTableView: self.indicatorTableView!)
    }
    
    func hideOptionsView(optionBtn: OptionBtn, optionTableView: BaseTableView) {
        optionBtn.isOpen = false
        self.showoptionTableView(optionBtn: optionBtn, optionTableView: optionTableView)
    }
    
    func hidePickSymbolView() {
        self.pickSymbolVC.hideInParentVC()
    }
    
    // MARK: - OptionCellDelegate
    
    func showIndicatorSettingView(indicatorType: IndicatorType) {
        let alertView = IndicatorAlertView(indicatorType: .BOLL, title: "123321132", btnTitles: ["Reset","Confirm"])
        self.showAlertVC(alertView: alertView)
    }
    
    // MARK: - TimeframeViewDelegate
    
    func didChangeTimeframe(timeframe: String, lastTimeframe: String) {
        
    }
    
    
    
    // MARK: - LeftMenuTableViewDelegate
    
    func leftMenuTabledidSelectRow(atIndexPath indexpath: Int , withNextViewController:String) {
        switch indexpath {
        case 1:
            let vc = AccountManagementController()
            vc.selectedIntValue = indexpath
            let navi = BaseNavigationController(rootViewController: vc)
            navi.navigationBar.isTranslucent = false
            navi.isNavigationBarHidden = true
            self.present(navi, animated: true, completion: nil)
            break
        case 2:
            let vc = AccountManagementController()
            vc.selectedIntValue = indexpath
            vc.selectedIntValue = indexpath
            let navi = BaseNavigationController(rootViewController: vc)
            navi.navigationBar.isTranslucent = false
            navi.isNavigationBarHidden = true
            self.present(navi, animated: true, completion: nil)
            break
        case 3:
            let vc = AccountManagementController()
            vc.selectedIntValue = indexpath
            let navi = BaseNavigationController(rootViewController: vc)
            navi.navigationBar.isTranslucent = false
            navi.isNavigationBarHidden = true
            self.present(navi, animated: true, completion: nil)
            break
        case 5:
            let vc = DepositeViewController()
            let navi = BaseNavigationController(rootViewController: vc)
            navi.navigationBar.isTranslucent = false
            navi.isNavigationBarHidden = true
            self.present(navi, animated: true, completion: nil)
            break
        case 6:
            let vc = WithDrawalViewController()
            let navi = BaseNavigationController(rootViewController: vc)
            navi.navigationBar.isTranslucent = false
            navi.isNavigationBarHidden = true
            self.present(navi, animated: true, completion: nil)
//            self.navigationController?.pushViewController(WithDrawalViewController(), animated: true)
            break
        case 7:
            let vc = TradingHistroyVC()
            let navi = BaseNavigationController(rootViewController: vc)
            navi.navigationBar.isTranslucent = false
            navi.isNavigationBarHidden = true
            self.present(navi, animated: true, completion: nil)
            break
        case 8:
            let vc = SettingsVC()
            let navi = BaseNavigationController(rootViewController: vc)
            navi.navigationBar.isTranslucent = false
            navi.isNavigationBarHidden = true
            self.present(navi, animated: true, completion: nil)
            break
        case 9:
            let vc = FeedbackVC()
            let navi = BaseNavigationController(rootViewController: vc)
            navi.navigationBar.isTranslucent = false
            navi.isNavigationBarHidden = true
            self.present(navi, animated: true, completion: nil)
             break
           
           case 10:
//            let vc = AboutUsVC()
//            let navi = BaseNavigationController(rootViewController: vc)
//            self.present(navi, animated: true, completion: nil)
            break
        case 11:
            let vc = ViewController()
            let navi = BaseNavigationController(rootViewController: vc)
            navi.navigationBar.isTranslucent = false
            navi.isNavigationBarHidden = true
            self.present(navi, animated: true, completion: nil)
            break
        default:
            break
        }
    }
    
    func leftMenuTapGestureCalled() {
        UIView.beginAnimations(nil, context: nil)
        UIView.setAnimationDuration(0.3)
        menuSlider.frame = CGRect(x: CGFloat(-SCREEN_WIDTH()), y: CGFloat(44), width: CGFloat(SCREEN_WIDTH()), height: CGFloat(SCREEN_HEIGHT() - 44))
        UIView.commitAnimations()
}
    
    
    // MARK: - UITableViewDataSource,UITableViewDelegate
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch tableView {
        case self.userTableView!:
            return self.userBtn.options.count
        case self.periodTableView!:
            return self.periodBtn.options.count
        case self.indicatorTableView!:
            return self.indicatorBtn.options.count
        default:
            break
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: OptionCell = tableView.dequeueReusableCell(withIdentifier: "OptionCell", for: indexPath) as! OptionCell
        
        var infos = self.userBtn.options
        cell.isShowSetting = false
        switch tableView {
        case self.periodTableView!:
            infos = self.periodBtn.options
        case self.indicatorTableView!:
            infos = self.indicatorBtn.options
            cell.isShowSetting = true
        default:
            break
        }
        
        cell.info = infos[indexPath.row]
        cell.isTickedOn = arc4random() % 2 > 0 ? true : false
        cell.delegate = self
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 30.0
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        
        let cell = tableView.cellForRow(at: indexPath) as! OptionCell
        if tableView == self.indicatorTableView {
            cell.isTickedOn = !cell.isTickedOn
        }else {
            cell.isTickedOn = true
        }
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
    
    // MARK: - NumberPadViewDelegate  数字键盘的弹出视图类
    func toViewControllerImplementationMethods() {
        print("控制器执行代理的方法执行")
        
        createPopNumberPadView()
    }

    func createPopNumberPadView() {
        if numberPadVeiw.isHidden == true {
            numberPadVeiw.isHidden = false
        }
        numberPadVeiw.frame = CGRect(x: 0.0, y: 0.0, width: COMPUTE_LENGTH(538), height: SCREEN_HEIGHT())
        
        numberPadVeiw.delegate = self
        numberPadVeiw.createContentView()
        self.view.addSubview(numberPadVeiw)
    }
    
    func closeNumberPadView() {   // 关闭键盘的视图
        numberPadVeiw.isHidden = true
    }
    
    // MARK: - OpenPositionViewDelegate   正在进行中的交易类
    
    func transactionToViewController() {
        //  hide self.tradingRightView
        self.tradingRightView.isHidden = true
        
        if openPositionsView.isHidden == true {
            openPositionsView.isHidden = false
            
        }else{
            openPositionsView.createUI()
            openPositionsView.delegate = self
            self.view.addSubview(openPositionsView)
            openPositionsView.snp.makeConstraints { (mack) in
                mack.top.left.width.height.equalTo(self.tradingRightView)
            }
        }
    }
    
    func closeTableView() {   // close The ongoing trading
        //  dishide self.tradingRightView
        self.tradingRightView.isHidden = false
        openPositionsView.isHidden = true
    }
    
     // MARK: - ClosePositionsViewDelegate     已经关闭的交易类
    
    func openToClosePosiTableViewCell() {
        //  hide self.tradingRightView
        self.tradingRightView.isHidden = true
        
        if closepositionsView.isHidden == true {
            closepositionsView.isHidden = false
        }else{
            closepositionsView.createUI()
            closepositionsView.delegate = self
            self.view.addSubview(closepositionsView)
            closepositionsView.snp.makeConstraints { (mack) in
                mack.top.left.width.height.equalTo(self.tradingRightView)
            }
        }
    }
    
    func closeClosePositionsViewTableView() {
        
        //  Dishide self.tradingRightView
        self.tradingRightView.isHidden = false
        closepositionsView.isHidden = true
    }
    
    func createPushTradingHistroy() {
        self.tradingHistroyVC  = TradingHistroyVC.init()
        
        self.navigationController?.pushViewController(self.tradingHistroyVC, animated: true)
        
    }
    
     // MARK: - NumberPadViewDelegate     键盘的代理方法
    func changeValue(compassPoint: CompassPoint, number: Int) {
        
        print(number)
        self.tradingRightView.changeInvestmentAmount(compassPoint:compassPoint, number: number)
    }
    
    
     // MARK: - TradingParticularsViewDelegate 交易详情
    
    func createTradingParticularsView(titleLb: String, profit profitLb: String){
        
        self.tradingParticularsView.removeFromSuperview()
        
        self.tradingParticularsView.createUI()
        
        self.tradingParticularsView.breedLb.text = titleLb
        self.tradingParticularsView.earningsLb.text = profitLb
        self.tradingParticularsView.delegate = self
        self.tradingParticularsView.frame = CGRect.init(x: COMPUTE_LENGTH(500), y: COMPUTE_LENGTH(300), width: COMPUTE_LENGTH(939), height: COMPUTE_LENGTH(584))
        self.view.addSubview(self.tradingParticularsView)
    
    }
    
    func closeTradingParticularsView(){
        self.tradingParticularsView.removeFromSuperview()
    }
    
    // MARK: - Device Orientation
    
    override var shouldAutorotate: Bool {
        return true
    }
    
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return .landscape
    }
    
    // MARK: - Other
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        numberPadVeiw.removeFromSuperview()
        
    }
    
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}
