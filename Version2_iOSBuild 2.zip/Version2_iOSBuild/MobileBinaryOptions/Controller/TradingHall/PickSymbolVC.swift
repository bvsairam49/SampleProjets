//
//  PickSymbolVC.swift
//  MobileBinaryOptions
//
//  Created by GE on 17/2/4.
//  Copyright © 2017年 Broctagon. All rights reserved.
//

import UIKit

class PickSymbolVC: BaseVC, UITableViewDataSource, UITableViewDelegate,UITextFieldDelegate, SymbolCellDelegate{

    let searchImgView = UIImageView()
    let searchTF = UITextField()
    let searchBtn = UIButton()  /// magnifying glass or cancel
    
    let groupBackView = UIView()
    var groupNames = Array<String>()
    var groupBtns = Array<BaseBtn>()
    var selectedBtn = BaseBtn()
    
    let separateLine = UIImageView()
    let tableView = UITableView()
    
    var allModels = Array<SymbolModel>()  /// all models, using when show search data
    var favouriteModels = Array<SymbolModel>()  /// record the favourite models
    
    var showModels = Array<SymbolModel>()   /// data source for tableView
    var filterModels = Array<SymbolModel>() /// data source after filter
    
    var allModelGroups = Array<Array<SymbolModel>>()
    
    var isShowSearchView = false
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.view.backgroundColor = .green
        
        self.setupSymbolModels()
        self.createUI()
    }
    
    // MARK: - setup data
    
    func setupSymbolModels() {
        self.groupNames = ["Forex","Index","Favorites"]
        
        let indexModels = self.convertToSymbolModels(symbols: ["Index0","Index1","Index2","Index3","Index4"])
        let forexModels = self.convertToSymbolModels(symbols: ["Forex0","Forex1","Forex2","Forex3","Forex4","Forex5","Forex6","Forex7","Forex8","Forex9"])
        
        self.allModelGroups.append(indexModels)
        self.allModelGroups.append(forexModels)
        self.allModelGroups.append(self.favouriteModels)
        self.showModels = indexModels
    }
    
    func convertToSymbolModels(symbols: Array<String>) -> Array<SymbolModel> {
        var models = Array<SymbolModel>()
        for symbol in symbols {
            let model = SymbolModel()
            model.name = symbol
            model.isStar = arc4random() % 2 > 0 ? true : false
            
            models.append(model)
            self.allModels.append(model)
            
            if model.isStar {
                self.favouriteModels.append(model)
            }
        }
        return models
    }
    
    // MARK: - createUI
    
    func createUI() {
        self.view.backgroundColor = .clear
        self.view.showCorner(5.0)
        
        let backImgView = UIImageView()
        backImgView.image = UIImage(named: "landscape_background.png")
        self.view.addSubview(backImgView)
        
        backImgView.snp.makeConstraints { (make) in
            make.left.top.equalTo(self.view)
            make.width.equalTo(COMPUTE_LENGTH(1000.0))
            make.height.equalTo(COMPUTE_LENGTH(800.0))
        }
        
        self.searchImgView.isUserInteractionEnabled = true
        self.searchImgView.showCorner(15.0)
        self.searchImgView.image = UIImage(named: "searchBar_background.png")
        self.view.addSubview(self.searchImgView)
        self.searchImgView.snp.makeConstraints { (make) in
            make.left.equalTo(COMPUTE_LENGTH(28.0))
            make.right.equalTo(backImgView).offset(-COMPUTE_LENGTH(28.0))
            make.top.equalTo(COMPUTE_LENGTH(23.0))
            make.height.equalTo(25.0)
        }
        
        self.createSubviewsInSearchImgView()
        
        self.view.addSubview(self.groupBackView)
        self.groupBackView.snp.makeConstraints { (make) in
            make.left.right.equalTo(backImgView)
            make.top.equalTo(self.searchImgView.snp.bottom)
            make.height.equalTo(25.0+20.0)
        }
        
        var normalBorderImg = UIImage(named: "btnBorder_normal.png")
        normalBorderImg = normalBorderImg?.resizableImage(withCapInsets: UIEdgeInsetsMake(0, (normalBorderImg?.size.width)!/462.0*40, 0, (normalBorderImg?.size.width)!/462.0*40), resizingMode: .stretch)
        var selectedBorderImg = UIImage(named: "btnBorder_press.png")
        selectedBorderImg = selectedBorderImg?.resizableImage(withCapInsets: UIEdgeInsetsMake(0, (selectedBorderImg?.size.width)!/462.0*40, 0, (selectedBorderImg?.size.width)!/462.0*40), resizingMode: .stretch)
        
        var lastBtn = BaseBtn()
        for i in 0..<self.groupNames.count {
            let groupBtn = BaseBtn()
            groupBtn.setBackgroundImage(normalBorderImg, for: .normal)
            groupBtn.setBackgroundImage(selectedBorderImg, for: .selected)
            groupBtn.setTitleColor(kColorTimeframeNormal(), for: .normal)
            groupBtn.setTitleColor(kColorTimeframeSelected(), for: .selected)
            groupBtn.titleLabel?.font = FONT_CUSTOM(10.0)
            groupBtn.setTitle(self.groupNames[i], for: .normal)
            groupBtn.tagName = self.groupNames[i]
            groupBtn.tag = i
            groupBtn.addTarget(self, action: #selector(selectGroup(groupBtn:)), for: .touchUpInside)
            self.groupBackView.addSubview(groupBtn)
            
            groupBtn.snp.makeConstraints({ (make) in
                make.top.equalTo(self.groupBackView).offset(10)
                make.bottom.equalTo(self.groupBackView).offset(-10)
                
                if i == 0 {
                    make.left.equalTo(COMPUTE_LENGTH(70.0))
                }else {
                    make.left.equalTo(lastBtn.snp.right).offset(COMPUTE_LENGTH(81.0))
                    make.width.equalTo(lastBtn)
                    
                    if i == self.groupNames.count - 1 {
                        make.right.equalTo(self.groupBackView).offset(-COMPUTE_LENGTH(70.0))
                    }
                }
            })
            
            if i == 0 {
                groupBtn.isSelected = true
                self.selectedBtn = groupBtn
            }
            
            self.groupBtns.append(groupBtn)
            lastBtn = groupBtn
        }
        
        self.separateLine.image = UIImage(named: "line.png")
        self.view.addSubview(self.separateLine)

        self.separateLine.snp.makeConstraints { (make) in
            make.left.right.equalTo(self.searchImgView)
            make.top.equalTo(self.groupBackView.snp.bottom)
            make.height.equalTo(2)
        }
        
        self.tableView.backgroundColor = .clear
        self.tableView.dataSource = self
        self.tableView.delegate = self
        self.view.addSubview(self.tableView)
        self.tableView.register(UINib(nibName: "SymbolCell", bundle: nil), forCellReuseIdentifier: "SymbolCell")
        
        self.tableView.snp.makeConstraints { (make) in
            make.left.right.equalTo(self.groupBackView)
            make.top.equalTo(self.separateLine.snp.bottom)
            make.bottom.equalTo(backImgView)
        }
    }
    
    func createSubviewsInSearchImgView() {
        self.searchTF.placeholder = LString(key: "Search")
        self.searchTF.tintColor = kColorTimeframeNormal()
        self.searchTF.textColor = kColorTimeframeNormal()
        self.searchTF.font = FONT_CUSTOM(13.0)
        self.searchTF.delegate = self
        self.searchImgView.addSubview(self.searchTF)
        
        self.searchBtn.setImage(UIImage(named: "search_icon.png"), for: .normal)
        self.searchImgView.addSubview(self.searchBtn)
        
        self.searchTF.snp.makeConstraints { (make) in
            make.top.bottom.equalTo(self.searchImgView)
            make.left.equalTo(15.0)
            make.right.equalTo(self.searchBtn.snp.left).offset(-5)
        }
        
        self.searchBtn.snp.makeConstraints { (make) in
            make.width.height.equalTo(COMPUTE_LENGTH(40.0))
            make.right.equalTo(self.searchImgView).offset(-10.0)
            make.centerY.equalTo(self.searchImgView)
        }
    }
    
    func selectGroup(groupBtn: BaseBtn) {
        self.selectedBtn.isSelected = false
        self.selectedBtn = groupBtn
        self.selectedBtn.isSelected = true
        
        self.showModels.removeAll()
        self.showModels = self.allModelGroups[groupBtn.tag]
        self.tableView.reloadData()
    }
    
    // MARK: - show or hide in ParentVC
    
    func showInParentVC() {
        self.view.isHidden = false
    }
    
    func hideInParentVC() {
        self.cancelSearchStatus()
        self.view.isHidden = true
    }
    
    // MARK: - SymbolCellDelegate
    
    func starSymbol(symbolModel: SymbolModel) {
        if symbolModel.isStar {
            self.favouriteModels.append(symbolModel)
        }else {
//            let index = self.favouriteModels.index(of: symbolModel)
//            self.favouriteModels.remove(at: index!)
            
            for model in self.favouriteModels {
                if model.name == symbolModel.name {
                    let index = self.favouriteModels.index(of: model)
                    self.favouriteModels.remove(at: index!)
                    break
                }
            }
        }
    }
    
    // MARK: - UIScrollViewDelegate
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        self.searchTF.resignFirstResponder()
    }
    
    // MARK: - UITableViewDataSource,UITableViewDelegate
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.showModels.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: SymbolCell = tableView.dequeueReusableCell(withIdentifier: "SymbolCell", for: indexPath) as! SymbolCell
        cell.symbolModel = self.showModels[indexPath.row]
        cell.delegate = self
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 30.0
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        
        if self.isShowSearchView {
            self.cancelSearchStatus()
        }
        
    }
    
    // MARK: - UITextFieldDelegate
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        // if user scroll tableView, will resign keyboard but isShowSearchView won't be changed
        if self.isShowSearchView == false {
            self.showModels = self.allModels
            self.groupBackView.isHidden = true
            self.separateLine.snp.remakeConstraints { (make) in
                make.left.right.equalTo(self.searchImgView)
                make.top.equalTo(self.searchImgView.snp.bottom).offset(10)
                make.height.equalTo(2)
            }
            self.tableView.reloadData()
        }
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        var newValue = textField.text!
        /// range.length == 0 means add character, otherwise means minus characters
        if range.length == 0 {
            newValue += string
        }else {
            let newMStr = NSMutableString(string: newValue)
            newMStr.deleteCharacters(in: range)
            newValue = newMStr as String
        }
        
        if newValue.lengthOfBytes(using: .utf8) == 0 {
            self.filterModels = self.allModels
        }else {
            let predicate = NSPredicate(format: "SELF CONTAINS[cd] %@", newValue)
            self.showModels = self.allModels.filter({ (symbolModel) -> Bool in
                return predicate.evaluate(with: symbolModel.name)
            })
        }
        
        self.tableView.reloadData()
        print(newValue + "\ntext: \(textField.text)" + "\nstring:" + string)
        
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        
    }

    // MARK: - cancel search status, resign keyboard
    
    func cancelSearchStatus() {
        self.isShowSearchView = false
        self.searchTF.resignFirstResponder()
        self.groupBackView.isHidden = false
        self.showModels = self.allModelGroups[self.selectedBtn.tag]
        self.tableView.reloadData()
        
        self.separateLine.snp.remakeConstraints { (make) in
            make.left.right.equalTo(self.searchImgView)
            make.top.equalTo(self.groupBackView.snp.bottom)
            make.height.equalTo(2)
        }

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
