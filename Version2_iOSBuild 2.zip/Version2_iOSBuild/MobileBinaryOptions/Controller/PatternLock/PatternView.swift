//
//  PatternView.swift
//  landscape
//
//  Created by GE on 17/2/7.
//  Copyright © 2017年 pc003. All rights reserved.
//

import UIKit

fileprivate let kBorderLineWidth: CGFloat = 2.0
fileprivate let kBorderCircleRadius: CGFloat = 35.0
fileprivate let kInnerCircleRadius: CGFloat = 10.0

let kNodeNormalColor   = UIColor(red: 241.0 / 255.0, green: 241.0 / 255.0, blue: 241.0 / 255.0, alpha: 0.7)
let kNodeSelectedColor = UIColor(red: 249.0 / 255.0, green: 199.0 / 255.0, blue: 81.0 / 255.0, alpha: 1.0)
let kNodeWarningColor  = UIColor(red: 254.0 / 255.0, green: 82.0 / 255.0, blue: 92.0 / 255.0, alpha: 1.0)

enum NodeStatus : Int {
    case normal
    case selected
    case warning
    
    func nodeColor() -> UIColor {
        switch self {
            case .normal:   return kNodeNormalColor
            case .selected: return kNodeSelectedColor
            case .warning:  return kNodeWarningColor
        }
    }
}

protocol PatternViewDelegate : NSObjectProtocol {
    func patternEnded(patternStr: String, showError: () -> Void)
}

class PatternView: UIView {
    
    var allNodes = Array<PatternNode>()
    var normalNodes = Array<PatternNode>()
    var selectedNodes = Array<PatternNode>()

    var linkLineColor = kNodeSelectedColor
    var selectedPoints = Array<CGPoint>()   /// selected nodes' center point
    var lastPoint: CGPoint? /// if last point is a selected point, lastPoint = nil, otherwise, record the touch point
    
    var isClean = true  /// false when touches end, tue when new touch begin
    
    weak var delegate :PatternViewDelegate?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.createUI()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func createUI() {
        self.backgroundColor = .clear
        
        let miniLength = min(self.width, self.height)
        let space = (miniLength - kBorderCircleRadius*2*3) / 2.0    /// between two nodes
        let originOffset = kBorderCircleRadius * 2 + space  /// x&y offset between the border upon nodes
        for i in 0..<9 {
            let left: CGFloat = originOffset * CGFloat(i % 3)
            let top: CGFloat = originOffset * CGFloat(i / 3)
            
            let node = PatternNode(frame: CGRect(x: left, y: top, width: kBorderCircleRadius * 2, height: kBorderCircleRadius * 2))
            node.backgroundColor = .clear
            node.tag = i
            self.addSubview(node)
            
            allNodes.append(node)
            normalNodes.append(node)
        }
    }
    
    override func draw(_ rect: CGRect) {
        // Drawing code
        
        if self.selectedPoints.count == 0 {
            return
        }
        
        let linePath = UIBezierPath()
        
        for i in 0..<self.selectedPoints.count {
            let point = self.selectedPoints[i]
            if i == 0 {
                linePath.move(to: point)
            }else {
                linePath.addLine(to: point)
            }
        }
        
        if let point = self.lastPoint {
            linePath.addLine(to: point)
        }
        
        linePath.lineWidth = kBorderLineWidth
        self.linkLineColor.setStroke()
        linePath.stroke()
    }
    
    // MARK: - touches event
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.resetPattern()
        self.touchesChanged(touches, isEnded: false)
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.touchesChanged(touches, isEnded: false)
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.touchesChanged(touches, isEnded: true)
        self.isClean = false
        
        var patternStr = ""
        for node in self.selectedNodes {
            patternStr.append("\(node.tag)")
        }
        
        self.delegate?.patternEnded(patternStr: patternStr, showError: {
            self.linkLineColor = kNodeWarningColor
            self.setNeedsDisplay()
            
            for node in self.selectedNodes {
                node.status = .warning
            }
        })
        
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 1.0) {
            [weak self] in
            if let strongSelf = self {
                strongSelf.resetPattern()
                strongSelf.setNeedsDisplay()
            }
        }
    }
    
    /// invoke when any touch event happen
    func touchesChanged(_ touches: Set<UITouch>, isEnded: Bool) {
        let point = (touches.first?.location(in: self))!
        
        var meetNode = isEnded    /// judge if the meet a normal node or not
        
        /// if the point is a point in normal Nodes, select it
        for node in self.normalNodes {
            if node.frame.contains(point) {
                node.status = .selected
                
                self.selectedNodes.append(node)
                self.selectedPoints.append(node.center)
                if let index = normalNodes.index(of: node) {
                    normalNodes.remove(at: index)
                }
                meetNode = true
                break
            }
        }
        
        if meetNode == true {
            self.lastPoint = nil
        }else {
            self.lastPoint = point
        }
        
        self.setNeedsDisplay()
    }
    
    func resetPattern() {
        /// like @synchronized(self) {} in OC
        objc_sync_enter(self)
        
        if self.isClean == false {
            for node in self.selectedNodes {
                node.status = .normal
            }
            
            self.normalNodes = self.allNodes
            self.selectedNodes.removeAll()
            self.selectedPoints.removeAll()
            
            self.linkLineColor = kNodeSelectedColor
            self.isClean = true
        }
        
        objc_sync_exit(self)
    }
}

class PatternNode: UIView {
    
    var _status = NodeStatus.normal
    var status: NodeStatus {
        get {
            return _status
        }
        set(newValue) {
            _status = newValue
            self.setNeedsDisplay()
        }
    }
    
    override func draw(_ rect: CGRect) {
        // Drawing code
        
        let borderCirclePath = UIBezierPath(ovalIn: CGRect(x: kBorderLineWidth, y: kBorderLineWidth, width: self.width - kBorderLineWidth*2.0, height: self.height - kBorderLineWidth*2.0))
        borderCirclePath.lineWidth = kBorderLineWidth
        self.status.nodeColor().setStroke()
        borderCirclePath.stroke()
        
        let innerCirclePath = UIBezierPath(ovalIn: CGRect(x: kBorderCircleRadius - kInnerCircleRadius, y: kBorderCircleRadius - kInnerCircleRadius, width: kInnerCircleRadius * 2.0, height: kInnerCircleRadius * 2.0))
        self.status.nodeColor().setFill()
        innerCirclePath.fill()
    }
}
