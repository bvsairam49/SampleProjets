//
//  PatternLockVC.swift
//  landscape
//
//  Created by GE on 17/2/7.
//  Copyright © 2017年 pc003. All rights reserved.
//

import UIKit

let kAllowedPatternToUnlock = "kAllowedPatternToUnlock"

fileprivate let kMainTitleColor = UIColor(red: 255.0 / 255.0, green: 255.0 / 255.0, blue: 255.0 / 255.0, alpha: 0.3)
fileprivate let kSubtitleColor = UIColor(red: 255.0 / 255.0, green: 255.0 / 255.0, blue: 255.0 / 255.0, alpha: 0.3)
fileprivate let kReminderTitleColor = UIColor(red: 255.0 / 255.0, green: 255.0 / 255.0, blue: 255.0 / 255.0, alpha: 0.3)
fileprivate let kInfoColor = UIColor(red: 255.0 / 255.0, green: 255.0 / 255.0, blue: 255.0 / 255.0, alpha: 0.3)
fileprivate let kSmallNodeNormalColor = UIColor.gray
fileprivate let kSmallNodeSelectedColor = kNodeWarningColor

func kPatternPassword() -> String {
    let uesr = "crmEmail"
    return "kPatternLock_\(uesr)"
}

enum PatternLockType : Int {
    case setting
    case verify
    case modify
    case cancel
    
    func title() -> String {
        switch self {
            case .setting: return LString(key: "Pattern Setting")
            case .verify: return LString(key: "Verify Pattern")
            case .modify: return LString(key: "Modify Pattern")
            case .cancel: return LString(key: "Cancel Pattern")
        }
    }
}

protocol PatternLockVCDelegate : NSObjectProtocol {
    func didPatternSettingSucceed()
    func didPatternVerifySucceed()
    func patternErrorTooManyTimes() // error count > allowedErrorCount, invoke it
}

class PatternLockVC: UIViewController, PatternViewDelegate {
    
    let backBtn = UIButton()
    let titleLb = UILabel()
    let subtitleLb = UILabel()
    let smallPatternView = UIView()
    var smallNodes = Array<UIView>() /// nodes in smallPatternView
    let infoLb = UILabel()  /// label above reminderLb, shows info(e.g. username)
    var patternView: PatternView!
    
    let reminderLb = UILabel()
    var resetBtn: UIButton!
    var forgetPwdBtn: UIButton!
    
    var type = PatternLockType.setting
    
    var patternStr: String?  /// user password or record the setting password first time
    var minimumCount = 4       /// the minimum length of pattern nodes
    var allowedErrorCount = 5
    
    weak var delegate :PatternLockVCDelegate?
    
    required init(type: PatternLockType) {
        super.init(nibName: nil, bundle: nil)
        self.type = type
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        
        ///  viewDidLoad be invoked before supportedInterfaceOrientations
        ///  and the SCREEN_WIDTH() incorrect, so createUI here
        
        self.createUI()
        self.setupData()
        
        self.reminderLb.text = "pattern"
        
    }
    
    func setupData() {
        self.titleLb.text = self.type.title()
//        if let savedPatternStr = UserDefaults.standard.object(forKey: kPatternPassword()) {
//            self.patternStr = savedPatternStr as? String
//        }
        self.patternStr = UserDefaults.standard.object(forKey: kPatternPassword()) as? String
        
        switch self.type {
        case .setting:
            self.subtitleLb.text = LString(key: "Draw your pattern")
            break
        default:
            self.subtitleLb.text = LString(key: "userName")
            break
        }
    }
    
    func createUI() {
        self.view.backgroundColor = UIColor(patternImage: UIImage(named: "pattern_background.png")!)
        
        self.backBtn.frame = CGRect(x: 16, y: 16, width: 30, height: 30)
        self.backBtn.setImage(UIImage(named: "back_icon"), for: .normal)
        self.backBtn.addTarget(self, action: #selector(clickBackBtn), for: .touchUpInside)
        self.view.addSubview(self.backBtn)
        
        self.titleLb.frame = CGRect(x: 0, y: self.backBtn.bottom+10, width: SCREEN_WIDTH(), height: 30)
        self.titleLb.textAlignment = .center
        self.titleLb.textColor = kMainTitleColor
        self.titleLb.font = FONT_CUSTOM(25.0)
        self.view.addSubview(self.titleLb)
        
        self.subtitleLb.frame = CGRect(x: 0, y: self.titleLb.bottom+15, width: SCREEN_WIDTH(), height: 20)
        self.subtitleLb.textAlignment = .center
        self.subtitleLb.textColor = kSubtitleColor
        self.subtitleLb.font = FONT_CUSTOM(15.0)
        self.view.addSubview(self.subtitleLb)
        
        self.patternView = PatternView(frame: CGRect(x: 25.0, y: 0, width: SCREEN_WIDTH() - 50.0, height: SCREEN_WIDTH() - 50.0))
        self.patternView.bottom = SCREEN_HEIGHT() - 60.0
        self.patternView.delegate = self
        self.view.addSubview(self.patternView)
        
        self.createReminderLb()
        
        if self.type == .setting {
            self.createSmallPatternView()
            self.createResetBtn()
        }else if self.type == .cancel {
            self.createForgetPwdBtn()
        }
    }
    
    func createSmallPatternView() {
        self.smallPatternView.frame = CGRect(x: 0, y: self.subtitleLb.bottom+10, width: 60, height: 60)
        self.smallPatternView.centerX = SCREEN_WIDTH() / 2.0
        self.view.addSubview(self.smallPatternView)
        
        self.createSubviewInSmallPatternView(length: self.smallPatternView.width)
    }
    
    func createSubviewInSmallPatternView(length: CGFloat) {
        let btnRadius: CGFloat = 8.0
        let space = (length - btnRadius*2*3) / 2.0    /// between two nodes
        let originOffset = btnRadius * 2 + space  /// x&y offset between the border upon nodes
        for i in 0..<9 {
            let left: CGFloat = originOffset * CGFloat(i % 3)
            let top: CGFloat = originOffset * CGFloat(i / 3)
            
            let node = UIView(frame: CGRect(x: left, y: top, width: btnRadius * 2, height: btnRadius * 2))
            node.backgroundColor = kSmallNodeNormalColor
            node.layer.cornerRadius = btnRadius
            node.layer.masksToBounds = true
            node.tag = i
            self.smallPatternView.addSubview(node)
            self.smallNodes.append(node)
        }
    }
    
    func createInfoLb() {
        self.infoLb.frame = CGRect(x: 0, y: self.subtitleLb.bottom+50, width: 60, height: 20)
        self.infoLb.textAlignment = .center
        self.infoLb.textColor = kInfoColor
        self.infoLb.font = FONT_CUSTOM(15.0)
        self.view.addSubview(self.infoLb)
    }
    
    func createReminderLb() {
        self.reminderLb.frame = CGRect(x: 0, y: self.subtitleLb.bottom+80, width: SCREEN_WIDTH(), height: 20)
        self.reminderLb.textAlignment = .center
        self.reminderLb.textColor = kReminderTitleColor
        self.reminderLb.font = FONT_CUSTOM(15.0)
        self.view.addSubview(self.reminderLb)
    }
    
    func createResetBtn() {
        self.resetBtn = self.createBottomBtn(title: LString(key: "Reset Pattern"))
        self.resetBtn.addTarget(self, action: #selector(resetPatternStr), for: .touchUpInside)
    }
    
    func createForgetPwdBtn() {
        self.forgetPwdBtn = self.createBottomBtn(title: LString(key: "Forget Pattern"))
    }
    
    /// create the button under the patternView
    func createBottomBtn(title: String) -> UIButton {
        let btn = UIButton()
        btn.size = CGSize(width: 120, height: 30)
        btn.centerX = SCREEN_WIDTH() / 2.0
        btn.centerY = self.patternView.bottom + (SCREEN_HEIGHT() - self.patternView.bottom) / 2.0
        btn.setTitle(title, for: .normal)
        btn.setTitleColor(kColorTimeframeNormal(), for: .normal)
        btn.titleLabel?.font = FONT_CUSTOM(15.0)
        self.view.addSubview(btn)
        
        return btn
    }
    
    // MARK: - button function
    
    func clickBackBtn() {
        self.dismiss(animated: true, completion: nil)
    }
    
    /// reset patternStr user set first time
    func resetPatternStr() {
        self.patternStr = nil
        self.updateSmallPatternView()
        self.subtitleLb.text = LString(key: "Draw your pattern")
    }
    
    /// login with password and forget the pattern
    func loginWithPasswordAndForgetRecordPattern() {
        print("loginWithPasswordAndForgetRecordPattern")
    }
    
    // MARK: - PatternViewDelegate
    
    func patternEnded(patternStr: String, showError: () -> Void) {
        if self.type != .setting || self.patternStr != nil {
            if self.patternStr == patternStr {
                self.verifySucceed()
            }else {
                showError() /// notify patternView showing error status
                
                self.allowedErrorCount -= 1
                if self.allowedErrorCount <= 0 {
                    
                }
                
                var errorMsg = LString(key: "Invalid password 4 attempt(s) left")
                errorMsg = errorMsg.replacingOccurrences(of: "4", with:  "\(self.allowedErrorCount)")
                self.showErrorMsg(errorMsg: errorMsg)
            }
        }else {
            if patternStr.characters.count >= minimumCount {
                self.patternStr = patternStr
                self.updateSmallPatternView()
                self.subtitleLb.text = LString(key: "Draw pattern again")
            }else {
                self.showErrorMsg(errorMsg: LString(key: "At least 4 points required"))
            }
        }
    }
    
    func verifySucceed() {
        switch self.type {
            case .setting:
                UserDefaults.standard.set(self.patternStr, forKey: kPatternPassword())
                UserDefaults.standard.synchronize()
                self.delegate?.didPatternSettingSucceed()
                break
            case .verify:
                self.delegate?.didPatternVerifySucceed()
                break
            case .modify:
                self.type = .setting
                break
            case .cancel:
                UserDefaults.standard.set(nil, forKey: kPatternPassword())
                UserDefaults.standard.synchronize()
                break
        }
        
        self.dismiss(animated: true, completion: nil)
    }
    
    /// when patternStr update, must invoke it
    func updateSmallPatternView() {
        if self.type != .setting {
            return
        }
        
        if let patternStr = self.patternStr {
            for character in patternStr.characters {
                let tag: Int = Int(character.description)!
                let node = self.smallNodes[tag]
                node.backgroundColor = kSmallNodeSelectedColor
            }
        }else {
            for node in self.smallNodes {
                node.backgroundColor = kSmallNodeNormalColor
            }
        }
    }
    
    func showErrorMsg(errorMsg: String) {
        self.reminderLb.text = errorMsg
        self.reminderLb.textColor = kNodeWarningColor
        self.shakeView(shakeView: self.reminderLb)
    }
    
    /// when error happening, shake the reminderView
    func shakeView(shakeView: UIView) {
        let shakeAnimation = CAKeyframeAnimation(keyPath: "transform.translation.x")
        let s = 5
        shakeAnimation.values = [-s,0,s,0,-s,0,s,0]
        shakeAnimation.duration = 0.3
        shakeAnimation.repeatCount = 2
        shakeAnimation.isRemovedOnCompletion = true
        shakeView.layer.add(shakeAnimation, forKey: "shake")
    }
    
    // MARK: - Device Orientation
    
    override var shouldAutorotate: Bool {
        return true
    }
    
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return .portrait
    }
    
    // MARK: - hidden StatusBar
    
    override var prefersStatusBarHidden: Bool {
        return true
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
