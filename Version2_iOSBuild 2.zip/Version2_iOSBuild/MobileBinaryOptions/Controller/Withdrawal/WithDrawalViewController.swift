//
//  WithDrawalViewController.swift
//  MobileBinaryOptions
//
//  Created by Anandh on 1/30/17.
//  Copyright © 2017 Broctagon. All rights reserved.
//

import UIKit

class WithDrawalViewController: BaseVC , UICollectionViewDelegate,UICollectionViewDataSource {
    // Withdrawal View
    var withdrawalView = UIView()
    // Back Button
    var backBtn = UIButton()
    // WithDrawal label
    var withDrawalLabel = UILabel()
    
    // WithDrawal images  array
    var withdrawalImagesArray = NSMutableArray()
    
    //ImageView and Select Button
    var withdrawalImageView = UIImageView()
    var withDrawalSelectBtn = UIButton()
    
    // Withdrawal Financial Images
    var withdrawal_FinancilImage1 = UIImageView()
    var withdrawal_FinancilImage2 = UIImageView()
    var withdrawal_FinancilImage3 = UIImageView()
    var withdrawal_FinancilImage4 = UIImageView()


   // MARK:- View Initilaization
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.addwithDrawalControlsForUI()
    }
    
  // MARK:- Add UI for ViewController
    func addwithDrawalControlsForUI(){
        
        // Static With Drawal Images
        withdrawalImagesArray = ["skrill@3x.png","unionpay@3x.png","visa-mastercard@3x.png","wire-transfer@3x.png"]
        
        // WithDrawal BackGroudView
        let frame = CGRect(x: CGFloat(0), y: CGFloat(0), width: SCREEN_WIDTH(), height: SCREEN_HEIGHT())
        let backgroundImage = UIImageView(frame: frame)
        backgroundImage.image = UIImage(named: "bg@3x.png")
        self.withdrawalView.insertSubview(backgroundImage, at: 0)
        self.view.addSubview(self.withdrawalView)
        
        // Back Button
        backBtn = UIButton.init(type: .custom)
        backBtn = UIButton(frame: CGRect(x: 5, y:15, width: 30, height: 30))
        backBtn.setImage(UIImage(named: "back_icon@3x.png"), for: .normal)
        backBtn.imageView?.contentMode = .scaleAspectFit
        backBtn.addTarget(self, action:#selector(self.backButtonAction(_:)), for: .touchUpInside)
        self.view.addSubview(backBtn)

        //  Withdrawal  TypeLabel
        withDrawalLabel.frame = CGRect(x:30, y:(backBtn.frame.size.height+10), width: (SCREEN_WIDTH()-60), height: 30)
        withDrawalLabel.textColor = UIColor.yellow
        withDrawalLabel.textAlignment = NSTextAlignment.center
        withDrawalLabel.text = "Request New Withdrawal"
        withDrawalLabel.font = UIFont.systemFont(ofSize: 20)
        self.view.addSubview(withDrawalLabel)
        
        // CollectionView WithDrawal types
        let layout: UICollectionViewFlowLayout = UICollectionViewFlowLayout()
        if (SCREEN_WIDTH() >= 568) {
            layout.itemSize = CGSize(width: SCREEN_WIDTH() * 36/100 , height: SCREEN_HEIGHT() * 28/100)
            layout.sectionInset = UIEdgeInsets(top: 0, left: 0, bottom: 30, right: 10)
        }
        else{
            layout.itemSize = CGSize(width: SCREEN_WIDTH() * 32/100 , height: SCREEN_HEIGHT() * 26/100)
            layout.sectionInset = UIEdgeInsets(top: 0, left: 30, bottom: 30, right: 35)
        }
        let myCollectionView:UICollectionView = UICollectionView(frame:CGRect(x: 10, y:(withDrawalLabel.frame.origin.y+withDrawalLabel.frame.size.height+40), width: (SCREEN_WIDTH()-20), height: SCREEN_HEIGHT() * 60/100), collectionViewLayout: layout)
        myCollectionView.dataSource = self
        myCollectionView.delegate = self
        myCollectionView.register(UICollectionViewCell.self, forCellWithReuseIdentifier: "MyCell")
        myCollectionView.backgroundColor = UIColor.clear
        self.view.addSubview(myCollectionView)
        
        
        // WithDrawal Financial images
        withdrawal_FinancilImage1.frame = CGRect(x:25, y:(myCollectionView.frame.size.height+myCollectionView.frame.origin.y+SCREEN_HEIGHT() * 9/100), width:((((SCREEN_WIDTH())-120)/4)+10), height: SCREEN_HEIGHT() * 12/100)
        withdrawal_FinancilImage1.image = UIImage(named: "FV-logo@3x.png")!
        withdrawal_FinancilImage1.contentMode = .scaleAspectFit
        self.view.addSubview(withdrawal_FinancilImage1)
        
        withdrawal_FinancilImage2.frame = CGRect(x:(withdrawal_FinancilImage1.frame.size.height+withdrawal_FinancilImage1.frame.origin.x+5), y:(myCollectionView.frame.size.height+myCollectionView.frame.origin.y+SCREEN_HEIGHT() * 9/100), width: ((((SCREEN_WIDTH())-120)/4)+10), height: SCREEN_HEIGHT() * 12/100)
        withdrawal_FinancilImage2.image = UIImage(named: "Finance-Review-Logo@3x.png")!
        withdrawal_FinancilImage2.contentMode = .scaleAspectFit
        self.view.addSubview(withdrawal_FinancilImage2)
        
        withdrawal_FinancilImage3.frame = CGRect(x:(withdrawal_FinancilImage2.frame.size.height+withdrawal_FinancilImage2.frame.origin.x+5), y:(myCollectionView.frame.size.height+myCollectionView.frame.origin.y+SCREEN_HEIGHT() * 9/100), width: ((((SCREEN_WIDTH())-120)/4)+10), height: SCREEN_HEIGHT() * 12/100)
        withdrawal_FinancilImage3.image = UIImage(named: "Best--Trading")!
        withdrawal_FinancilImage3.contentMode = .scaleAspectFit
        self.view.addSubview(withdrawal_FinancilImage3)
        
        withdrawal_FinancilImage4.frame = CGRect(x:(withdrawal_FinancilImage3.frame.size.height+withdrawal_FinancilImage3.frame.origin.x+5), y:(myCollectionView.frame.size.height+myCollectionView.frame.origin.y+SCREEN_HEIGHT() * 9/100), width:((((SCREEN_WIDTH())-120)/4)+10), height: SCREEN_HEIGHT() * 12/100)
        withdrawal_FinancilImage4.image = UIImage(named: "Best-Binary-Logo@3x.png")!
        withdrawal_FinancilImage4.contentMode = .scaleAspectFit
        self.view.addSubview(withdrawal_FinancilImage4)
        
    }
    
    // MARK:- DataSource and Delegate Methods Of collectionView
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return withdrawalImagesArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell: UICollectionViewCell? = collectionView.dequeueReusableCell(withReuseIdentifier: "MyCell", for: indexPath)
        
        //WithDrawal ImageView
        withdrawalImageView = UIImageView(frame: CGRect(x: CGFloat(0), y: CGFloat(0), width: CGFloat(SCREEN_WIDTH() * 34/100), height: CGFloat(SCREEN_HEIGHT() * 22/100)))
        withdrawalImageView.clipsToBounds = true
        withdrawalImageView.image = UIImage(named: withdrawalImagesArray[indexPath.row] as! String)
        withdrawalImageView.contentMode = .scaleAspectFit
        cell?.contentView.addSubview(withdrawalImageView)
        
        print(indexPath.row)
        
        // WithDrawal Select Button
        withDrawalSelectBtn = UIButton(type:.custom)
        withDrawalSelectBtn = UIButton(frame: CGRect(x: 0, y:(withdrawalImageView.frame.size.height+withdrawalImageView.frame.origin.y), width: CGFloat(SCREEN_WIDTH() * 34/100), height: 33))
        withDrawalSelectBtn.setTitle("Select", for: .normal)
        withDrawalSelectBtn.setBackgroundImage(UIImage(named: "btn2@3x.png"), for: .normal)
        withDrawalSelectBtn.addTarget(self, action:#selector(selectButtonAction(_:)), for: .touchUpInside)
        withDrawalSelectBtn.titleLabel?.font = UIFont.systemFont(ofSize: 14)
        withDrawalSelectBtn.tag = (100 + indexPath.row)
        cell?.contentView.addSubview(withDrawalSelectBtn)
        
        return cell!
    }
    
    // MARK:- BUTTON ACTIONS
    
    func backButtonAction(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)

//        sender.isSelected = !sender.isSelected
//        if (sender.isSelected) {
//            print("Button action")
//            let vc = TradingHallVC()
//            let navi = BaseNavigationController(rootViewController: vc)
//            navi.navigationBar.isTranslucent = false
//            navi.isNavigationBarHidden = true
//            self.present(navi, animated: true, completion: nil)
//        }
//        else{
//            print("Button")
//        }
    }
    
    func selectButtonAction(_ sender: UIButton) {
//        btn2_press@3x
        sender.isSelected = !sender.isSelected
        if (sender.isSelected) {
            print("Button action")
            let vc = WithdrawalPaymentViewController()
            let navi = BaseNavigationController(rootViewController: vc)
            navi.navigationBar.isTranslucent = false
            navi.isNavigationBarHidden = true
            self.present(navi, animated: true, completion: nil)
            withDrawalSelectBtn.setBackgroundImage(UIImage(named: "btn2_press@3x.png"), for: .normal)

        }
        else{
            print("Button")
            withDrawalSelectBtn.setBackgroundImage(UIImage(named: "btn2@3x.png"), for: .normal)

        }

    }
    
    // MARK:- Device Orientation
    
    override var shouldAutorotate: Bool {
        return true
    }
    
     override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return .portrait
    }
    
    // MARK:- Default memoryWarning
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
