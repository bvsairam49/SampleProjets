//
//  WithdrawalPaymentViewController.swift
//  MobileBinaryOptions
//
//  Created by Anandh on 1/31/17.
//  Copyright © 2017 Broctagon. All rights reserved.
//

import UIKit

class WithdrawalPaymentViewController: BaseVC ,UITextFieldDelegate,
UITableViewDelegate,UITableViewDataSource , UIGestureRecognizerDelegate
 {
    // WithDrawal BackGroud  view
    var withDrawalBgView = UIView()
    // Back button
    var backBtn = UIButton()
    // withDarwal type Label
    var withDrawalTypeLabel = UILabel()
    // WithDrawal Table
    // var withDrawalConditionsView = UIView()
    var withdrawalContentTableView = UITableView()
    
    var withDrawalParam_TextField = UITextField()
    var withDrawalParam_dropdownBtn = UIButton()
    var seperatorLabel = UILabel()
    
    
    // Check mark Button
    var checkmarkBtn = UIButton()
    //WithDrawal Terms and  Conditions Label
    var withDrawaltermsLabel = UILabel()
    // WithDrawal Submit button
    var withDrawalSubmitBtn = UIButton()
    // WithDrawal financial Images
    var withdrawal_LogoImage1 = UIImageView()
    var withdrawal_LogoImage2 = UIImageView()
    var withdrawal_LogoImage3 = UIImageView()
    var withdrawal_LogoImage4 = UIImageView()
    
    // Check either TextField Or DropDown For Reference
    var uiTypeStr = NSString()
    
    // TapGesture for Removing tableView
    var tapGesture = UITapGestureRecognizer()
    var withdrawalTypesTableView = UITableView()
    
    // Dictionary Data
    var dataDictioanry = NSMutableDictionary()
    
    // TableView Y-Position
    var rectInSuperview = CGRect()
    
    // ADD Tool Bar
    var numberToolbar =  UIToolbar()
    var activeField =  UITextField()

    // MARK:- View Initialization.
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.addUIforWithDrawalControl()
    }
    
    // MARK:- ADD UI for Withdrawal controls.
    func addUIforWithDrawalControl(){
        // DropDown Table
        withdrawalTypesTableView.isHidden = true
        // Given type Text or dropdown
         uiTypeStr = "Text"
        
        // gesture recognizer for UIView
        var tapGesture1 = UITapGestureRecognizer()
        tapGesture1 = UITapGestureRecognizer(target: self, action: #selector(WithdrawalPaymentViewController.handleTap1(gestureRecognizer:)))
        tapGesture1.delegate = self
        self.view.addGestureRecognizer(tapGesture1)

        // Toolbar
        numberToolbar = UIToolbar(frame: CGRect(x: CGFloat(0), y: CGFloat(0), width: CGFloat(SCREEN_WIDTH()), height: CGFloat(40)))
        numberToolbar.items = [UIBarButtonItem(title: "Cancel", style: .done, target: self, action: #selector(self.cancelNumberPad)), UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil), UIBarButtonItem(title: "Ok", style: .done, target: self, action: #selector(self.doneWithNumberPad))]
        

        //  Withdrawal BackGroundView
        let frame = CGRect(x: CGFloat(0), y: CGFloat(0), width: SCREEN_WIDTH(), height: SCREEN_HEIGHT())
        let backgroundImage = UIImageView(frame: frame)
        backgroundImage.image = UIImage(named: "bg@3x.png")
        self.withDrawalBgView.insertSubview(backgroundImage, at: 0)
        self.view.addSubview(self.withDrawalBgView)
        
        //  BackButton
        backBtn = UIButton.init(type: .custom)
        backBtn = UIButton(frame: CGRect(x: 10, y:15, width: 30, height: 30))
        backBtn.setImage(UIImage(named: "back_icon@3x.png"), for: .normal)
        backBtn.imageView?.contentMode = .scaleAspectFit
        backBtn.addTarget(self, action:#selector(backButtonAction(_:)), for: .touchUpInside)
        self.view.addSubview(backBtn)
        
        //  deposite  Label
        withDrawalTypeLabel.frame = CGRect(x:30, y:(backBtn.frame.size.height+20), width: (SCREEN_WIDTH()-60), height: 30)
        withDrawalTypeLabel.textColor = UIColor.yellow
        withDrawalTypeLabel.textAlignment = NSTextAlignment.center
        withDrawalTypeLabel.text = "Rfupay- PaymentGateway"
        withDrawalTypeLabel.font = UIFont.systemFont(ofSize: 20)
        self.view.addSubview(withDrawalTypeLabel)
        
        // WithDrawal  Tableview
        if (SCREEN_WIDTH()>=568)
        {
          withdrawalContentTableView.frame = CGRect(x:30, y:(withDrawalTypeLabel.frame.size.height+withDrawalTypeLabel.frame.origin.y+40), width: (SCREEN_WIDTH()-60), height: SCREEN_HEIGHT() * 40/100)
        }
        else{
           withdrawalContentTableView.frame = CGRect(x:30, y:(withDrawalTypeLabel.frame.size.height+withDrawalTypeLabel.frame.origin.y+40), width: (SCREEN_WIDTH()-60), height: SCREEN_HEIGHT() * 42/100)
        }
        withdrawalContentTableView.dataSource = self
        withdrawalContentTableView.delegate = self
        withdrawalContentTableView.register(UITableViewCell.self, forCellReuseIdentifier: "myCell")
        withdrawalContentTableView.backgroundColor = UIColor.clear
        withdrawalContentTableView.layoutMargins = UIEdgeInsets.zero
        withdrawalContentTableView.separatorInset = UIEdgeInsets.zero
        self.view.addSubview(withdrawalContentTableView)
        
        //CheckMark button
        checkmarkBtn = UIButton.init(type: .custom)
        checkmarkBtn = UIButton(frame: CGRect(x: 20, y:(withdrawalContentTableView.frame.size.height+withdrawalContentTableView.frame.origin.y+10), width: 15, height: 15))
        checkmarkBtn.setBackgroundImage(UIImage(named: "select_icon_nopress@3x.png"), for: .normal)
        checkmarkBtn.imageView?.contentMode = .scaleAspectFit
        checkmarkBtn.addTarget(self, action:#selector(checkMarkButtonAction(_:)), for: .touchUpInside)
        self.view.addSubview(checkmarkBtn)
        
         // TermsandConditions label
        withDrawaltermsLabel.frame = CGRect(x: (checkmarkBtn.frame.size.width+checkmarkBtn.frame.origin.x+10), y:(withdrawalContentTableView.frame.size.height+withdrawalContentTableView.frame.origin.y+2), width: (SCREEN_WIDTH()-60), height: SCREEN_HEIGHT()/7)
        withDrawaltermsLabel.textColor = UIColor.white
        withDrawaltermsLabel.textAlignment = NSTextAlignment.center
        var textStr = NSString()
        textStr = "DepositDepositDepositDepositDepositDepositDepositDepositDepositDepositDepositDepositDepositDepositDepositDepositDepositDepositDepositDepositDepositDepositDepositDepositDepositDepositDeposit"
        withDrawaltermsLabel.text = "\(textStr)\n"
        withDrawaltermsLabel.lineBreakMode = .byCharWrapping
        withDrawaltermsLabel.numberOfLines = 6
        withDrawaltermsLabel.font = UIFont.systemFont(ofSize:14)
        self.view.addSubview(withDrawaltermsLabel)
        
        // SubmitButton
        withDrawalSubmitBtn = UIButton.init(type: .custom)
        withDrawalSubmitBtn = UIButton(frame: CGRect(x: 27, y:(withDrawaltermsLabel.frame.size.height+withDrawaltermsLabel.frame.origin.y+10), width: SCREEN_WIDTH()-54, height: 46))
        withDrawalSubmitBtn.setBackgroundImage(UIImage(named: "btn@3x.png"), for: .normal)
        withDrawalSubmitBtn.setTitle("Submit", for: .normal)
        withDrawalSubmitBtn.titleLabel?.font = UIFont.systemFont(ofSize: 20)
        withDrawalSubmitBtn.imageView?.contentMode = .scaleAspectFit
        withDrawalSubmitBtn.addTarget(self, action:#selector(submitButtonAction(_:)), for: .touchUpInside)
        self.view.addSubview(withDrawalSubmitBtn)
        
        // Withdrawal Financial Images
        withdrawal_LogoImage1.frame = CGRect(x:25, y:(withDrawalSubmitBtn.frame.size.height+withDrawalSubmitBtn.frame.origin.y+10), width:((((SCREEN_WIDTH())-120)/4)+10), height: SCREEN_HEIGHT() * 12/100)
        withdrawal_LogoImage1.image = UIImage(named: "FV-logo@3x.png")!
        withdrawal_LogoImage1.contentMode = .scaleAspectFit
        self.view.addSubview(withdrawal_LogoImage1)
        
        withdrawal_LogoImage2.frame = CGRect(x:(withdrawal_LogoImage1.frame.size.height+withdrawal_LogoImage1.frame.origin.x+5), y:(withDrawalSubmitBtn.frame.size.height+withDrawalSubmitBtn.frame.origin.y+10), width: ((((SCREEN_WIDTH())-120)/4)+10), height: SCREEN_HEIGHT() * 12/100)
        withdrawal_LogoImage2.image = UIImage(named: "Finance-Review-Logo@3x.png")!
        withdrawal_LogoImage2.contentMode = .scaleAspectFit
        self.view.addSubview(withdrawal_LogoImage2)
        
        withdrawal_LogoImage3.frame = CGRect(x:(withdrawal_LogoImage2.frame.size.height+withdrawal_LogoImage2.frame.origin.x+5), y:(withDrawalSubmitBtn.frame.size.height+withDrawalSubmitBtn.frame.origin.y+10), width: ((((SCREEN_WIDTH())-120)/4)+10), height: SCREEN_HEIGHT() * 12/100)
        withdrawal_LogoImage3.image = UIImage(named: "Best--Trading")!
        withdrawal_LogoImage3.contentMode = .scaleAspectFit
        self.view.addSubview(withdrawal_LogoImage3)
        
        withdrawal_LogoImage4.frame = CGRect(x:(withdrawal_LogoImage3.frame.size.height+withdrawal_LogoImage3.frame.origin.x+5), y:(withDrawalSubmitBtn.frame.size.height+withDrawalSubmitBtn.frame.origin.y+10), width:((((SCREEN_WIDTH())-120)/4)+10), height: SCREEN_HEIGHT() * 12/100)
        withdrawal_LogoImage4.image = UIImage(named: "Best-Binary-Logo@3x.png")!
        withdrawal_LogoImage4.contentMode = .scaleAspectFit
        self.view.addSubview(withdrawal_LogoImage4)
    }
    
    // MARK:- TableView Datasource and Delegate Methods.
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        if ( tableView == withdrawalTypesTableView){
            return 45
        }
        else{
            
            return 52
        }
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        if ( tableView == withdrawalTypesTableView){
            return 2
        }
        else{
            
            return 10
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        // Initialize the  TableView cell
        var cell: UITableViewCell? = nil
        if ( tableView == withdrawalContentTableView)
        {
            let cellIdentifier: String = "\("myCell")\(Int(indexPath.row))"
            cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier)
            if cell == nil {
                cell = UITableViewCell(style: .default, reuseIdentifier: cellIdentifier)
                // depositeTextField
                if (uiTypeStr == "Text"){
            
                    withDrawalParam_TextField = UITextField(frame: CGRect(x:10, y: 0, width:(SCREEN_WIDTH()-20), height: 44))
                    withDrawalParam_TextField.placeholder = "Enter OTP number"
                    withDrawalParam_TextField.textColor = UIColor.white
                    withDrawalParam_TextField.keyboardType = UIKeyboardType.phonePad
                    withDrawalParam_TextField.borderStyle = UITextBorderStyle.none
                    withDrawalParam_TextField.backgroundColor = UIColor.clear
                    withDrawalParam_TextField.delegate = self
                    withDrawalParam_TextField.setValue(UIColor(red: CGFloat(68.0 / 255.0), green: CGFloat(84.0 / 255.0), blue: CGFloat(168.0 / 255.0), alpha: CGFloat(1.0)), forKeyPath: "_placeholderLabel.textColor")
                    
                    withDrawalParam_TextField.inputAccessoryView = numberToolbar
                    
                    cell?.contentView .addSubview(withDrawalParam_TextField)
                    withDrawalParam_dropdownBtn.isHidden = true
                    withDrawalParam_TextField.isHidden = false
                }
                else if (uiTypeStr == "dropdown"){
                    // dropDown Field
                    withDrawalParam_dropdownBtn = UIButton.init(type: .custom)
                    withDrawalParam_dropdownBtn.frame = CGRect(x: CGFloat(10), y: CGFloat(4), width: CGFloat(SCREEN_WIDTH()-20), height: CGFloat(44))
                    withDrawalParam_dropdownBtn.setTitle("Account Number", for: .normal)
                    withDrawalParam_dropdownBtn.setTitleColor(UIColor.white, for: .normal)
                    withDrawalParam_dropdownBtn.titleLabel?.lineBreakMode = .byTruncatingTail
                    withDrawalParam_dropdownBtn.isExclusiveTouch = true
                    withDrawalParam_dropdownBtn.contentHorizontalAlignment = .left
                    withDrawalParam_dropdownBtn.titleEdgeInsets = UIEdgeInsetsMake(0, 30, 0, 20)
                    withDrawalParam_dropdownBtn.addTarget(self, action: #selector(dropDownButtonAction(_:)), for: .touchUpInside)
                    cell?.contentView.addSubview(withDrawalParam_dropdownBtn)
                    // dropDown Image
                    let imageView = UIImageView(frame: CGRect(x:(SCREEN_WIDTH()-80), y: CGFloat(24), width: CGFloat(10), height: CGFloat(5)))
                    imageView.image = UIImage(named: "bank_arrow@3x.png")
                    cell?.contentView.addSubview(imageView)
                    
                    withDrawalParam_dropdownBtn.isHidden = false
                }
                // Seperator Label
                seperatorLabel = UILabel(frame: CGRect(x:10, y:44, width: (SCREEN_WIDTH()-20), height: 2))
                seperatorLabel.backgroundColor = UIColor.white
                cell?.contentView.addSubview(seperatorLabel)
            }
            tableView.separatorStyle = .none
            cell?.backgroundColor = UIColor.clear
        }
        else if(tableView == withdrawalTypesTableView){
            let cellIdentifier1: String = "\("dropDownCell")\(Int(indexPath.row))"
            if (withdrawalTypesTableView.isHidden == false)
            {
                cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier1)
                if cell == nil {
                    cell = UITableViewCell(style: .default, reuseIdentifier: cellIdentifier1)
                    cell?.textLabel?.text = "Bank"
                    tableView.separatorStyle = .singleLine
                    cell?.separatorInset = UIEdgeInsets.zero
                    cell?.backgroundColor = UIColor.clear
                }
            }
        }
        return cell!
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        print("User selected table row \(indexPath.row))")
        
    }
    
    // MARK:- ButtonAction Methods.
    
    func backButtonAction(_ sender: UIButton) {
    sender.isSelected = !sender.isSelected
        if (sender.isSelected) {
            print("Button action")
            let vc = WithDrawalViewController()
            let navi = BaseNavigationController(rootViewController: vc)
            navi.navigationBar.isTranslucent = false
            navi.isNavigationBarHidden = true
            self.present(navi, animated: true, completion: nil)
        }
        else{
            print("Button")
        }

        print("Back button action")
    }
    
    func checkMarkButtonAction(_ sender: UIButton) {
        sender.isSelected = !sender.isSelected

        if (sender.isSelected) {
            checkmarkBtn.setBackgroundImage(UIImage(named: "select_icon@3x.png"), for: .normal)

        }
        else{
            print("Button")
            checkmarkBtn.setBackgroundImage(UIImage(named: "select_icon_nopress@3x.png"), for: .normal)
        }
        
//        select_icon@3x
    }
    
    func submitButtonAction(_ sender: UIButton) {
        print("Submit button action")
        
        sender.isSelected = !sender.isSelected
        
        if (sender.isSelected) {
            withDrawalSubmitBtn.setBackgroundImage(UIImage(named: "btn_press@3x.png"), for: .normal)
        }
        else{
            print("Button")
            withDrawalSubmitBtn.setBackgroundImage(UIImage(named: "btn@3x.png"), for: .normal)
        }

        
    }
    
    func dropDownButtonAction(_ sender: Any)  {
        print("DropDown Action")
        withdrawalTypesTableView.isHidden = false
        let buttonPosition = (sender as AnyObject).convert!(CGPoint.zero, to: withdrawalContentTableView)
        let tappedIP: IndexPath? = withdrawalContentTableView.indexPathForRow(at: buttonPosition)
        let rectInTableView: CGRect = withdrawalContentTableView.rectForRow(at: tappedIP!)
        rectInSuperview = withdrawalContentTableView.convert(rectInTableView, to: withdrawalContentTableView.superview)
        print("Cell Y Is \(rectInSuperview.origin.y)")
        print("Cell X Is \(rectInSuperview.origin.x)")
        
        // DepositeType tableView
        withdrawalTypesTableView.frame = CGRect(x:(rectInSuperview.origin.x), y:(rectInSuperview.origin.y+40), width: (SCREEN_WIDTH()-40), height: (SCREEN_HEIGHT()/4))
        //        depositeTypesTableView.backgroundColor = UIColor(patternImage: UIImage(named: "bg@3x.png")!)
        withdrawalTypesTableView.backgroundColor = UIColor.clear
        let tableBackgroundView = UIImageView(image: UIImage(named: "bg@3x.png"))
        tableBackgroundView.frame = withdrawalTypesTableView.frame
        withdrawalTypesTableView.backgroundView = tableBackgroundView
        withdrawalTypesTableView.delegate = self
        withdrawalTypesTableView.dataSource = self
        withdrawalTypesTableView.layoutMargins = UIEdgeInsets.zero
        withdrawalTypesTableView.separatorInset = UIEdgeInsets.zero
        withdrawalTypesTableView.register(UITableViewCell.self, forCellReuseIdentifier: "dropDownCell")
        withdrawalTypesTableView.layer.cornerRadius = 10
        self.view.addSubview(withdrawalTypesTableView)
        
        // gesture recognizer
        tapGesture = UITapGestureRecognizer(target: self, action: #selector(WithdrawalPaymentViewController.handleTap(gestureRecognizer:)))
        tapGesture.delegate = self
        self.view.addGestureRecognizer(tapGesture)
    }
   
    // MARK:- TapGesture Method.
    func handleTap(gestureRecognizer: UIGestureRecognizer) {
        if (withdrawalTypesTableView.isHidden == false) {
            withdrawalTypesTableView.isHidden = true
        }
        
    }
    func handleTap1(gestureRecognizer: UIGestureRecognizer) {
       self.view.endEditing(true)
        
    }
    
    // MARK: - UITextfieldDelegate
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        animateViewMoving(true, moveValue: 100)
    }
    func textFieldDidEndEditing(_ textField: UITextField) {
        animateViewMoving(false, moveValue: 100)
        //        headersDictionary .setValue(textField.text, forKey: "\(textField.tag)")
        //        print(headersDictionary)
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool
    {
        textField.resignFirstResponder()
        return true
    }
    func animateViewMoving (_ up:Bool, moveValue :CGFloat){
        let movementDuration:TimeInterval = 0.3
        let movement:CGFloat = ( up ? -moveValue : moveValue)
        UIView.beginAnimations( "animateView", context: nil)
        UIView.setAnimationBeginsFromCurrentState(true)
        UIView.setAnimationDuration(movementDuration )
        self.view.frame = self.view.frame.offsetBy(dx: 0,  dy: movement)
        UIView.commitAnimations()
    }

    
    // MARK: - Toolbar methods.
    
    func cancelNumberPad() {
//        if activeField.isFirstResponder {
//            activeField.resignFirstResponder()
            activeField.text = ""
//        }
        self.view.endEditing(true)
    }
    
    func doneWithNumberPad() {
        self.view.endEditing(true)
//        if activeField.isFirstResponder {
//            activeField.resignFirstResponder()
//        }
    }
    
    // MARK:- Device Orientation
    
    override var shouldAutorotate: Bool {
        return true
    }
    
     override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return .portrait
    }
    
    // MARK:- Default Memory warning
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
