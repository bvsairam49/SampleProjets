//
//  DepositeViewController.swift
//  MobileBinaryOptions
//
//  Created by Anandh on 1/30/17.
//  Copyright © 2017 Broctagon. All rights reserved.
//

import UIKit

class DepositeViewController: BaseVC , UICollectionViewDelegate,UICollectionViewDataSource {
    // DepositeBGView
    var depositeView = UIView()
    //BackButton
    var backBtn = UIButton()
    // Deposite Label
    var depositeLabel = UILabel()
    // Deposite Terms and Conditions Label
    var depositeTermsLabel = UILabel()
    
    // deposite Imamges  array
    var depositeImagesArray = NSMutableArray()
    
    // CollectionView (Image and DepositeType)
    var depositeImageview = UIImageView()
    var depositeSelectBtn = UIButton()
    
    // Deposite Accept Terms and conditions
    var depositeNoteLabel = UILabel()
    
    // Deposite Background Financial Images
     var dep_FinancilImage1 = UIImageView()
     var dep_FinancilImage2 = UIImageView()
     var dep_FinancilImage3 = UIImageView()
     var dep_FinancilImage4 = UIImageView()
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.addControlsForDepositeUI()
    }
    
    // MARK:- Add controls For UI
    
    func addControlsForDepositeUI() {
        // Statically added Images For reference
        depositeImagesArray = ["skrill.png", "unionpay.png", "visa-mastercard.png", "wire-transfer.png"]

        // DepositeBg view
        let frame = CGRect(x: CGFloat(0), y: CGFloat(0), width: SCREEN_WIDTH(), height: SCREEN_HEIGHT())
        let backgroundImage = UIImageView(frame: frame)
        backgroundImage.image = UIImage(named: "bg.png")
        self.depositeView.insertSubview(backgroundImage, at: 0)
        self.view.addSubview(self.depositeView)
        
        // Back Button
        backBtn = UIButton.init(type: .custom)
        backBtn = UIButton(frame: CGRect(x: 5, y:15, width: 30, height: 30))
        backBtn.setImage(UIImage(named: "back_icon.png"), for: .normal)
        backBtn.imageView?.contentMode = .scaleAspectFit
        backBtn.addTarget(self, action:#selector(backButtonAction(_:)), for: .touchUpInside)
        self.view.addSubview(backBtn)
        
        //  deposite  Label
        depositeLabel.frame = CGRect(x:30, y:(backBtn.frame.size.height), width: (SCREEN_WIDTH()-60), height: 30)
        depositeLabel.textColor = UIColor.yellow
        depositeLabel.textAlignment = NSTextAlignment.center
        depositeLabel.text = "Deposit"
        self.view.addSubview(depositeLabel)
        
        //deposite Terms and Conditions Label
        depositeTermsLabel.frame = CGRect(x:20, y:(depositeLabel.frame.size.height+depositeLabel.frame.origin.y), width: (SCREEN_WIDTH()-40), height: SCREEN_HEIGHT()/8)
        depositeTermsLabel.textColor = UIColor.white
        depositeTermsLabel.textAlignment = NSTextAlignment.center
        depositeTermsLabel.text = "DepositDepositDepositDepositDepositDepositDepositDepositDepositDepositDepositDepositDepositDepositDepositDepositDepositDepositDepositDepositDepositDepositDepositDepositDepositDepositDeposit"
        depositeTermsLabel.lineBreakMode = .byWordWrapping
        depositeTermsLabel.numberOfLines = 4
        depositeTermsLabel.font = UIFont.systemFont(ofSize:10)
        self.view.addSubview(depositeTermsLabel)
        
        // CollectionView Deposite types
        let layout: UICollectionViewFlowLayout = UICollectionViewFlowLayout()
        if (SCREEN_WIDTH() >= 568) {
            layout.itemSize = CGSize(width: SCREEN_WIDTH() * 36/100 , height: SCREEN_HEIGHT() * 28/100)
            layout.sectionInset = UIEdgeInsets(top: 0, left: 0, bottom: 30, right: 10)
        }
        else{
         layout.itemSize = CGSize(width: SCREEN_WIDTH() * 32/100 , height: SCREEN_HEIGHT() * 26/100)
         layout.sectionInset = UIEdgeInsets(top: 0, left: 30, bottom: 30, right: 35)
        }
        let myCollectionView:UICollectionView = UICollectionView(frame:CGRect(x: 10, y:(depositeTermsLabel.frame.origin.y+depositeTermsLabel.frame.size.height+5), width: (SCREEN_WIDTH()-20), height: SCREEN_HEIGHT() * 50/100), collectionViewLayout: layout)
        myCollectionView.dataSource = self
        myCollectionView.delegate = self
        myCollectionView.register(UICollectionViewCell.self, forCellWithReuseIdentifier: "MyCell")
        myCollectionView.backgroundColor = UIColor.clear
        self.view.addSubview(myCollectionView)
        
        // Deposite accept terms and  Conditions  label
        depositeNoteLabel.frame = CGRect(x:20, y:(myCollectionView.frame.size.height+myCollectionView.frame.origin.y+5), width: (SCREEN_WIDTH()-40), height: SCREEN_HEIGHT()/9)
        depositeNoteLabel.textColor = UIColor.white
        depositeNoteLabel.textAlignment = NSTextAlignment.center
        depositeNoteLabel.text = "Deposit:DepositDepositDepositDepositDepositDepositDepositDepositDepositDepositDepositDepositDepositDepositDepositDepositDepositDepositEnding"
        depositeNoteLabel.lineBreakMode = .byWordWrapping
        depositeNoteLabel.numberOfLines = 3
        depositeNoteLabel.font = UIFont.systemFont(ofSize:10)
        depositeNoteLabel.textColor = UIColor.red
        print((depositeNoteLabel.frame.size.height+depositeNoteLabel.frame.origin.y))
        self.view.addSubview(depositeNoteLabel)
        
        // Deposite Financial Images
        dep_FinancilImage1.frame = CGRect(x:25, y:(depositeNoteLabel.frame.size.height+depositeNoteLabel.frame.origin.y+10), width:((((SCREEN_WIDTH())-120)/4)+10), height: SCREEN_HEIGHT() * 12/100)
        dep_FinancilImage1.image = UIImage(named: "FV-logo.png")!
        dep_FinancilImage1.contentMode = .scaleAspectFit
        self.view.addSubview(dep_FinancilImage1)
        
        dep_FinancilImage2.frame = CGRect(x:(dep_FinancilImage1.frame.size.height+dep_FinancilImage1.frame.origin.x+5), y:(depositeNoteLabel.frame.size.height+depositeNoteLabel.frame.origin.y+10), width: ((((SCREEN_WIDTH())-120)/4)+10), height: SCREEN_HEIGHT() * 12/100)
        dep_FinancilImage2.image = UIImage(named: "Finance-Review-Logo.png")!
        dep_FinancilImage2.contentMode = .scaleAspectFit
        self.view.addSubview(dep_FinancilImage2)
        
        dep_FinancilImage3.frame = CGRect(x:(dep_FinancilImage2.frame.size.height+dep_FinancilImage2.frame.origin.x+5), y:(depositeNoteLabel.frame.size.height+depositeNoteLabel.frame.origin.y+10), width: ((((SCREEN_WIDTH())-120)/4)+10), height: SCREEN_HEIGHT() * 12/100)
        dep_FinancilImage3.image = UIImage(named: "Best--Trading")!
        dep_FinancilImage3.contentMode = .scaleAspectFit
        self.view.addSubview(dep_FinancilImage3)
        
        dep_FinancilImage4.frame = CGRect(x:(dep_FinancilImage3.frame.size.height+dep_FinancilImage3.frame.origin.x+5), y:(depositeNoteLabel.frame.size.height+depositeNoteLabel.frame.origin.y+10), width:((((SCREEN_WIDTH())-120)/4)+10), height: SCREEN_HEIGHT() * 12/100)
        dep_FinancilImage4.image = UIImage(named: "Best-Binary-Logo.png")!
        dep_FinancilImage4.contentMode = .scaleAspectFit
        self.view.addSubview(dep_FinancilImage4)
    }
    
    // MARK:- DataSource and Delegate Methods Of collectionView
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 4
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell: UICollectionViewCell? = collectionView.dequeueReusableCell(withReuseIdentifier: "MyCell", for: indexPath)
        
       //DepositeImageView
        depositeImageview = UIImageView(frame: CGRect(x: CGFloat(0), y: CGFloat(0), width: CGFloat(SCREEN_WIDTH() * 34/100), height: CGFloat(SCREEN_HEIGHT() * 22/100)))
        depositeImageview.clipsToBounds = true
        depositeImageview.image = UIImage(named: depositeImagesArray[indexPath.row] as! String)
        depositeImageview.contentMode = .scaleAspectFit
        cell?.contentView.addSubview(depositeImageview)

        print(indexPath.row)

        // Select Button
         depositeSelectBtn = UIButton(type: .custom)
        depositeSelectBtn = UIButton(frame: CGRect(x: 0, y:(depositeImageview.frame.size.height+depositeImageview.frame.origin.y), width: CGFloat(SCREEN_WIDTH() * 34/100), height: 33))
        depositeSelectBtn.setTitle("Select", for: .normal)
        depositeSelectBtn.setBackgroundImage(UIImage(named: "btn2.png"), for: .normal)
        depositeSelectBtn.addTarget(self, action:#selector(selectButtonAction(_:)), for: .touchUpInside)
        depositeSelectBtn.titleLabel?.font = UIFont.systemFont(ofSize: 14)
        depositeSelectBtn.tag = (100 + indexPath.row)
        cell?.contentView.addSubview(depositeSelectBtn)

        return cell!
    }
    
    // MARK:- BUTTON ACTIONS
    
    func backButtonAction(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
//        let vc = TradingHallVC()
//        let navi = BaseNavigationController(rootViewController: vc)
//        navi.navigationBar.isTranslucent = false
//        navi.isNavigationBarHidden = true
//        self.present(navi, animated: true, completion: nil)
        
//        let vc = TradingHallVC()
//        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func selectButtonAction(_ sender: UIButton) {
        print("Button action")
        let vc = DepositePaymentViewController()
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    
    
    // MARK: - Device Orientation
    
    override var shouldAutorotate: Bool {
        return true
    }
    
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return .portrait
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
