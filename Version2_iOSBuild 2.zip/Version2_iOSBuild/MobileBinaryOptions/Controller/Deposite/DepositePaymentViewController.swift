//
//  DepositePaymentViewController.swift
//  MobileBinaryOptions
//
//  Created by Anandh on 1/31/17.
//  Copyright © 2017 Broctagon. All rights reserved.
//

import UIKit

class DepositePaymentViewController: BaseVC ,UITableViewDelegate,UITableViewDataSource, UIGestureRecognizerDelegate , UITextFieldDelegate {
    
    // Set Ui for DeposuiteView
    var depositeBgView = UIView()
    var backBtn = UIButton()
    var depositeTypeLabel = UILabel()
    var depAccConditionsLabel = UILabel()
    // tableView For Deposite
    var depositeContentTableView = UITableView()
     // Deposite dropDown and textfield
    var depositeTextField = UITextField()
    var seperatorLabel = UILabel()
    var depositeDropDownBtn = UIButton()
    // Dropdown table
    /* var depositeDropDownTable = UITableView()*/
    
    // Deposite  termsandConditions Label
    var dep_TermsandconditionsLbl = UILabel()
    var checkMarkBtn = UIButton()
    var nextBtn = UIButton()
    
    // Check either TextField Or DropDown For Reference
    var uiTypeStr = NSString()
    
    // Images DepositeView
    var  dep_FinancialImage1 = UIImageView()
    var  dep_FinancialImage2 = UIImageView()
    var  dep_FinancialImage3 = UIImageView()
    var  dep_FinancialImage4 = UIImageView()
    
    // TapGesture for Removing tableView
    var tapGesture = UITapGestureRecognizer()
    var depositeTypesTableView = UITableView()
    
    // Dictionary Data 
    var dataDictioanry = NSMutableDictionary()
    
    // TableView Y-Position
    var rectInSuperview = CGRect()
    
    // ADD Tool Bar
    var numberToolbar =  UIToolbar()
    var activeField =  UITextField()
    


    // MARK:- View Initialization.
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.addUIControlsForDepositeView()
    }
    
    //  MARK:- Add UI Controls For DepositeView.
    
    func addUIControlsForDepositeView(){
        //  Dropdown Table
        depositeTypesTableView.isHidden = true
        // gesture recognizer for UIView
        var tapGesture1 = UITapGestureRecognizer()
        tapGesture1 = UITapGestureRecognizer(target: self, action: #selector(WithdrawalPaymentViewController.handleTap1(gestureRecognizer:)))
        tapGesture1.delegate = self
        self.view.addGestureRecognizer(tapGesture1)
       
        // get Type of string Dropdown or textField
         uiTypeStr = "Text"
        
        // Toolbar
        numberToolbar = UIToolbar(frame: CGRect(x: CGFloat(0), y: CGFloat(0), width: CGFloat(SCREEN_WIDTH()), height: CGFloat(40)))
        numberToolbar.items = [UIBarButtonItem(title: "Cancel", style: .done, target: self, action: #selector(self.cancelNumberPad)), UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil), UIBarButtonItem(title: "Ok", style: .done, target: self, action: #selector(self.doneWithNumberPad))]
        
        // BackgroundView
        let frame = CGRect(x: CGFloat(0), y: CGFloat(0), width: SCREEN_WIDTH(), height: SCREEN_HEIGHT())
        let backgroundImage = UIImageView(frame: frame)
        backgroundImage.image = UIImage(named: "bg@3x.png")
        self.depositeBgView.insertSubview(backgroundImage, at: 0)
        self.view.addSubview(self.depositeBgView)
        // Back Button
        backBtn = UIButton.init(type: .custom)
        backBtn = UIButton(frame: CGRect(x: 10, y:15, width: 30, height: 30))
        backBtn.setImage(UIImage(named: "back_icon@3x.png"), for: .normal)
        backBtn.imageView?.contentMode = .scaleAspectFit
        backBtn.addTarget(self, action:#selector(backButtonAction(_:)), for: .touchUpInside)
        self.view.addSubview(backBtn)
        //  deposite  Label
        depositeTypeLabel.frame = CGRect(x:30, y:(backBtn.frame.size.height+10), width: (SCREEN_WIDTH()-60), height: 30)
        depositeTypeLabel.textColor = UIColor.yellow
        depositeTypeLabel.textAlignment = NSTextAlignment.center
        depositeTypeLabel.text = "Rfupay- PaymentGateway"
        depositeTypeLabel.font = UIFont.systemFont(ofSize: 20)
        self.view.addSubview(depositeTypeLabel)
        //deposite Acc Terms Label
        depAccConditionsLabel.frame = CGRect(x:20, y:(depositeTypeLabel.frame.size.height+depositeTypeLabel.frame.origin.y), width: (SCREEN_WIDTH()-40), height: SCREEN_HEIGHT()/7)
        depAccConditionsLabel.textColor = UIColor.white
        depAccConditionsLabel.textAlignment = NSTextAlignment.center
        depAccConditionsLabel.text = "DepositDepositDepositDepositDepositDepositDepositDepositDepositDepositDepositDepositDepositDepositDepositDepositDepositDepositDepositDepositDepositDepositDepositDepositDepositDepositDeposit"
        depAccConditionsLabel.lineBreakMode = .byCharWrapping
        depAccConditionsLabel.numberOfLines = 5
        depAccConditionsLabel.font = UIFont.systemFont(ofSize:14)
        self.view.addSubview(depAccConditionsLabel)
        // Deposite DynamicView
        depositeContentTableView.frame = CGRect(x:30, y:(depAccConditionsLabel.frame.size.height+depAccConditionsLabel.frame.origin.y+10), width: (SCREEN_WIDTH()-60), height: SCREEN_HEIGHT() * 35/100)
        depositeContentTableView.dataSource = self
        depositeContentTableView.delegate = self
        depositeContentTableView.register(UITableViewCell.self, forCellReuseIdentifier: "myCell")
        depositeContentTableView.backgroundColor = UIColor.clear
        depositeContentTableView.layoutMargins = UIEdgeInsets.zero
        depositeContentTableView.separatorInset = UIEdgeInsets.zero
        self.view.addSubview(depositeContentTableView)
        
        //CheckMark button
        checkMarkBtn = UIButton.init(type: .custom)
        checkMarkBtn = UIButton(frame: CGRect(x: 20, y:(depositeContentTableView.frame.size.height+depositeContentTableView.frame.origin.y+10), width: 15, height: 15))
        checkMarkBtn.setBackgroundImage(UIImage(named: "select_icon_nopress@3x.png"), for: .normal)
        checkMarkBtn.imageView?.contentMode = .scaleAspectFit
        checkMarkBtn.addTarget(self, action:#selector(checkMarkButtonAction(_:)), for: .touchUpInside)
        self.view.addSubview(checkMarkBtn)
        
        // TermsandConditions label
        dep_TermsandconditionsLbl.frame = CGRect(x: (checkMarkBtn.frame.size.width+checkMarkBtn.frame.origin.x+10), y:(depositeContentTableView.frame.size.height+depositeContentTableView.frame.origin.y), width: (SCREEN_WIDTH()-60), height: SCREEN_HEIGHT()/7)
        dep_TermsandconditionsLbl.textColor = UIColor.white
        dep_TermsandconditionsLbl.textAlignment = NSTextAlignment.center
        var textStr = NSString()
        textStr = "DepositDepositDepositDepositDepositDepositDepositDepositDepositDepositDepositDepositDepositDepositDepositDepositDepositDepositDepositDepositDepositDepositDepositDepositDepositDepositDeposit"
        dep_TermsandconditionsLbl.text = "\(textStr)\n"
        dep_TermsandconditionsLbl.lineBreakMode = .byCharWrapping
        dep_TermsandconditionsLbl.numberOfLines = 6
        dep_TermsandconditionsLbl.font = UIFont.systemFont(ofSize:14)
        self.view.addSubview(dep_TermsandconditionsLbl)
        
        // NextButton
        nextBtn = UIButton (type: .custom)
        nextBtn = UIButton(frame: CGRect(x: 27, y:(dep_TermsandconditionsLbl.frame.size.height+dep_TermsandconditionsLbl.frame.origin.y+10), width: SCREEN_WIDTH()-54, height: 46))
        nextBtn.setBackgroundImage(UIImage(named: "btn@3x.png"), for: .normal)
        nextBtn.setTitle("Next", for: .normal)
        nextBtn.titleLabel?.font = UIFont.systemFont(ofSize: 20)
        nextBtn.imageView?.contentMode = .scaleAspectFit
        nextBtn.addTarget(self, action:#selector(nextButtonAction(_:)), for: .touchUpInside)
        self.view.addSubview(nextBtn)
        
        // Deposite Financial Images
        dep_FinancialImage1.frame = CGRect(x:25, y:(nextBtn.frame.size.height+nextBtn.frame.origin.y+10), width:((((SCREEN_WIDTH())-120)/4)+10), height: SCREEN_HEIGHT() * 12/100)
        dep_FinancialImage1.image = UIImage(named: "FV-logo@3x.png")!
        dep_FinancialImage1.contentMode = .scaleAspectFit
        self.view.addSubview(dep_FinancialImage1)
        
        dep_FinancialImage2.frame = CGRect(x:(dep_FinancialImage1.frame.size.height+dep_FinancialImage1.frame.origin.x+5), y:(nextBtn.frame.size.height+nextBtn.frame.origin.y+10), width: ((((SCREEN_WIDTH())-120)/4)+10), height: SCREEN_HEIGHT() * 12/100)
        dep_FinancialImage2.image = UIImage(named: "Finance-Review-Logo@3x.png")!
        dep_FinancialImage2.contentMode = .scaleAspectFit
        self.view.addSubview(dep_FinancialImage2)
        
        dep_FinancialImage3.frame = CGRect(x:(dep_FinancialImage2.frame.size.height+dep_FinancialImage2.frame.origin.x+5), y:(nextBtn.frame.size.height+nextBtn.frame.origin.y+10), width: ((((SCREEN_WIDTH())-120)/4)+10), height: SCREEN_HEIGHT() * 12/100)
        dep_FinancialImage3.image = UIImage(named: "Best--Trading")!
        dep_FinancialImage3.contentMode = .scaleAspectFit
        self.view.addSubview(dep_FinancialImage3)
        
        dep_FinancialImage4.frame = CGRect(x:(dep_FinancialImage3.frame.size.height+dep_FinancialImage3.frame.origin.x+5), y:(nextBtn.frame.size.height+nextBtn.frame.origin.y+10), width:((((SCREEN_WIDTH())-120)/4)+10), height: SCREEN_HEIGHT() * 12/100)
        dep_FinancialImage4.image = UIImage(named: "Best-Binary-Logo@3x.png")!
        dep_FinancialImage4.contentMode = .scaleAspectFit
        self.view.addSubview(dep_FinancialImage4)
       
    }
        
    // MARK:- TableView Datasource and Delegate Methods.
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        if ( tableView == depositeTypesTableView){
            return 45
        }
        else{
            
            return 52
        }
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        if ( tableView == depositeTypesTableView){
          return 2
        }
        else{
            
            return 10
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        // Initialize the  TableView cell
        var cell: UITableViewCell? = nil
        if ( tableView == depositeContentTableView)
        {
            let cellIdentifier: String = "\("myCell")\(Int(indexPath.row))"
            cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier)
            if cell == nil {
                cell = UITableViewCell(style: .default, reuseIdentifier: cellIdentifier)
                // depositeTextField
                if (uiTypeStr == "Text"){
                    depositeTextField = UITextField(frame: CGRect(x:10, y: 0, width:(SCREEN_WIDTH()-20), height: 44))
                    depositeTextField.placeholder = "Enter OTP number"
                    depositeTextField.textColor = UIColor.white
                    depositeTextField.keyboardType = UIKeyboardType.phonePad
                    depositeTextField.borderStyle = UITextBorderStyle.none
                    depositeTextField.backgroundColor = UIColor.clear
                    depositeTextField.delegate = self
                    depositeTextField.setValue(UIColor(red: CGFloat(68.0 / 255.0), green: CGFloat(84.0 / 255.0), blue: CGFloat(168.0 / 255.0), alpha: CGFloat(1.0)), forKeyPath: "_placeholderLabel.textColor")
                    
                    depositeTextField.inputAccessoryView = numberToolbar

                    cell?.contentView .addSubview(depositeTextField)
                    depositeDropDownBtn.isHidden = true
                    depositeTextField.isHidden = false
                }
                else if (uiTypeStr == "dropdown"){
                    // dropDown Field
                    depositeDropDownBtn = UIButton.init(type: .custom)
                    depositeDropDownBtn.frame = CGRect(x: CGFloat(10), y: CGFloat(4), width: CGFloat(SCREEN_WIDTH()-20), height: CGFloat(44))
                    depositeDropDownBtn.setTitle("Account Number", for: .normal)
                    depositeDropDownBtn.setTitleColor(UIColor.white, for: .normal)
                    depositeDropDownBtn.titleLabel?.lineBreakMode = .byTruncatingTail
                    depositeDropDownBtn.isExclusiveTouch = true
                    depositeDropDownBtn.contentHorizontalAlignment = .left
                    depositeDropDownBtn.titleEdgeInsets = UIEdgeInsetsMake(0, 30, 0, 20)
                    depositeDropDownBtn.addTarget(self, action: #selector(dropDownButtonAction(_:)), for: .touchUpInside)
                    cell?.contentView.addSubview(depositeDropDownBtn)
                    // dropDown Image
                    let imageView = UIImageView(frame: CGRect(x:(SCREEN_WIDTH()-80), y: CGFloat(24), width: CGFloat(10), height: CGFloat(5)))
                    imageView.image = UIImage(named: "bank_arrow@3x.png")
                    cell?.contentView.addSubview(imageView)
                    
                    depositeDropDownBtn.isHidden = false
                }
                // Seperator Label
                seperatorLabel = UILabel(frame: CGRect(x:10, y:44, width: (SCREEN_WIDTH()-20), height: 2))
                seperatorLabel.backgroundColor = UIColor.white
                cell?.contentView.addSubview(seperatorLabel)
            }
            tableView.separatorStyle = .none
            cell?.backgroundColor = UIColor.clear
        }
        else if(tableView == depositeTypesTableView){
            let cellIdentifier1: String = "\("dropDownCell")\(Int(indexPath.row))"
            if (depositeTypesTableView.isHidden == false)
            {
                cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier1)
                if cell == nil {
                    cell = UITableViewCell(style: .default, reuseIdentifier: cellIdentifier1)
                    cell?.textLabel?.text = "Bank"
                    tableView.separatorStyle = .singleLine
                    cell?.separatorInset = UIEdgeInsets.zero
                    cell?.backgroundColor = UIColor.clear
                 }
            }
        }
        return cell!
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        
        
        print("User selected table row \(indexPath.row))")
        
    }
    
    // MARK:- ButtonAction Methods.
    
    func backButtonAction(_ sender: UIButton) {
        print("Back button action")
        //let _ = self.navigationController?.popViewController(animated: true)
        
        let vc = DepositeViewController()
        let navi = BaseNavigationController(rootViewController: vc)
        navi.navigationBar.isTranslucent = false
        navi.isNavigationBarHidden = true
        self.present(navi, animated: true, completion: nil)
    }
    
    func checkMarkButtonAction(_ sender: UIButton) {
        sender.isSelected = !sender.isSelected
        
        if (sender.isSelected) {
            checkMarkBtn.setBackgroundImage(UIImage(named: "select_icon@3x.png"), for: .normal)
            
        }
        else{
            print("Button")
            checkMarkBtn.setBackgroundImage(UIImage(named: "select_icon_nopress@3x.png"), for: .normal)
        }
    }
    
    func nextButtonAction(_ sender: UIButton) {
        print("nextButtonAction")
        
        sender.isSelected = !sender.isSelected
        if (sender.isSelected) {
            nextBtn.setBackgroundImage(UIImage(named: "btn_press@3x.png"), for: .normal)
//            print("Button action")
//            let vc = TradingHallVC()
//            let navi = BaseNavigationController(rootViewController: vc)
//            navi.navigationBar.isTranslucent = false
//            navi.isNavigationBarHidden = true
//            self.present(navi, animated: true, completion: nil)
        }
        else{
            print("Button")
            nextBtn.setBackgroundImage(UIImage(named: "btn@3x.png"), for: .normal)
        }
    }
    
    func dropDownButtonAction(_ sender: Any)  {
        print("DropDown Action")
        depositeTypesTableView.isHidden = false
        let buttonPosition = (sender as AnyObject).convert!(CGPoint.zero, to: depositeContentTableView)
        let tappedIP: IndexPath? = depositeContentTableView.indexPathForRow(at: buttonPosition)
        let rectInTableView: CGRect = depositeContentTableView.rectForRow(at: tappedIP!)
        rectInSuperview = depositeContentTableView.convert(rectInTableView, to: depositeContentTableView.superview)
        print("Cell Y Is \(rectInSuperview.origin.y)")
        print("Cell X Is \(rectInSuperview.origin.x)")
        
        // DepositeType tableView
        depositeTypesTableView.frame = CGRect(x:(rectInSuperview.origin.x), y:(rectInSuperview.origin.y+40), width: (SCREEN_WIDTH()-40), height: (SCREEN_HEIGHT()/4))
//        depositeTypesTableView.backgroundColor = UIColor(patternImage: UIImage(named: "bg@3x.png")!)
        depositeTypesTableView.backgroundColor = UIColor.clear
        let tableBackgroundView = UIImageView(image: UIImage(named: "bg@3x.png"))
        tableBackgroundView.frame = depositeTypesTableView.frame
        depositeTypesTableView.backgroundView = tableBackgroundView
        depositeTypesTableView.delegate = self
        depositeTypesTableView.dataSource = self
        depositeTypesTableView.layoutMargins = UIEdgeInsets.zero
        depositeTypesTableView.separatorInset = UIEdgeInsets.zero
        depositeTypesTableView.register(UITableViewCell.self, forCellReuseIdentifier: "dropDownCell")
        depositeTypesTableView.layer.cornerRadius = 10
        self.view.addSubview(depositeTypesTableView)
        
        // gesture recognizer
        tapGesture = UITapGestureRecognizer(target: self, action: #selector(DepositePaymentViewController.handleTap(gestureRecognizer:)))
        tapGesture.delegate = self
        self.view.addGestureRecognizer(tapGesture)
    }
    
     // MARK:- TapGesture Method.
    func handleTap(gestureRecognizer: UIGestureRecognizer) {
        if (depositeTypesTableView.isHidden == false) {
            depositeTypesTableView.isHidden = true
        }
        
        self.view.endEditing(true)
    }
    func handleTap1(gestureRecognizer: UIGestureRecognizer) {
        self.view.endEditing(true)
        
    }
    // MARK: - UITextfieldDelegate
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        animateViewMoving(true, moveValue: 100)
    }
    func textFieldDidEndEditing(_ textField: UITextField) {
        animateViewMoving(false, moveValue: 100)
//        headersDictionary .setValue(textField.text, forKey: "\(textField.tag)")
//        print(headersDictionary)
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool
    {
        textField.resignFirstResponder()
        return true
    }
    func animateViewMoving (_ up:Bool, moveValue :CGFloat){
        let movementDuration:TimeInterval = 0.3
        let movement:CGFloat = ( up ? -moveValue : moveValue)
        UIView.beginAnimations( "animateView", context: nil)
        UIView.setAnimationBeginsFromCurrentState(true)
        UIView.setAnimationDuration(movementDuration )
        self.view.frame = self.view.frame.offsetBy(dx: 0,  dy: movement)
        UIView.commitAnimations()
    }
    
    // MARK: - Toolbar methods.
    
    func cancelNumberPad() {
        
        self.view.endEditing(true)
//        if activeField.isFirstResponder {
//            activeField.resignFirstResponder()
           activeField.text = ""
//        }
    }
    
    func doneWithNumberPad() {
//        if activeField.isFirstResponder {
//            activeField.resignFirstResponder()
//        }
        
        self.view.endEditing(true)
    }
    
    
    // MARK:- InterfAce Orientation.
    // MARK: - Device Orientation
    
    override var shouldAutorotate: Bool {
        return true
    }
    
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return .portrait
    }
    

    // MARK:- Default Memory Warning.
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
