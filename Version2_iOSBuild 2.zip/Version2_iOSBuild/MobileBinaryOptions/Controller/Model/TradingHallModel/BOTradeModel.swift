//
//  BOTradeModel.swift
//  MobileBinaryOptions
//
//  Created by Jerry song on 17/2/10.
//  Copyright © 2017年 Broctagon. All rights reserved.
//

import UIKit

class BOTradeModel: NSObject {

    
    var symbol : String = ""  // 品种名称
    var action : String = ""  // Up, Down
    var amount : String = ""  // 投资金额
    var interval : Int = 0    //结算时限，例:60秒结算
    var payout : String = ""  // 收益，例:80
    var tradeId : String = ""  // Up, Down
//    var amount : String = ""  // 投资金额
   
    
    
    
    
    
    
    
    
    
}
