//
//  FeedbackModel.swift
//  MobileBinaryOptions
//
//  Created by GE on 17/2/11.
//  Copyright © 2017年 Broctagon. All rights reserved.
//

import UIKit

class FeedbackModel: BaseModel {
    var question = ""
    var answer = ""
    var isReplied = false
    var isStar = false
    var starCount = 0   // show highlighted star count
    
}
