//
//  FeedBackVC.swift
//  MobileBinaryOptions
//
//  Created by ALOK KUMAR on 06/02/17.
//  Copyright © 2017 Broctagon. All rights reserved.
//

import UIKit

class FeedBackVC: UIPageViewController {

    var accBackGroundView = UIView()
    
    // Header Label
    var accHeaderView = UIView()
    var accManagementLabel = UILabel()
    var accManagementCancelBtn = UIButton()
    
    // Account management Page
    var profileBtn  = UIButton()
    var mt4PasswordBtn = UIButton()
    var patternlockButton = UIButton()
    
    // TextField For Profile
    var accManagementScrollview: UIScrollView!
    var numberofFields: Int = 0
    
    
    var emailaddressTextField = UITextView()
    var seperatorLabel1 = UILabel()
    var nameTextField = UITextField()
    var seperatorLabel2 = UILabel()
    var phoneTextField = UITextField()
    var seperatorLabel3 = UILabel()
    var countryTextField = UITextField()
    var seperatorLabel4 = UILabel()
    var citizenShipTextField = UITextField()
    var seperatorLabel5 = UILabel()
    var cityTextField = UITextField()
    var seperatorLabel6 = UILabel()
    var addressTextField = UITextField()
    var seperatorLabel7 = UILabel()
    
    // Submit Button
    var submitBtn = UIButton()
    
    // PageControls
    var pageControl = UIPageControl()
    
    
    // MARK:- View Initialization.
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.createUIForAccountManagement()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        //        let value = UIInterfaceOrientation.landscapeLeft.rawValue
        //        UIDevice.current.setValue(value, forKey: "orientation")
    }
    
    // MARK:- Create UI for Controls.
    func createUIForAccountManagement(){
        
        // AccountManagementBG view
        let frame = CGRect(x: CGFloat(0), y: CGFloat(0), width: SCREEN_WIDTH(), height: SCREEN_HEIGHT())
        let backgroundImage = UIImageView(frame: frame)
        backgroundImage.image = UIImage(named: "bg2.png")
        self.accBackGroundView.insertSubview(backgroundImage, at: 0)
        self.view.addSubview(self.accBackGroundView)
        
        //Header view
        accHeaderView = UIView(frame: CGRect(x: 0, y:0, width: SCREEN_WIDTH(), height: 44))
        accHeaderView.backgroundColor = UIColor.clear
        accHeaderView.backgroundColor = UIColor.init(patternImage: UIImage(named: "title_bg@3x")!)
        self.view.addSubview(accHeaderView)
        
        // Title label
        accManagementLabel = UILabel(frame: CGRect(x: 0, y:0, width: SCREEN_WIDTH(), height: 44))
        accManagementLabel.text = "FeedBack"
        accManagementLabel.textColor = UIColor.yellow
        accManagementLabel.textAlignment = .center
        accManagementLabel.font = UIFont.systemFont(ofSize: 20)
        accHeaderView.addSubview(accManagementLabel)
        
        //  cancel Button
        accManagementCancelBtn = UIButton(frame: CGRect(x: (SCREEN_WIDTH()-30), y:9, width: 25, height: 25))
        accManagementCancelBtn.setImage(UIImage(named: "close_icon@3x.png"), for: .normal)
        // accManagementCancelBtn.addTarget(self, action:#selector(self.backBtnAction), for: .touchUpInside)
        accHeaderView.addSubview(accManagementCancelBtn)
        
        // Feedback Content Button
        profileBtn = UIButton(frame: CGRect(x: (SCREEN_WIDTH()*26/100), y:64, width: ((SCREEN_WIDTH()-(SCREEN_WIDTH()*52/100))/2), height: 30))
       // profileBtn.setImage(UIImage(named: "mt4-icon@3x.png"), for: .normal)
        profileBtn.setTitle("Feedback content", for: .normal)
        profileBtn.titleEdgeInsets = UIEdgeInsetsMake(0, 10, 0, -10)
        profileBtn.titleLabel?.font = UIFont.systemFont(ofSize: 14)
        // profileBtn.addTarget(self, action:#selector(self.backBtnAction), for: .touchUpInside)
        self.view.addSubview(profileBtn)
        
        mt4PasswordBtn = UIButton(frame: CGRect(x:(profileBtn.frame.origin.x+profileBtn.frame.size.width+70), y:64, width: ((SCREEN_WIDTH()-(SCREEN_WIDTH()*52/100))/3), height: 30))
       // mt4PasswordBtn.setImage(UIImage(named: "key_icon@3x.png"), for: .normal)
        mt4PasswordBtn.setTitle("Feedback history", for: .normal)
        mt4PasswordBtn.titleLabel?.font = UIFont.systemFont(ofSize: 14)
        mt4PasswordBtn.titleEdgeInsets = UIEdgeInsetsMake(0, 0, 0, -10)
        // profileBtn.addTarget(self, action:#selector(self.backBtnAction), for: .touchUpInside)
        mt4PasswordBtn.alpha = 0.5
        self.view.addSubview(mt4PasswordBtn)
        
//        // Pattern lock Button.
//        patternlockButton = UIButton(frame: CGRect(x:(mt4PasswordBtn.frame.origin.x+mt4PasswordBtn.frame.size.width+10), y:64, width:((SCREEN_WIDTH()-(SCREEN_WIDTH()*52/100))/3), height: 30))
//        patternlockButton.setImage(UIImage(named: "lock-icon@3x.png"), for: .normal)
//        patternlockButton.setTitle("Pattern Lock", for: .normal)
//        patternlockButton.titleLabel?.font = UIFont.systemFont(ofSize: 14)
//        // profileBtn.addTarget(self, action:#selector(self.backBtnAction), for: .touchUpInside)
//        patternlockButton.alpha = 0.5
//        patternlockButton.titleEdgeInsets = UIEdgeInsetsMake(0, 0, 0, -10)
//        self.view.addSubview(patternlockButton)
        
        // ScrollView
        accManagementScrollview = UIScrollView()
        accManagementScrollview.frame = CGRect(x: CGFloat(SCREEN_WIDTH()*26/100)+20, y: CGFloat(patternlockButton.frame.size.height+patternlockButton.frame.origin.y+10), width: CGFloat(SCREEN_WIDTH()-(SCREEN_WIDTH()*52/100)), height: CGFloat(SCREEN_HEIGHT()-(accHeaderView.frame.origin.y+accHeaderView.frame.size.height+patternlockButton.frame.size.height+patternlockButton.frame.origin.y+60)))
        accManagementScrollview.backgroundColor = UIColor.clear
        accManagementScrollview.showsHorizontalScrollIndicator = false
        accManagementScrollview.alwaysBounceHorizontal = false
        accManagementScrollview.isDirectionalLockEnabled = true
        accManagementScrollview.bounces = false
        self.view.addSubview(accManagementScrollview)
        // TextField data
        // FeedbackContent Data....
//        emailaddressTextField = UITextField(frame: CGRect(x:2, y:90, width:(accManagementScrollview.frame.size.width-4), height: 44))
//        emailaddressTextField.placeholder = "Please Enter"
//        emailaddressTextField.textColor = UIColor.gray
//        emailaddressTextField.keyboardType = UIKeyboardType.emailAddress
//        emailaddressTextField.borderStyle = UITextBorderStyle.none
//        emailaddressTextField.backgroundColor = UIColor.clear
//        accManagementScrollview.addSubview(emailaddressTextField)
//        // Seperator Label
//        seperatorLabel1 = UILabel(frame: CGRect(x:0, y:(emailaddressTextField.frame.size.height+emailaddressTextField.frame.origin.y), width:accManagementScrollview.frame.size.width, height: 1))
//        seperatorLabel1.backgroundColor = UIColor.white
//        numberofFields += 1
//        accManagementScrollview.addSubview(seperatorLabel1)
        emailaddressTextField = UITextView(frame: CGRect(x:2, y:90, width: (accManagementScrollview.frame.size.width-4), height: 100 ))
        //emailaddressTextField.placeholder="Please enter"
        emailaddressTextField.textColor = UIColor.gray
        emailaddressTextField.keyboardType = UIKeyboardType.emailAddress
       // emailaddressTextField.borderStyle = UITextBorderStyle.line
        emailaddressTextField.backgroundColor = UIColor.blue
        accManagementScrollview.addSubview(emailaddressTextField)
        
        
        
        //Contact TextField
        nameTextField = UITextField(frame: CGRect(x:2, y:230, width:(accManagementScrollview.frame.size.width-4), height: 34))
        nameTextField.placeholder = "Number"
        nameTextField.textColor = UIColor.gray
        nameTextField.keyboardType = UIKeyboardType.default
        nameTextField.borderStyle = UITextBorderStyle.roundedRect
        nameTextField.backgroundColor = UIColor.white
        nameTextField.autocorrectionType = UITextAutocorrectionType.no
        nameTextField.keyboardType = UIKeyboardType.default
        nameTextField.returnKeyType = UIReturnKeyType.done
        nameTextField.clearButtonMode = UITextFieldViewMode.whileEditing;
        nameTextField.contentVerticalAlignment = UIControlContentVerticalAlignment.center
        accManagementScrollview.addSubview(nameTextField)
       
        
        
        // scrollView Content Size
        accManagementScrollview.contentSize = CGSize(width:CGFloat(SCREEN_WIDTH()-(SCREEN_WIDTH()*50/100)), height: CGFloat(46 * (numberofFields)))
        
        // Submit Btn
        submitBtn = UIButton(frame: CGRect(x:((SCREEN_WIDTH()-(SCREEN_WIDTH()*65/100))), y:(accManagementScrollview.frame.size.height+accManagementScrollview.frame.origin.y+20), width:((SCREEN_WIDTH()-(SCREEN_WIDTH()*65/100))), height: 30))
        submitBtn.setBackgroundImage(UIImage(named: "btn@3x.png"), for: .normal)
        submitBtn.setTitle("Submit", for: .normal)
        submitBtn.titleLabel?.font = UIFont.systemFont(ofSize: 14)
        // submitBtn.addTarget(self, action:#selector(self.backBtnAction), for: .touchUpInside)
        self.view.addSubview(submitBtn)
        
        // PageControl
        pageControl.frame = CGRect(x: CGFloat(SCREEN_WIDTH()/2), y: CGFloat(SCREEN_HEIGHT()-30), width: CGFloat(20), height: CGFloat(20))
        pageControl.numberOfPages = 2
        pageControl.currentPage = 0
        pageControl.pageIndicatorTintColor = UIColor.gray
        pageControl.currentPageIndicatorTintColor = UIColor.white
        self.view.addSubview(pageControl)
    }
    
    // MARK: - Device Orientation
    
    override var shouldAutorotate: Bool {
        return true
    }
    
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return .landscape
    }


    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
