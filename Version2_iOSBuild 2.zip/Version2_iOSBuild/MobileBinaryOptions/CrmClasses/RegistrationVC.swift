//
//  RegistrationVC.swift
//  MobileBinaryOptions
//
//  Created by ALOK KUMAR on 30/01/17.
//  Copyright © 2017 Broctagon. All rights reserved.
//

import UIKit

class RegistrationVC: UIViewController {
    
    var emailaddressTextField = UITextField()
    var seperatorLabel1 = UILabel()
    var nameTextField = UITextField()
    var seperatorLabel2 = UILabel()
    var phoneTextField = UITextField()
    var seperatorLabel3 = UILabel()
    var countryTextField = UITextField()
    var seperatorLabel4 = UILabel()
    var citizenShipTextField = UITextField()
    var seperatorLabel5 = UILabel()
    var cityTextField = UITextField()
    var seperatorLabel6 = UILabel()
    var addressTextField = UITextField()
    var seperatorLabel7 = UILabel()
    
    var txtpassportID = UITextField()
    var txtDOB = UITextField()
    var txtcountry = UITextField()
    var txtCode = UITextField()
    var txtphone = UITextField()
    
    let agreeBtn = BaseBtn()    /// agree check box

    var RegBtn = UIButton()

    
    var numberofFields: Int = 0
    
        //Submit Button
    var submitBtn = UIButton()
    
    var NextView = UIView()


    override func viewDidLoad() {
        super.viewDidLoad()
        
        NextView.isHidden = true
        
        
        
        let imageName = "bg@3x.png"
        let image = UIImage(named: imageName)
        let imageView = UIImageView(image: image!)
        self.view.addSubview(imageView)
        
        let WL_logo = "Starfish-Logo@3x.png"
        let Wl_image = UIImage(named: WL_logo)
        let Wl_imageView = UIImageView(image: Wl_image!)
        Wl_imageView.center = CGPoint(x: 180, y :90)
        self.view.addSubview(Wl_imageView)
        
        Wl_imageView.snp.makeConstraints { (mack) in
            mack.top.equalTo(COMPUTE_LENGTH(230))
            mack.centerX.equalTo(self.view)
            mack.width.equalTo(COMPUTE_LENGTH(665))
            mack.height.equalTo(COMPUTE_LENGTH(211))
        }
        
        let lblLogin = UILabel(frame: CGRect(x: 0, y: 0, width: 200, height: 40))
        lblLogin.center = CGPoint(x: 160, y: 170)
        lblLogin.textAlignment = .center
        lblLogin.text = "Register Live Account"
        lblLogin.adjustsFontSizeToFitWidth=true
        lblLogin.font = UIFont(name:lblLogin.font.fontName,size :25)
        lblLogin.textColor = UIColor.yellow
        lblLogin.alpha = 0.8
        self.view.addSubview(lblLogin)
        lblLogin.snp.makeConstraints { (mack) in
            mack.top.equalTo(Wl_imageView.snp.bottom).offset(COMPUTE_LENGTH(72))
            mack.centerX.equalTo(self.view)
        }


        
        let lbl_version = UILabel.init()
        //        let lbl_version = UILabel(frame: CGRect(x:((SCREEN_WIDTH()*10/100)+120), y: 20, width: 200, height: 21))
        //lbl_version.center = CGPoint(x: 300, y: 40)
        lbl_version.textAlignment = .center
        lbl_version.text = "Version:0.0.0"
        lbl_version.textColor = kColorTimeframeNormal()
        lbl_version.font = UIFont.systemFont(ofSize: 12)
        self.view.addSubview(lbl_version)
        lbl_version.snp.makeConstraints { (mack) in
            mack.top.equalTo(COMPUTE_LENGTH(110))
            mack.left.equalTo(self.view.snp.right).offset(-COMPUTE_LENGTH(300))
        }
        
        // back_icon
        let img_Btnlang = UIImage(named: "back_icon@3x") as UIImage?
        let btn_Lang = UIButton(frame: CGRect(x: 10 ,y:30, width: COMPUTE_LENGTH(180), height:COMPUTE_LENGTH(68)))
        btn_Lang.backgroundColor = UIColor.clear
        btn_Lang.addTarget(self, action: #selector(regiBack1(btn:)), for: .touchUpInside)
        //        btn_Lang.setBackgroundImage(img_Btnlang, for: .normal)
        btn_Lang.setImage(img_Btnlang, for: .normal)
        
        self.view.addSubview(btn_Lang)
        
//        let lblLogin = UILabel(frame: CGRect(x: 0, y: 0, width: 200, height: 40))
//        lblLogin.center = CGPoint(x: 160, y: 170)
//        lblLogin.textAlignment = .center
//        lblLogin.text = "Login"
//        lblLogin.adjustsFontSizeToFitWidth=true
//        lblLogin.font = UIFont(name:lblLogin.font.fontName,size :25)
//        //        lblLogin.numberOfLines = 8
//        self.view.addSubview(lblLogin)
//        
//        // Input fileds and Login Button........
//        
//        let txtUserName = UITextField(frame: CGRect(x: 40, y: 230, width: 300, height: 40))
//        txtUserName.placeholder = "Email Address"
//        txtUserName.font = UIFont.systemFont(ofSize: 15)
//        txtUserName.borderStyle = UITextBorderStyle.roundedRect
//        txtUserName.autocorrectionType = UITextAutocorrectionType.no
//        txtUserName.keyboardType = UIKeyboardType.default
//        txtUserName.returnKeyType = UIReturnKeyType.done
//        txtUserName.clearButtonMode = UITextFieldViewMode.whileEditing;
//        txtUserName.contentVerticalAlignment = UIControlContentVerticalAlignment.center
//        self.view.addSubview(txtUserName)
//        
//        let txtPassword = UITextField(frame: CGRect(x: 40, y: 280, width: 300, height: 40))
//        txtPassword.placeholder = "Password"
//        txtPassword.font = UIFont.systemFont(ofSize: 15)
//        txtPassword.borderStyle = UITextBorderStyle.roundedRect
//        txtPassword.autocorrectionType = UITextAutocorrectionType.no
//        txtPassword.keyboardType = UIKeyboardType.default
//        txtPassword.returnKeyType = UIReturnKeyType.done
//        txtPassword.clearButtonMode = UITextFieldViewMode.whileEditing;
//        txtPassword.contentVerticalAlignment = UIControlContentVerticalAlignment.center
//        self.view.addSubview(txtPassword)
//        
//        
//        let img_Btnlogin = UIImage(named: "btn@3x") as UIImage?
//        let btnlogin = UIButton(frame: CGRect(x: 40 ,y:370, width: 290, height:50))
//        btnlogin.backgroundColor = UIColor.clear
//       // btnlogin.addTarget(self, action: #selector(loginAction(btn:)), for: .touchUpInside)
//        btnlogin.setBackgroundImage(img_Btnlogin, for: .normal)
//        btnlogin.setTitle("Login", for: .normal)
//        
//        self.view.addSubview(btnlogin)
//        
//        let lblreginfo = UILabel(frame: CGRect(x: 0, y: 0, width: 200, height: 21))
//        lblreginfo.center = CGPoint(x: 180, y: 450)
//        lblreginfo.textAlignment = .center
//        lblreginfo.text = "If you don't have account go and Register"
//        lblreginfo.adjustsFontSizeToFitWidth=true
//        lblreginfo.font = UIFont(name:lblreginfo.font.fontName,size :15)
//        lblreginfo.numberOfLines = 8
//        self.view.addSubview(lblreginfo)
//        
//        let btnForgotPass = UIButton(frame: CGRect(x: 40 ,y:480, width: 290, height:50))
//        btnForgotPass.backgroundColor = UIColor.clear
//       // btnForgotPass.addTarget(self, action: #selector(ForgotPass(btn:)), for: .touchUpInside)
//        //        btn_Lang.setBackgroundImage(img_Btnlang, for: .normal)
//        //btnForgotPass.setImage(img_Btnlogin, for: .normal)
//        btnForgotPass.setTitle("Forgot Password?", for: UIControlState.normal)
//        self.view.addSubview(btnForgotPass)
//        
        // TextField data
        // Email
        if(SCREEN_WIDTH() <= 320)
        {
        emailaddressTextField = UITextField(frame: CGRect(x:30, y:180, width:290, height: 44))
        }
        else
        {
            emailaddressTextField = UITextField(frame: CGRect(x:40, y:180, width:290, height: 44))
        }
        emailaddressTextField.placeholder = "Name"
        emailaddressTextField.textColor = UIColor.white
        emailaddressTextField.keyboardType = UIKeyboardType.emailAddress
        emailaddressTextField.borderStyle = UITextBorderStyle.none
        emailaddressTextField.backgroundColor = UIColor.clear
        self.view.addSubview(emailaddressTextField)
        // Seperator Label
        if(SCREEN_WIDTH() <= 320)
        {
        seperatorLabel1 = UILabel(frame: CGRect(x:30, y:(emailaddressTextField.frame.size.height+emailaddressTextField.frame.origin.y), width:260, height: 1))
        }
        else
        {
            seperatorLabel1 = UILabel(frame: CGRect(x:40, y:(emailaddressTextField.frame.size.height+emailaddressTextField.frame.origin.y), width:290, height: 1))
        }
        seperatorLabel1.backgroundColor = UIColor.white
        numberofFields += 1
        self.view.addSubview(seperatorLabel1)
        
        //Name TextField
        if(SCREEN_WIDTH() <= 320)
        {
        nameTextField = UITextField(frame: CGRect(x:30, y:(seperatorLabel1.frame.size.height+seperatorLabel1.frame.origin.y), width:290, height: 44))
        }
        else
        {
            nameTextField = UITextField(frame: CGRect(x:40, y:(seperatorLabel1.frame.size.height+seperatorLabel1.frame.origin.y), width:290, height: 44))
        }
        nameTextField.placeholder = "Email "
        nameTextField.textColor = UIColor.white
        nameTextField.keyboardType = UIKeyboardType.default
        nameTextField.borderStyle = UITextBorderStyle.none
        nameTextField.backgroundColor = UIColor.clear
        self.view.addSubview(nameTextField)
        // Seperator Label
        if(SCREEN_WIDTH() <= 320)
        {

        seperatorLabel2 = UILabel(frame: CGRect(x:30, y:(nameTextField.frame.size.height+nameTextField.frame.origin.y), width:260, height: 1))
        }
        else
        {
            seperatorLabel2 = UILabel(frame: CGRect(x:40, y:(nameTextField.frame.size.height+nameTextField.frame.origin.y), width:290, height: 1))
        }
        seperatorLabel2.backgroundColor = UIColor.white
        numberofFields += 1
        self.view.addSubview(seperatorLabel2)
        
        //Phone TextField
//        phoneTextField = UITextField(frame: CGRect(x:30, y:(seperatorLabel2.frame.size.height+seperatorLabel2.frame.origin.y), width:290, height: 44))
        if(SCREEN_WIDTH() <= 320)
        {
            phoneTextField = UITextField(frame: CGRect(x:30, y:(seperatorLabel2.frame.size.height+seperatorLabel2.frame.origin.y), width:290, height: 44))
        }
        else
        {
            phoneTextField = UITextField(frame: CGRect(x:40, y:(seperatorLabel2.frame.size.height+seperatorLabel2.frame.origin.y), width:290, height: 44))
        }
        phoneTextField.placeholder = "Password"
        phoneTextField.textColor = UIColor.white
        phoneTextField.keyboardType = UIKeyboardType.phonePad
        phoneTextField.borderStyle = UITextBorderStyle.none
        phoneTextField.backgroundColor = UIColor.clear
        self.view.addSubview(phoneTextField)
        // Seperator Label
        if(SCREEN_WIDTH() <= 320)
        {
            
            seperatorLabel3 = UILabel(frame: CGRect(x:30, y:(phoneTextField.frame.size.height+phoneTextField.frame.origin.y), width:260, height: 1))
        }
        else
        {
            seperatorLabel3 = UILabel(frame: CGRect(x:40, y:(phoneTextField.frame.size.height+phoneTextField.frame.origin.y), width:290, height: 1))
        }
        seperatorLabel3.backgroundColor = UIColor.white
        numberofFields += 1
        self.view.addSubview(seperatorLabel3)
        
        //Country TextField
        if(SCREEN_WIDTH() <= 320)
        {
        countryTextField = UITextField(frame: CGRect(x:30, y:(seperatorLabel3.frame.size.height+seperatorLabel3.frame.origin.y), width:290, height: 44))
        }
        else{
             countryTextField = UITextField(frame: CGRect(x:40, y:(seperatorLabel3.frame.size.height+seperatorLabel3.frame.origin.y), width:290, height: 44))
        }
        countryTextField.placeholder = "Confirm Password"
        countryTextField.textColor = UIColor.white
        countryTextField.keyboardType = UIKeyboardType.default
        countryTextField.borderStyle = UITextBorderStyle.none
        countryTextField.backgroundColor = UIColor.clear
        self.view.addSubview(countryTextField)
        // Seperator Label
        if(SCREEN_WIDTH() <= 320)
        {
            
            seperatorLabel4 = UILabel(frame: CGRect(x:30, y:(countryTextField.frame.size.height+countryTextField.frame.origin.y), width:260, height: 1))
        }
        else
        {
            seperatorLabel4 = UILabel(frame: CGRect(x:40, y:(countryTextField.frame.size.height+countryTextField.frame.origin.y), width:290, height: 1))
        }
        seperatorLabel4.backgroundColor = UIColor.white
        numberofFields += 1
        self.view.addSubview(seperatorLabel4)
        
        //CityzenShip TextField
//        citizenShipTextField = UITextField(frame: CGRect(x:30, y:(seperatorLabel4.frame.size.height+seperatorLabel4.frame.origin.y), width:290, height: 44))
        if(SCREEN_WIDTH() <= 320)
        {
            citizenShipTextField = UITextField(frame: CGRect(x:30, y:(seperatorLabel4.frame.size.height+seperatorLabel4.frame.origin.y), width:290, height: 44))
        }
        else{
            citizenShipTextField = UITextField(frame: CGRect(x:40, y:(seperatorLabel4.frame.size.height+seperatorLabel4.frame.origin.y), width:290, height: 44))
        }
        citizenShipTextField.placeholder = "PromoCode"
        citizenShipTextField.autocorrectionType = .no
        citizenShipTextField.autocapitalizationType = .none
        citizenShipTextField.textColor = UIColor.white
        citizenShipTextField.keyboardType = UIKeyboardType.default
        citizenShipTextField.borderStyle = UITextBorderStyle.none
        citizenShipTextField.backgroundColor = UIColor.clear
        self.view.addSubview(citizenShipTextField)
        // Seperator Label
        if(SCREEN_WIDTH() <= 320)
        {
            
            seperatorLabel5 = UILabel(frame: CGRect(x:30, y:(citizenShipTextField.frame.size.height+citizenShipTextField.frame.origin.y), width:260, height: 1))
        }
        else
        {
            seperatorLabel5 = UILabel(frame: CGRect(x:40, y:(citizenShipTextField.frame.size.height+citizenShipTextField.frame.origin.y), width:290, height: 1))
        }
        seperatorLabel5.backgroundColor = UIColor.white
        numberofFields += 1
        self.view.addSubview(seperatorLabel5)
        
        // Submit Btn
//        submitBtn = UIButton(frame: CGRect(x: 140, y: 530, width:((SCREEN_WIDTH()-(SCREEN_WIDTH()*65/100))), height: 30))
//        submitBtn.setBackgroundImage(UIImage(named: "btn@3x.png"), for: .normal)
//        submitBtn.setTitle("Next", for: .normal)
//        submitBtn.titleLabel?.font = UIFont.systemFont(ofSize: 14)
        // submitBtn.addTarget(self, action:#selector(self.backBtnAction), for: .touchUpInside)
        let submitBtn = UIButton.init(type: .custom)
        submitBtn.setTitle("Next", for: .normal)
        submitBtn.setTitleColor(kColorDouble(), for: .highlighted)
        submitBtn.setTitleColor(UIColor.white, for: .normal)
        submitBtn.setBackgroundImage(UIImage.init(named: "btn"), for: .normal)
        submitBtn.setBackgroundImage(UIImage.init(named: "btn_press"), for: .highlighted)
        submitBtn.addTarget(self, action: #selector(loginAction(btn:)), for: .touchUpInside)
        self.view.addSubview(submitBtn)
        submitBtn.snp.makeConstraints { (mack) in
            mack.top.equalTo(citizenShipTextField.snp.bottom).offset(COMPUTE_LENGTH(72))
            mack.centerX.equalTo(self.view)
        }

        
        
        
        // Bottom images
        let imageName1 = "FV-logo@3x.png"
        let image1 = UIImage(named: imageName1)
        let imageView1 = UIImageView(image: image1!)
        imageView1.center = CGPoint(x: 50, y :630)
        self.view.addSubview(imageView1)
        
        imageView1.snp.makeConstraints { (mack) in
            mack.left.equalTo(COMPUTE_LENGTH(77))
            mack.width.equalTo(COMPUTE_LENGTH(214))
            mack.height.equalTo(COMPUTE_LENGTH(127))
            mack.bottom.equalTo(self.view.snp.bottom).offset(-COMPUTE_LENGTH(99))
        }

        
        let imageName2 = "Finance-Review-Logo@3x.png"
        let image2 = UIImage(named: imageName2)
        let imageView2 = UIImageView(image: image2!)
        imageView2.center = CGPoint(x: 150, y :630)
        self.view.addSubview(imageView2)
        
        imageView2.snp.makeConstraints { (mack) in
            mack.left.equalTo(imageView1.snp.right).offset(COMPUTE_LENGTH(48))
            mack.width.equalTo(COMPUTE_LENGTH(243))
            mack.height.equalTo(COMPUTE_LENGTH(64))
            mack.bottom.equalTo(imageView1.snp.bottom).offset(-COMPUTE_LENGTH(25))
            
        }

        
        let imageName3 = "Best--Trading"
        let image3 = UIImage(named: imageName3)
        let imageView3 = UIImageView(image: image3!)
        imageView3.center = CGPoint(x: 230, y :630)
        self.view.addSubview(imageView3)
        
        imageView3.snp.makeConstraints { (mack) in
            mack.left.equalTo(imageView2.snp.right).offset(COMPUTE_LENGTH(68))
            mack.width.equalTo(COMPUTE_LENGTH(130))
            mack.height.equalTo(COMPUTE_LENGTH(127))
            mack.bottom.equalTo(imageView1)
        }
        
        let imageName4 = "Best-Binary-Logo@3x.png"
        let image4 = UIImage(named: imageName4)
        let imageView4 = UIImageView(image: image4!)
        imageView4.center = CGPoint(x: 310, y :630)
        self.view.addSubview(imageView4)
        
        imageView4.snp.makeConstraints { (mack) in
            mack.left.equalTo(imageView3.snp.right).offset(COMPUTE_LENGTH(58))
            mack.width.equalTo(COMPUTE_LENGTH(304))
            mack.height.equalTo(COMPUTE_LENGTH(111))
            mack.bottom.equalTo(imageView1.snp.bottom).offset(COMPUTE_LENGTH(10))
        }
        
        
        
    }

    func addHeaderViewForFeedBack()
    {
        
        NextView=UIView(frame: CGRect(x:0, y:0,width: SCREEN_WIDTH(),height: SCREEN_HEIGHT()))
        let imageName = "bg.png"
        let image = UIImage(named: imageName)
        let imageView = UIImageView(image: image!)
        self.NextView.insertSubview(imageView, at: 0)
        self.view.addSubview(NextView)

        self.view.addSubview(NextView)
        
//        let imageName = "bg@3x.png"
//        let image = UIImage(named: imageName)
//        let imageView = UIImageView(image: image!)
        self.NextView.addSubview(imageView)
        
        let WL_logo = "Starfish-Logo.png"
        let Wl_image = UIImage(named: WL_logo)
        let Wl_imageView = UIImageView(image: Wl_image!)
        Wl_imageView.center = CGPoint(x: 180, y :90)
        self.NextView.addSubview(Wl_imageView)
        
        Wl_imageView.snp.makeConstraints { (mack) in
            mack.top.equalTo(COMPUTE_LENGTH(230))
            mack.centerX.equalTo(self.NextView)
            mack.width.equalTo(COMPUTE_LENGTH(665))
            mack.height.equalTo(COMPUTE_LENGTH(211))
        }
        
        let lblLogin = UILabel(frame: CGRect(x: 0, y: 0, width: 200, height: 40))
        lblLogin.center = CGPoint(x: 160, y: 170)
        lblLogin.textAlignment = .center
        lblLogin.text = LString(key: "Register Live Account")
        lblLogin.adjustsFontSizeToFitWidth=true
        lblLogin.font = UIFont(name:lblLogin.font.fontName,size :25)
        lblLogin.textColor = UIColor.yellow
        lblLogin.alpha = 0.8
        self.view.addSubview(lblLogin)
        lblLogin.snp.makeConstraints { (mack) in
            mack.top.equalTo(Wl_imageView.snp.bottom).offset(COMPUTE_LENGTH(72))
            mack.centerX.equalTo(self.view)
        }
        
        
        
        let lbl_version = UILabel.init()
        //        let lbl_version = UILabel(frame: CGRect(x:((SCREEN_WIDTH()*10/100)+120), y: 20, width: 200, height: 21))
        //lbl_version.center = CGPoint(x: 300, y: 40)
        lbl_version.textAlignment = .center
        let versionStr = LString(key: "Version") + ": " + "0.0.0"
        lbl_version.text = versionStr
        lbl_version.textColor = kColorTimeframeNormal()
        lbl_version.font = UIFont.systemFont(ofSize: 12)
        self.view.addSubview(lbl_version)
        lbl_version.snp.makeConstraints { (mack) in
            mack.top.equalTo(COMPUTE_LENGTH(110))
            mack.left.equalTo(self.view.snp.right).offset(-COMPUTE_LENGTH(300))
        }
        
        // back_icon
        let img_Btnlang = UIImage(named: "back_icon.png") as UIImage?
        let btn_Lang = UIButton(frame: CGRect(x: 10 ,y:30, width: COMPUTE_LENGTH(180), height:COMPUTE_LENGTH(68)))
        btn_Lang.backgroundColor = UIColor.clear
          btn_Lang.addTarget(self, action: #selector(registerBack(btn:)), for: .touchUpInside)
        //        btn_Lang.setBackgroundImage(img_Btnlang, for: .normal)
        btn_Lang.setImage(img_Btnlang, for: .normal)
        self.view.addSubview(btn_Lang)
        
        // Email
//        txtpassportID = UITextField(frame: CGRect(x:30, y:180, width:290, height: 44))
        if(SCREEN_WIDTH() <= 320)
        {
            txtpassportID = UITextField(frame: CGRect(x:30, y:180, width:290, height: 44))
        }
        else
        {
            txtpassportID = UITextField(frame: CGRect(x:40, y:180, width:290, height: 44))
        }

        txtpassportID.placeholder = LString(key: "Passport ID")
        txtpassportID.textColor = UIColor.white
        txtpassportID.keyboardType = UIKeyboardType.emailAddress
        txtpassportID.borderStyle = UITextBorderStyle.none
        txtpassportID.backgroundColor = UIColor.clear
        self.view.addSubview(txtpassportID)
        // Seperator Label
        if(SCREEN_WIDTH() <= 320)
        {
        seperatorLabel1 = UILabel(frame: CGRect(x:30, y:(txtpassportID.frame.size.height+txtpassportID.frame.origin.y), width:260, height: 1))
        }
        else{
            seperatorLabel1 = UILabel(frame: CGRect(x:40, y:(txtpassportID.frame.size.height+txtpassportID.frame.origin.y), width:290, height: 1))
        }
        seperatorLabel1.backgroundColor = UIColor.white
        numberofFields += 1
        self.view.addSubview(seperatorLabel1)
        
        //Name TextField
//        txtDOB = UITextField(frame: CGRect(x:30, y:(seperatorLabel1.frame.size.height+seperatorLabel1.frame.origin.y), width:290, height: 44))
        if(SCREEN_WIDTH() <= 320)
        {
            txtDOB = UITextField(frame: CGRect(x:30, y:(seperatorLabel1.frame.size.height+seperatorLabel1.frame.origin.y), width:290, height: 44))
        }
        else
        {
            txtDOB = UITextField(frame: CGRect(x:40, y:(seperatorLabel1.frame.size.height+seperatorLabel1.frame.origin.y), width:290, height: 44))
        }
        txtDOB.placeholder = LString(key: "Date Of Birth")
        txtDOB.textColor = UIColor.white
        txtDOB.keyboardType = UIKeyboardType.default
        txtDOB.borderStyle = UITextBorderStyle.none
        txtDOB.backgroundColor = UIColor.clear
        self.view.addSubview(txtDOB)
        // Seperator Label
        if(SCREEN_WIDTH() <= 320)
        {
        seperatorLabel2 = UILabel(frame: CGRect(x:30, y:(txtDOB.frame.size.height+txtDOB.frame.origin.y), width:260, height: 1))
        }
        else{
            seperatorLabel2 = UILabel(frame: CGRect(x:40, y:(txtDOB.frame.size.height+txtDOB.frame.origin.y), width:290, height: 1))
        }
        seperatorLabel2.backgroundColor = UIColor.white
        numberofFields += 1
        self.view.addSubview(seperatorLabel2)
        
        //Phone TextField
//        txtcountry = UITextField(frame: CGRect(x:30, y:(seperatorLabel2.frame.size.height+seperatorLabel2.frame.origin.y), width:290, height: 44))
        if(SCREEN_WIDTH() <= 320)
        {
            txtcountry = UITextField(frame: CGRect(x:30, y:(seperatorLabel2.frame.size.height+seperatorLabel2.frame.origin.y), width:290, height: 44))
        }
        else
        {
            txtcountry = UITextField(frame: CGRect(x:40, y:(seperatorLabel2.frame.size.height+seperatorLabel2.frame.origin.y), width:290, height: 44))
        }
        txtcountry.placeholder = LString(key: "Country")
        txtcountry.textColor = UIColor.white
        txtcountry.keyboardType = UIKeyboardType.phonePad
        txtcountry.borderStyle = UITextBorderStyle.none
        txtcountry.backgroundColor = UIColor.clear
        self.view.addSubview(txtcountry)
        // Seperator Label
        if(SCREEN_WIDTH() <= 320)
        {
        seperatorLabel3 = UILabel(frame: CGRect(x:30, y:(txtcountry.frame.size.height+txtcountry.frame.origin.y), width:260, height: 1))
        }
        else
        {
            seperatorLabel3 = UILabel(frame: CGRect(x:40, y:(txtcountry.frame.size.height+txtcountry.frame.origin.y), width:290, height: 1))
        }
        seperatorLabel3.backgroundColor = UIColor.white
        numberofFields += 1
        self.view.addSubview(seperatorLabel3)
        
        //Country TextField
        self.txtCode = UITextField(frame: CGRect(x:self.txtcountry.left, y:self.seperatorLabel3.bottom, width:60, height: txtcountry.height))
        
        txtCode.placeholder = "+86"
        txtCode.textColor = UIColor.white
        txtCode.keyboardType = UIKeyboardType.default
        txtCode.borderStyle = UITextBorderStyle.none
        txtCode.backgroundColor = UIColor.clear
        self.view.addSubview(txtCode)
        
        // Seperator Label
        self.seperatorLabel4 = UILabel(frame: CGRect(x:self.txtCode.left, y:self.txtCode.bottom, width:self.txtCode.width, height: 1))
        seperatorLabel4.backgroundColor = UIColor.white
        numberofFields += 1
        self.view.addSubview(seperatorLabel4)
        
        //CityzenShip TextField
        self.txtphone = UITextField(frame: CGRect(x:self.txtCode.right+10, y:self.txtCode.top, width:self.view.width - self.txtCode.right - 10 - self.txtCode.left, height: self.txtCode.height))
        txtphone.placeholder = LString(key: "Phone")
        txtphone.autocorrectionType = .no
        txtphone.autocapitalizationType = .none
        txtphone.textColor = UIColor.white
        txtphone.keyboardType = UIKeyboardType.default
        txtphone.borderStyle = UITextBorderStyle.none
        txtphone.backgroundColor = UIColor.clear
        self.view.addSubview(txtphone)
        
        // Seperator Label
        self.seperatorLabel5 = UILabel(frame: CGRect(x:self.txtphone.left, y:self.txtphone.bottom, width:self.txtphone.width, height: 1))
        seperatorLabel5.backgroundColor = UIColor.white
//        numberofFields += 1   /// same row as seperatorLabel4
        self.view.addSubview(seperatorLabel5)
        
        
        /// agree check box
        self.agreeBtn.frame = CGRect(x: self.txtCode.left+5, y: self.txtCode.bottom+10, width: 30, height: 30)
        let inset = (30 - COMPUTE_LENGTH(44.0)) / 2.0
        self.agreeBtn.imageEdgeInsets = UIEdgeInsetsMake(inset, inset, inset, inset)
        self.agreeBtn.setImage(UIImage(named: "checkBox_normal.png"), for: .normal)
        self.agreeBtn.setImage(UIImage(named: "checkBox_selected.png"), for: .selected)
        self.agreeBtn.addTarget(self, action: #selector(agreeTheTermsOfServices(btn:)), for: .touchUpInside)
        self.view.addSubview(self.agreeBtn)
        
        /// agreeDetailsLb
        let agreeDetailsLb = UILabel(frame: CGRect(x: self.agreeBtn.right, y: self.agreeBtn.top+inset, width: self.txtphone.right-self.agreeBtn.right-5, height: 20))
        agreeDetailsLb.numberOfLines = 0
        self.view.addSubview(agreeDetailsLb)
        
        let protocolStr = LString(key: "The terms of Services")
        let detailsStr = LString(key: LString(key: "I have read,understood and accept") + " " + protocolStr)
        let attributes = [NSFontAttributeName: FONT_CUSTOM(10.0), NSForegroundColorAttributeName: UIColor.white]
        let detailsAttributedStr = NSMutableAttributedString(string: detailsStr, attributes: attributes)
        detailsAttributedStr.setAttributes([NSFontAttributeName: FONT_CUSTOM(10.0), NSForegroundColorAttributeName: kColorTimeframeSelected(), NSUnderlineStyleAttributeName: 1, NSLinkAttributeName: "show protocol"], range: NSMakeRange(detailsStr.characters.count-protocolStr.characters.count, protocolStr.characters.count))
        agreeDetailsLb.attributedText = detailsAttributedStr
        agreeDetailsLb.sizeToFit()
        agreeDetailsLb.width = self.txtphone.right-self.agreeBtn.right-5

        // Bottom images
        let imageName1 = "FV-logo.png"
        let image1 = UIImage(named: imageName1)
        let imageView1 = UIImageView(image: image1!)
        imageView1.center = CGPoint(x: 50, y :630)
        self.view.addSubview(imageView1)
        
        imageView1.snp.makeConstraints { (mack) in
            mack.left.equalTo(COMPUTE_LENGTH(77))
            mack.width.equalTo(COMPUTE_LENGTH(214))
            mack.height.equalTo(COMPUTE_LENGTH(127))
            mack.bottom.equalTo(self.view.snp.bottom).offset(-COMPUTE_LENGTH(99))
        }
        
        
        let imageName2 = "Finance-Review-Logo.png"
        let image2 = UIImage(named: imageName2)
        let imageView2 = UIImageView(image: image2!)
        imageView2.center = CGPoint(x: 150, y :630)
        self.view.addSubview(imageView2)
        
        imageView2.snp.makeConstraints { (mack) in
            mack.left.equalTo(imageView1.snp.right).offset(COMPUTE_LENGTH(48))
            mack.width.equalTo(COMPUTE_LENGTH(243))
            mack.height.equalTo(COMPUTE_LENGTH(64))
            mack.bottom.equalTo(imageView1.snp.bottom).offset(-COMPUTE_LENGTH(25))
            
        }
        
        
        let imageName3 = "Best--Trading"
        let image3 = UIImage(named: imageName3)
        let imageView3 = UIImageView(image: image3!)
        imageView3.center = CGPoint(x: 230, y :630)
        self.view.addSubview(imageView3)
        
        imageView3.snp.makeConstraints { (mack) in
            mack.left.equalTo(imageView2.snp.right).offset(COMPUTE_LENGTH(68))
            mack.width.equalTo(COMPUTE_LENGTH(130))
            mack.height.equalTo(COMPUTE_LENGTH(127))
            mack.bottom.equalTo(imageView1)
        }
        
        let imageName4 = "Best-Binary-Logo@3x.png"
        let image4 = UIImage(named: imageName4)
        let imageView4 = UIImageView(image: image4!)
        imageView4.center = CGPoint(x: 310, y :630)
        self.view.addSubview(imageView4)
        
        imageView4.snp.makeConstraints { (mack) in
            mack.left.equalTo(imageView3.snp.right).offset(COMPUTE_LENGTH(58))
            mack.width.equalTo(COMPUTE_LENGTH(304))
            mack.height.equalTo(COMPUTE_LENGTH(111))
            mack.bottom.equalTo(imageView1.snp.bottom).offset(COMPUTE_LENGTH(10))
        }

        RegBtn = UIButton.init(type: .custom)
        RegBtn.setTitle("Register", for: .normal)
        RegBtn.setTitleColor(kColorDouble(), for: .highlighted)
        RegBtn.setTitleColor(UIColor.white, for: .normal)
        RegBtn.setBackgroundImage(UIImage.init(named: "btn"), for: .normal)
        RegBtn.setBackgroundImage(UIImage.init(named: "btn_press"), for: .highlighted)
        RegBtn.addTarget(self, action: #selector(registerAction(btn:)), for: .touchUpInside)
        self.view.addSubview(RegBtn)
        RegBtn.snp.makeConstraints { (mack) in
            mack.top.equalTo(citizenShipTextField.snp.bottom).offset(COMPUTE_LENGTH(72))
            mack.centerX.equalTo(self.view)
        }

        
    }
    
    // MARK :- Button Actions 
    
    func agreeTheTermsOfServices(btn: UIButton) {
        btn.isSelected = !btn.isSelected
    }
    
    func regiBack1(btn:UIButton!)  {
        let _ = self.navigationController?.popViewController(animated: false)
    }
    
    func registerBack(btn:UIButton!)  {
        print("registerBack")
        NextView.isHidden = true
        txtpassportID.isHidden = true
        txtDOB.isHidden = true
        txtcountry.isHidden = true
        txtCode.isHidden = true
        txtphone.isHidden = true
        RegBtn.isHidden = true
    }
    
    func loginAction(btn:UIButton!)  {
        print("Hello Next view")
      //  NextView.isHidden = false
        self.addHeaderViewForFeedBack()
        
    }
    func registerAction(btn:UIButton!)  {
        print("HelloRegister")
        //  NextView.isHidden = false
        let _ = self.navigationController?.popViewController(animated: false)
    }


    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
