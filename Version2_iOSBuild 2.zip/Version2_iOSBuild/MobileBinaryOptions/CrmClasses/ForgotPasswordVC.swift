//
//  ForgotPasswordVC.swift
//  MobileBinaryOptions
//
//  Created by ALOK KUMAR on 30/01/17.
//  Copyright © 2017 Broctagon. All rights reserved.
//

import UIKit
import SnapKit

class ForgotPasswordVC: UIViewController {
    
    var seperatorLabel2 = UILabel()
    var numberofFields: Int = 0
    var btnCancel = UIButton()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let imageName = "bg@3x.png"
        let image = UIImage(named: imageName)
        let imageView = UIImageView(image: image!)
        self.view.addSubview(imageView)
        
        let WL_logo = "Starfish-Logo"
        let Wl_image = UIImage(named: WL_logo)
        let Wl_imageView = UIImageView(image: Wl_image!)
        //        Wl_imageView.center = CGPoint(x: ((SCREEN_WIDTH()*45/100)+14), y :120)
        self.view.addSubview(Wl_imageView)
        Wl_imageView.snp.makeConstraints { (mack) in
            mack.top.equalTo(COMPUTE_LENGTH(230))
            mack.centerX.equalTo(self.view)
            mack.width.equalTo(COMPUTE_LENGTH(665))
            mack.height.equalTo(COMPUTE_LENGTH(211))
        }
        
        
        //        let lbl_version = UILabel(frame: CGRect(x: 0, y: 0, width: 200, height: 21))
        //        lbl_version.center = CGPoint(x: 300, y: 35)
        //        lbl_version.textAlignment = .center
        //        lbl_version.text = "Version: 0.0.0"
        //        self.view.addSubview(lbl_version)
        
        let lbl_version = UILabel.init()
        //        let lbl_version = UILabel(frame: CGRect(x:((SCREEN_WIDTH()*10/100)+120), y: 20, width: 200, height: 21))
        //lbl_version.center = CGPoint(x: 300, y: 40)
        lbl_version.textAlignment = .center
        lbl_version.text = "Version:0.0.0"
        lbl_version.textColor = kColorTimeframeNormal()
        lbl_version.font = UIFont.systemFont(ofSize: 12)
        self.view.addSubview(lbl_version)
        lbl_version.snp.makeConstraints { (mack) in
            mack.top.equalTo(COMPUTE_LENGTH(110))
            mack.left.equalTo(self.view.snp.right).offset(-COMPUTE_LENGTH(300))
        }
        // back_icon
        let img_Btnlang = UIImage(named: "back_icon") as UIImage?
        let btn_Lang = UIButton(frame: CGRect(x: 10 ,y:30, width: COMPUTE_LENGTH(180), height:COMPUTE_LENGTH(68)))
        btn_Lang.backgroundColor = UIColor.clear
        btn_Lang.addTarget(self, action: #selector(loginBack(btn:)), for: .touchUpInside)
        //        btn_Lang.setBackgroundImage(img_Btnlang, for: .normal)
        btn_Lang.setImage(img_Btnlang, for: .normal)
        
        self.view.addSubview(btn_Lang)
        
        
        let lblreginfo = UILabel(frame: CGRect(x: 0, y: 0, width: 200, height: 21))
        lblreginfo.center = CGPoint(x: 130, y: 230)
        lblreginfo.textAlignment = .center
        lblreginfo.text = "Please Enter Your Email-Id:"
        lblreginfo.textColor = UIColor.white
        lblreginfo.alpha = 0.8
        lblreginfo.adjustsFontSizeToFitWidth=true
        lblreginfo.font = UIFont(name:lblreginfo.font.fontName,size :15)
        lblreginfo.numberOfLines = 8
        self.view.addSubview(lblreginfo)

        let lblLogin = UILabel(frame: CGRect(x: 0, y: 0, width: 200, height: 40))
        lblLogin.center = CGPoint(x: 160, y: 170)
        lblLogin.textAlignment = .center
        lblLogin.text = "Forgot Password"
        lblLogin.adjustsFontSizeToFitWidth=true
        lblLogin.font = UIFont(name:lblLogin.font.fontName,size :25)
        lblLogin.textColor = UIColor.yellow
        lblLogin.alpha = 0.8
        self.view.addSubview(lblLogin)
        lblLogin.snp.makeConstraints { (mack) in
            mack.top.equalTo(Wl_imageView.snp.bottom).offset(COMPUTE_LENGTH(72))
            mack.centerX.equalTo(self.view)
        }
        
        // Input fileds and Login Button........
        
        let txtUserName = UITextField(frame: CGRect(x: 40, y: 270, width: 300, height: 40))
        txtUserName.placeholder = "Email Address"
        txtUserName.font = UIFont.systemFont(ofSize: 15)
        txtUserName.borderStyle = UITextBorderStyle.none
        txtUserName.autocorrectionType = UITextAutocorrectionType.no
        txtUserName.keyboardType = UIKeyboardType.default
        txtUserName.returnKeyType = UIReturnKeyType.done
        txtUserName.clearButtonMode = UITextFieldViewMode.whileEditing;
        txtUserName.contentVerticalAlignment = UIControlContentVerticalAlignment.center
        self.view.addSubview(txtUserName)
        
        if(SCREEN_WIDTH() <= 320)
        {
            seperatorLabel2 = UILabel(frame: CGRect(x:40, y:(txtUserName.frame.size.height+txtUserName.frame.origin.y), width:240, height: 1))
            
        }
        else
        {
            seperatorLabel2 = UILabel(frame: CGRect(x:40, y:(txtUserName.frame.size.height+txtUserName.frame.origin.y), width:290, height: 1))
            
        }
        //seperatorLabel2 = UILabel(frame: CGRect(x:40, y:(txtUserName.frame.size.height+txtUserName.frame.origin.y), width:240, height: 1))
        seperatorLabel2.backgroundColor = UIColor.white
        seperatorLabel2.alpha = 0.5
        
        numberofFields += 1
        self.view.addSubview(seperatorLabel2)
        
        
        let img_Btnlogin = UIImage(named: "btn@3x") as UIImage?
        let btnlogin = UIButton(frame: CGRect(x: 20 ,y:450, width: 120, height:30))
        btnlogin.backgroundColor = UIColor.clear
     //   btnlogin.addTarget(self, action: #selector(loginAction(btn:)), for: .touchUpInside)
        btnlogin.setBackgroundImage(img_Btnlogin, for: .normal)
        btnlogin.setTitle("Confirm", for: .normal)
        
        self.view.addSubview(btnlogin)
        
        let img_BtnCancel = UIImage(named: "btn@3x") as UIImage?
        if(SCREEN_WIDTH() <= 320)
        {
            btnCancel = UIButton(frame: CGRect(x: 180 ,y:450, width: 120, height:30))
        }
        else
        {
          btnCancel = UIButton(frame: CGRect(x: 230 ,y:450, width: 120, height:30))
        }
        btnCancel.backgroundColor = UIColor.clear
        //   btnlogin.addTarget(self, action: #selector(loginAction(btn:)), for: .touchUpInside)
        btnCancel.setBackgroundImage(img_BtnCancel, for: .normal)
        btnCancel.setTitle("Cancel", for: .normal)
        
        self.view.addSubview(btnCancel)
        



        
        // Bottom images
        let imageName1 = "FV-logo@3x.png"
        let image1 = UIImage(named: imageName1)
        let imageView1 = UIImageView(image: image1!)
        imageView1.center = CGPoint(x: 50, y :630)
        self.view.addSubview(imageView1)
        imageView1.snp.makeConstraints { (mack) in
            mack.left.equalTo(COMPUTE_LENGTH(77))
            mack.width.equalTo(COMPUTE_LENGTH(214))
            mack.height.equalTo(COMPUTE_LENGTH(127))
            mack.bottom.equalTo(self.view.snp.bottom).offset(-COMPUTE_LENGTH(99))
        }
        
        
        let imageName2 = "Finance-Review-Logo@3x.png"
        let image2 = UIImage(named: imageName2)
        let imageView2 = UIImageView(image: image2!)
        imageView2.center = CGPoint(x: 150, y :630)
        self.view.addSubview(imageView2)
        imageView2.snp.makeConstraints { (mack) in
            mack.left.equalTo(imageView1.snp.right).offset(COMPUTE_LENGTH(48))
            mack.width.equalTo(COMPUTE_LENGTH(243))
            mack.height.equalTo(COMPUTE_LENGTH(64))
            mack.bottom.equalTo(imageView1.snp.bottom).offset(-COMPUTE_LENGTH(25))
            
        }
        
        let imageName3 = "Best--Trading@3x.png"
        let image3 = UIImage(named: imageName3)
        let imageView3 = UIImageView(image: image3!)
        imageView3.center = CGPoint(x: 230, y :630)
        self.view.addSubview(imageView3)
        imageView3.snp.makeConstraints { (mack) in
            mack.left.equalTo(imageView2.snp.right).offset(COMPUTE_LENGTH(68))
            mack.width.equalTo(COMPUTE_LENGTH(130))
            mack.height.equalTo(COMPUTE_LENGTH(127))
            mack.bottom.equalTo(imageView1)
        }

        
        let imageName4 = "Best-Binary-Logo@3x.png"
        let image4 = UIImage(named: imageName4)
        let imageView4 = UIImageView(image: image4!)
        imageView4.center = CGPoint(x: 310, y :630)
        self.view.addSubview(imageView4)
        imageView4.snp.makeConstraints { (mack) in
            mack.left.equalTo(imageView3.snp.right).offset(COMPUTE_LENGTH(58))
            mack.width.equalTo(COMPUTE_LENGTH(304))
            mack.height.equalTo(COMPUTE_LENGTH(111))
            mack.bottom.equalTo(imageView1.snp.bottom).offset(COMPUTE_LENGTH(10))
        }


        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func loginBack(btn:UIButton!)  {
        print("Hello test login")
        let vc = ViewController()
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
}
