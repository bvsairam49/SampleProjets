

//
//  BindingMT4AccountViewController.swift
//  MobileBinaryOptions
//
//  Created by Anandh on 2/8/17.
//  Copyright © 2017 Broctagon. All rights reserved.
//

import UIKit

class BindingMT4AccountViewController: BaseVC , UITableViewDelegate, UITableViewDataSource, UITextFieldDelegate, UIGestureRecognizerDelegate {
    
    // BackgroundView
    var bindMt4BackGrounDView = UIView()
    // headerView
    var bindMt4HeaderView = UIView()
    // Header label
    var bindMT4headerLabel = UILabel()
    //  Cancel  Button
    var cancelBtn = UIButton()
    
    // TableView MT4 Binding ACcounts
    var mt4BindingAccountsTableView = UITableView()
    // Binding Mt4 ACcount
    var mt4AccountnumberLabel = UILabel()
    var checkmarkBtn = UIButton()
    var passwordTextfield = UITextField()
    var selectedCorrectBtn =  UIButton()
    var seperatorLabel = UILabel()
    
    //MT4AccountsDetails Array
    var mt4AccountsArray = NSMutableArray()
    
    //  SubMit btn
    var submitBtn = UIButton()
    
    // Tap gesture
    let gestureRecognizer = UITapGestureRecognizer()

    
    
    // MARK:- View Initialization.

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        // MT4 Accounts Array
        mt4AccountsArray = ["234444:","2567890:","24567887:","234774:","2567980:","2456737:"]
        // Device Orientation(Landscape or Portrait)
//        let value = UIInterfaceOrientation.landscapeLeft.rawValue
//        UIDevice.current.setValue(value, forKey: "orientation")
        // Add Controls For UI.
        self.addControlsForBindingMT4Account()
        // Tap gesture
        let gestureRecognizer = UITapGestureRecognizer(target: self, action:#selector(handleTap(gestureRecognizer:)))
        gestureRecognizer.delegate = self
        self.view.addGestureRecognizer(gestureRecognizer)
       
    }
    
    // MARK:- AddControls For UI
     func addControlsForBindingMT4Account()
     {
        // AccountManagementBG view
        let frame = CGRect(x: CGFloat(0), y: CGFloat(0), width: SCREEN_WIDTH(), height: SCREEN_HEIGHT())
        let backgroundImage = UIImageView(frame: frame)
        backgroundImage.image = UIImage(named: "bg2.png")
        self.bindMt4BackGrounDView.insertSubview(backgroundImage, at: 0)
        self.view.addSubview(self.bindMt4BackGrounDView)
        
        //Header view
        bindMt4HeaderView = UIView(frame: CGRect(x: 0, y:0, width: SCREEN_WIDTH(), height: 44))
        bindMt4HeaderView.backgroundColor = UIColor.clear
        bindMt4HeaderView.backgroundColor =  UIColor(patternImage: UIImage(named:"title_bg@3x")!)
        self.view.addSubview(bindMt4HeaderView)
        
        // Header label
        bindMT4headerLabel = UILabel(frame: CGRect(x: 0, y:0, width: SCREEN_WIDTH(), height: 44))
        bindMT4headerLabel.text = "Binding MT4 Account"
        bindMT4headerLabel.textColor = UIColor.yellow
        bindMT4headerLabel.textAlignment = .center
        bindMT4headerLabel.font = UIFont.systemFont(ofSize: 20)
        bindMt4HeaderView.addSubview(bindMT4headerLabel)
        
        //  cancel Button
        cancelBtn = UIButton(frame: CGRect(x: (SCREEN_WIDTH()-30), y:9, width: 25, height: 25))
        cancelBtn.setImage(UIImage(named: "close_icon@3x.png"), for: .normal)
        cancelBtn.addTarget(self, action:#selector(self.submitButtonAction(_:)), for: .touchUpInside)
        bindMt4HeaderView.addSubview(cancelBtn)
        
        // BindingMT4 AccountsView
        if(SCREEN_WIDTH() <= 568)
        {
            mt4BindingAccountsTableView.frame = CGRect(x: CGFloat(SCREEN_WIDTH()*24/100)+10, y: CGFloat(bindMt4HeaderView.frame.size.height+bindMt4HeaderView.frame.origin.y+20), width: CGFloat(SCREEN_WIDTH()-(SCREEN_WIDTH()*48/100)), height: CGFloat(SCREEN_HEIGHT()*50/100))
        }
        else
        {
            mt4BindingAccountsTableView.frame = CGRect(x: CGFloat(SCREEN_WIDTH()*26/100)+10, y: CGFloat(bindMt4HeaderView.frame.size.height+bindMt4HeaderView.frame.origin.y+40), width: CGFloat(SCREEN_WIDTH()-(SCREEN_WIDTH()*52/100)), height: CGFloat(SCREEN_HEIGHT()*50/100))
        }
        mt4BindingAccountsTableView.backgroundColor = UIColor.clear
        mt4BindingAccountsTableView.layoutMargins = UIEdgeInsets.zero
        mt4BindingAccountsTableView.separatorInset = UIEdgeInsets.zero
        mt4BindingAccountsTableView.dataSource = self
        mt4BindingAccountsTableView.delegate = self
        mt4BindingAccountsTableView.separatorStyle = .none
        mt4BindingAccountsTableView.allowsSelection = true
        mt4BindingAccountsTableView.reloadData()
        self.view.addSubview(mt4BindingAccountsTableView)
    
        // SUBMIT Button
        submitBtn = UIButton(type:.custom)
        submitBtn = UIButton(frame: CGRect(x:((SCREEN_WIDTH()-(SCREEN_WIDTH()*65/100))), y:(mt4BindingAccountsTableView.frame.size.height+mt4BindingAccountsTableView.frame.origin.y+40), width:((SCREEN_WIDTH()-(SCREEN_WIDTH()*65/100))), height: 30))
//        submitBtn.setBackgroundImage(UIImage(named: "btn@3x.png"), for: .normal)
        submitBtn.setBackgroundImage(UIImage.init(named: "btn"), for: .normal)
        submitBtn.setBackgroundImage(UIImage.init(named: "btn_press"), for: .highlighted)
        submitBtn.setTitle("Submit", for: .normal)
        submitBtn.titleLabel?.font = UIFont.systemFont(ofSize: 14)
        submitBtn.addTarget(self, action:#selector(self.submitButtonAction), for: .touchUpInside)
        submitBtn.isExclusiveTouch = true
        self.view.addSubview(submitBtn)
    }
    
       // MARK:- UITableView Datasource and Delegate methods
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 76
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return mt4AccountsArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell: UITableViewCell? = nil
        let cellIdentifier: String = "\("Cell")\(Int(indexPath.row))"
        cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier)
        if cell == nil {
            cell = UITableViewCell(style: .default, reuseIdentifier: cellIdentifier)
            cell?.backgroundColor = UIColor.clear
            
            // CheckMark Button
            checkmarkBtn = UIButton(frame: CGRect(x:0, y:0, width:16, height: 16))
            checkmarkBtn.setBackgroundImage(UIImage(named: "checkmark_icon_Press@3x.png"), for: .normal)
            checkmarkBtn.backgroundColor = UIColor.clear
            checkmarkBtn.imageView?.contentMode = .scaleAspectFit
            cell?.contentView.addSubview(checkmarkBtn)
            
            // MT4 Account Label
            mt4AccountnumberLabel = UILabel(frame: CGRect(x:(checkmarkBtn.frame.size.width+checkmarkBtn.frame.origin.x+10), y:0, width: mt4BindingAccountsTableView.frame.size.width/2, height: 22))
            mt4AccountnumberLabel.text = mt4AccountsArray[indexPath.row] as? String
            mt4AccountnumberLabel.textColor = UIColor.white
            mt4AccountnumberLabel.textAlignment = .center
            mt4AccountnumberLabel.font = UIFont.systemFont(ofSize: 16)
            mt4AccountnumberLabel.textAlignment = .left
            cell?.contentView.addSubview(mt4AccountnumberLabel)
            
            //password TextField
            passwordTextfield = UITextField(frame: CGRect(x:(mt4AccountnumberLabel.frame.origin.x), y:(mt4AccountnumberLabel.frame.size.height+mt4AccountnumberLabel.frame.origin.y+10), width:(mt4BindingAccountsTableView.frame.size.width-40), height: 25))
            passwordTextfield.placeholder = "Password"
            passwordTextfield.delegate = self
            passwordTextfield.textColor = UIColor.gray
            passwordTextfield.keyboardType = UIKeyboardType.default
            passwordTextfield.borderStyle = UITextBorderStyle.none
            passwordTextfield.backgroundColor = UIColor.clear
            cell?.contentView.addSubview(passwordTextfield)
            
            // CorrectBtn
            selectedCorrectBtn = UIButton(frame: CGRect(x:(mt4BindingAccountsTableView.frame.size.width-40), y:passwordTextfield.frame.origin.y+10, width: 16, height: 15))
            selectedCorrectBtn.setBackgroundImage(UIImage(named: "correct_icon@3x.png"), for: .normal)
            selectedCorrectBtn.imageView?.contentMode = .scaleAspectFit
            cell?.contentView.addSubview(selectedCorrectBtn)
            
            // Seperator Label
            seperatorLabel = UILabel(frame: CGRect(x:20, y:60, width:mt4BindingAccountsTableView.frame.size.width - 20, height: 1))
            seperatorLabel.backgroundColor = UIColor.lightGray
            cell?.contentView.addSubview(seperatorLabel)
        }
        return cell!
    }
    
    // MARK:- Button Action Methods
    func cancelButtonAction(_ sender: UIButton) {
        // LoginView
        let vc = LoginVC()
        let navi = BaseNavigationController(rootViewController: vc)
        navi.navigationBar.isTranslucent = false
        navi.isNavigationBarHidden = true
        self.present(navi, animated: true, completion: nil)
        
    }

    func submitButtonAction(_ sender: UIButton) {
         // TradingVC
        let vc = TradingHallVC()
        let navi = BaseNavigationController(rootViewController: vc)
        navi.navigationBar.isTranslucent = false
        navi.isNavigationBarHidden = true
        self.present(navi, animated: true, completion: nil)

    }
    
    // MARK:- Textfield delegate Methods
    func textFieldDidBeginEditing(_ textField: UITextField) {
        animateViewMoving(true, moveValue: 100)
    }
    func textFieldDidEndEditing(_ textField: UITextField) {
        animateViewMoving(false, moveValue: 100)
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool
    {
        textField.resignFirstResponder()
        return true
    }
    func animateViewMoving (_ up:Bool, moveValue :CGFloat){
        let movementDuration:TimeInterval = 0.3
        let movement:CGFloat = ( up ? -moveValue : moveValue)
        UIView.beginAnimations( "animateView", context: nil)
        UIView.setAnimationBeginsFromCurrentState(true)
        UIView.setAnimationDuration(movementDuration )
        self.view.frame = self.view.frame.offsetBy(dx: 0,  dy: movement)
        UIView.commitAnimations()
    }
    
    //MARK:- Tap Gesture Method
    func handleTap(gestureRecognizer: UIGestureRecognizer) {
        self.view.endEditing(true)
    }
    
   
    // MARK:- Device Orientation
    
    override var shouldAutorotate: Bool {
        return true
    }
    
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return .landscape
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
