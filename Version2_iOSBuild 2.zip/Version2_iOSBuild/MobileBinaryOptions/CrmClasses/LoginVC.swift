//
//  LoginVC.swift
//  MobileBinaryOptions
//
//  Created by ALOK KUMAR on 24/01/17.
//  Copyright © 2017 Broctagon. All rights reserved.
//

import UIKit
import SnapKit

class LoginVC: UIViewController {
    var seperatorLabel1 = UILabel()
    var seperatorLabel2 = UILabel()
    var numberofFields: Int = 0
    
    
    


    override func viewDidLoad() {
        super.viewDidLoad()

        let imageName = "bg@3x.png"
        let image = UIImage(named: imageName)
        let imageView = UIImageView(image: image!)
        self.view.addSubview(imageView)

//        let WL_logo = "Starfish-Logo@3x.png"
//        let Wl_image = UIImage(named: WL_logo)
//        let Wl_imageView = UIImageView(image: Wl_image!)
//        Wl_imageView.center = CGPoint(x: 180, y :90)
//        self.view.addSubview(Wl_imageView)
        let WL_logo = "Starfish-Logo"
        let Wl_image = UIImage(named: WL_logo)
        let Wl_imageView = UIImageView(image: Wl_image!)
        //        Wl_imageView.center = CGPoint(x: ((SCREEN_WIDTH()*45/100)+14), y :120)
        self.view.addSubview(Wl_imageView)
        Wl_imageView.snp.makeConstraints { (mack) in
            mack.top.equalTo(COMPUTE_LENGTH(230))
            mack.centerX.equalTo(self.view)
            mack.width.equalTo(COMPUTE_LENGTH(665))
            mack.height.equalTo(COMPUTE_LENGTH(211))
        }

        
//        let lbl_version = UILabel(frame: CGRect(x: 0, y: 0, width: 200, height: 21))
//        lbl_version.center = CGPoint(x: 300, y: 35)
//        lbl_version.textAlignment = .center
//        lbl_version.text = "Version: 0.0.0"
//        self.view.addSubview(lbl_version)
        
        let lbl_version = UILabel.init()
        //        let lbl_version = UILabel(frame: CGRect(x:((SCREEN_WIDTH()*10/100)+120), y: 20, width: 200, height: 21))
        //lbl_version.center = CGPoint(x: 300, y: 40)
        lbl_version.textAlignment = .center
        lbl_version.text = "Version:0.0.0"
        lbl_version.textColor = kColorTimeframeNormal()
        lbl_version.font = UIFont.systemFont(ofSize: 12)
        self.view.addSubview(lbl_version)
        lbl_version.snp.makeConstraints { (mack) in
            mack.top.equalTo(COMPUTE_LENGTH(120))
            mack.left.equalTo(self.view.snp.right).offset(-COMPUTE_LENGTH(300))
        }
        // back_icon
        let backBtn = UIButton(frame: CGRect(x: 0 ,y:30, width: COMPUTE_LENGTH(180), height:COMPUTE_LENGTH(68)))
        backBtn.backgroundColor = UIColor.clear
        backBtn.addTarget(self, action: #selector(loginBack(btn:)), for: .touchUpInside)
        backBtn.setImage( UIImage(named: "back_icon"), for: .normal)
        backBtn.imageView?.contentMode = .scaleAspectFit
        self.view.addSubview(backBtn)
        
        let lblLogin = UILabel(frame: CGRect(x: 0, y: 0, width: SCREEN_WIDTH(), height: 36))
        lblLogin.textAlignment = .center
        lblLogin.text = "Login"
        lblLogin.adjustsFontSizeToFitWidth=true
        lblLogin.font = UIFont(name:lblLogin.font.fontName,size :25)
        lblLogin.textColor = UIColor.yellow
        lblLogin.alpha = 0.8
        self.view.addSubview(lblLogin)
        lblLogin.snp.makeConstraints { (mack) in
            mack.top.equalTo(Wl_imageView.snp.bottom).offset(COMPUTE_LENGTH(72))
            mack.centerX.equalTo(self.view)
        }
        
        
        // Input fileds and Login Button........
        
        let txtUserName = UITextField(frame: CGRect(x: 40, y: 230, width: (SCREEN_WIDTH()-80), height: 40))
        txtUserName.placeholder = "Email Address"
        txtUserName.font = UIFont.systemFont(ofSize: 15)
        txtUserName.borderStyle = UITextBorderStyle.none
        txtUserName.textColor = UIColor.white
        txtUserName.autocorrectionType = UITextAutocorrectionType.no
        txtUserName.keyboardType = UIKeyboardType.default
        txtUserName.returnKeyType = UIReturnKeyType.done
        txtUserName.clearButtonMode = UITextFieldViewMode.whileEditing;
        txtUserName.contentVerticalAlignment = UIControlContentVerticalAlignment.center
         self.view.addSubview(txtUserName)
        
        if(SCREEN_WIDTH() <= 320)
        {
            seperatorLabel2 = UILabel(frame: CGRect(x:40, y:(txtUserName.frame.size.height+txtUserName.frame.origin.y), width:240, height: 1))
            
        }
        else
        {
            seperatorLabel2 = UILabel(frame: CGRect(x:40, y:(txtUserName.frame.size.height+txtUserName.frame.origin.y), width:290, height: 1))
            
        }
        //seperatorLabel2 = UILabel(frame: CGRect(x:40, y:(txtUserName.frame.size.height+txtUserName.frame.origin.y), width:240, height: 1))
        seperatorLabel2.backgroundColor = UIColor.white
        seperatorLabel2.alpha = 0.5
        
        numberofFields += 1
        self.view.addSubview(seperatorLabel2)

        var txtPassword = UITextField()
        
        //        {
        //            lbl_Online_User = UILabel(frame: CGRect(x:((SCREEN_WIDTH()*10/100)+60), y: 230, width: 500, height: 40))
        //        }
        //        else{
        //            lbl_Online_User = UILabel(frame: CGRect(x:((SCREEN_WIDTH()*10/100)+80), y: 230, width: 500, height: 40))
        //        }

        txtPassword = UITextField(frame: CGRect(x: 40, y: 280, width: (SCREEN_WIDTH()-80), height: 40))
        txtPassword.placeholder = "Password"
        txtPassword.font = UIFont.systemFont(ofSize: 15)
        txtPassword.borderStyle = UITextBorderStyle.none
        txtPassword.textColor = UIColor.white
        txtPassword.isSecureTextEntry = true
        txtPassword.autocorrectionType = UITextAutocorrectionType.no
        txtPassword.keyboardType = UIKeyboardType.default
        txtPassword.returnKeyType = UIReturnKeyType.done
        txtPassword.clearButtonMode = UITextFieldViewMode.whileEditing;
        txtPassword.contentVerticalAlignment = UIControlContentVerticalAlignment.center
        self.view.addSubview(txtPassword)
        // Seperater Line 
        if(SCREEN_WIDTH() <= 320)
        {
            seperatorLabel1 = UILabel(frame: CGRect(x:40, y:(txtPassword.frame.size.height+txtPassword.frame.origin.y), width:240, height: 1))

        }
        else
        {
            seperatorLabel1 = UILabel(frame: CGRect(x:40, y:(txtPassword.frame.size.height+txtPassword.frame.origin.y), width:290, height: 1))

        }
        //seperatorLabel1 = UILabel(frame: CGRect(x:40, y:(txtPassword.frame.size.height+txtPassword.frame.origin.y), width:240, height: 1))
        seperatorLabel1.backgroundColor = UIColor.white
        seperatorLabel1.alpha = 0.5
        
        numberofFields += 1
        self.view.addSubview(seperatorLabel1)

        
        
        
        //let img_Btnlogin = UIImage(named: "btn@3x") as UIImage?
        let btnlogin = UIButton.init(type: .custom)
        btnlogin.setTitle("Login", for: .normal)
        btnlogin.setTitleColor(kColorDouble(), for: .highlighted)
        btnlogin.setTitleColor(UIColor.white, for: .normal)
        btnlogin.setBackgroundImage(UIImage.init(named: "btn"), for: .normal)
        btnlogin.setBackgroundImage(UIImage.init(named: "btn_press"), for: .highlighted)

        btnlogin.addTarget(self, action: #selector(loginAction(btn:)), for: .touchUpInside)
       // btnlogin.setBackgroundImage(img_Btnlogin, for: .normal)
      //  btnlogin.setTitle("Login", for: .normal)
        self.view.addSubview(btnlogin)
        
        btnlogin.snp.makeConstraints { (mack) in
            mack.top.equalTo(txtPassword.snp.bottom).offset(COMPUTE_LENGTH(72))
            mack.centerX.equalTo(self.view)
        }

        
        let lblreginfo = UILabel(frame: CGRect(x: 0, y: 0, width: 200, height: 21))
        lblreginfo.center = CGPoint(x: 180, y: 450)
        lblreginfo.textAlignment = .center
        lblreginfo.text = "If you don't have account go and Register"
        lblreginfo.adjustsFontSizeToFitWidth=true
        lblreginfo.font = UIFont(name:lblreginfo.font.fontName,size :12)
        lblreginfo.textColor = UIColor.white
        lblreginfo.alpha = 0.5
        lblreginfo.numberOfLines = 8
        self.view.addSubview(lblreginfo)
        lblreginfo.snp.makeConstraints{ (mack) in
            mack.top.equalTo(btnlogin.snp.bottom).offset(COMPUTE_LENGTH(30))
            mack.centerX.equalTo(self.view)
        }
        
        
        
        let btnForgotPass = UIButton(frame: CGRect(x: ((SCREEN_WIDTH()*10/100)-40) ,y:480, width: SCREEN_WIDTH(), height:50))
        btnForgotPass.backgroundColor = UIColor.clear
        btnForgotPass.addTarget(self, action: #selector(ForgotPass(btn:)), for: .touchUpInside)
        //        btn_Lang.setBackgroundImage(img_Btnlang, for: .normal)
        //btnForgotPass.setImage(img_Btnlogin, for: .normal)
        btnForgotPass.setTitle("Forgot Password?", for: UIControlState.normal)
        self.view.addSubview(btnForgotPass)
        btnForgotPass.snp.makeConstraints { (mack) in
            mack.top.equalTo(lblreginfo.snp.bottom).offset(COMPUTE_LENGTH(58))
            mack.centerX.equalTo(self.view)
 
        }



        
        // Bottom images
        let imageName1 = "FV-logo@3x.png"
        let image1 = UIImage(named: imageName1)
        let imageView1 = UIImageView(image: image1!)
        imageView1.center = CGPoint(x: 50, y :630)
        self.view.addSubview(imageView1)
        imageView1.snp.makeConstraints { (mack) in
            mack.left.equalTo(COMPUTE_LENGTH(77))
            mack.width.equalTo(COMPUTE_LENGTH(214))
            mack.height.equalTo(COMPUTE_LENGTH(127))
            mack.bottom.equalTo(self.view.snp.bottom).offset(-COMPUTE_LENGTH(99))
        }
        
        
        
        let imageName2 = "Finance-Review-Logo@3x.png"
        let image2 = UIImage(named: imageName2)
        let imageView2 = UIImageView(image: image2!)
        imageView2.center = CGPoint(x: 150, y :630)
        self.view.addSubview(imageView2)
        
        imageView2.snp.makeConstraints { (mack) in
            mack.left.equalTo(imageView1.snp.right).offset(COMPUTE_LENGTH(48))
            mack.width.equalTo(COMPUTE_LENGTH(243))
            mack.height.equalTo(COMPUTE_LENGTH(64))
            mack.bottom.equalTo(imageView1.snp.bottom).offset(-COMPUTE_LENGTH(25))
            
        }

        
        let imageName3 = "Best--Trading"

        let image3 = UIImage(named: imageName3)
        let imageView3 = UIImageView(image: image3!)
        imageView3.center = CGPoint(x: 230, y :630)
        self.view.addSubview(imageView3)
        
        imageView3.snp.makeConstraints { (mack) in
            mack.left.equalTo(imageView2.snp.right).offset(COMPUTE_LENGTH(68))
            mack.width.equalTo(COMPUTE_LENGTH(130))
            mack.height.equalTo(COMPUTE_LENGTH(127))
            mack.bottom.equalTo(imageView1)
        }

        
        let imageName4 = "Best-Binary-Logo@3x.png"
        let image4 = UIImage(named: imageName4)
        let imageView4 = UIImageView(image: image4!)
        imageView4.center = CGPoint(x: 310, y :630)
        self.view.addSubview(imageView4)
        
        imageView4.snp.makeConstraints { (mack) in
            mack.left.equalTo(imageView3.snp.right).offset(COMPUTE_LENGTH(58))
            mack.width.equalTo(COMPUTE_LENGTH(304))
            mack.height.equalTo(COMPUTE_LENGTH(111))
            mack.bottom.equalTo(imageView1.snp.bottom).offset(COMPUTE_LENGTH(10))
        }
        

        
    }
    
    func loginBack(btn:UIButton!)  {
        print("Hello test login")
        let vc = ViewController()
        self.navigationController?.pushViewController(vc, animated: true)
  
    }

    func ForgotPass(btn:UIButton!)  {
        print("Clicked on Forgot pass")
        let vc = ForgotPasswordVC()
        self.navigationController?.pushViewController(vc, animated: true)
        
    }

    func loginAction(btn:UIButton!)  {
         // BIndingMT4ACcountView
        let vc = BindingMT4AccountViewController()
        let navi = BaseNavigationController(rootViewController: vc)
        navi.navigationBar.isTranslucent = false
        navi.isNavigationBarHidden = true
        self.present(navi, animated: true, completion: nil)
        
    }
    
    // MARK: - Device Orientation
    
    override var shouldAutorotate: Bool {
        return true
    }
    
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return .portrait
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
