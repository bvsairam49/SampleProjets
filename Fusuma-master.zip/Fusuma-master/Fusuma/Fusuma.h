//
//  Fusuma.h
//  Fusuma
//
//  Created by Yuta Akizuki on 2016/03/26.
//  Copyright © 2016年 ytakzk. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Fusuma.
FOUNDATION_EXPORT double FusumaVersionNumber;

//! Project version string for Fusuma.
FOUNDATION_EXPORT const unsigned char FusumaVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Fusuma/PublicHeader.h>


