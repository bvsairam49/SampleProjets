# HorizontalScrollCell
Horizontal Scrollable UICollectionView Cell for ios.

Update 07.03.2015
-Pull to refresh added.



